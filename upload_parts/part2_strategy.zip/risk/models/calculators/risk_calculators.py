"""其他风险指标计算器

提供波动率、贝塔、夏普比率、最大回撤等风险指标的计算
"""

import logging
import numpy as np
from typing import Dict, Any, Optional, List
from datetime import datetime

from ..risk_types import RiskCalculationConfig

logger = logging.getLogger(__name__)


class VolatilityCalculator:
    """波动率计算器"""
    
    def __init__(self, config: Optional[RiskCalculationConfig] = None):
        self.config = config or RiskCalculationConfig()
    
    def calculate(self, returns: np.ndarray) -> float:
        """计算年化波动率
        
        Args:
            returns: 收益率序列
            
        Returns:
            年化波动率
        """
        try:
            if len(returns) == 0:
                return 0.0
            
            # 计算标准差
            volatility = np.std(returns)
            
            # 年化（假设252个交易日）
            annualized_volatility = volatility * np.sqrt(252)
            
            return annualized_volatility
        except Exception as e:
            logger.error(f"波动率计算失败: {e}")
            return 0.0


class PositionRiskCalculator:
    """仓位风险计算器"""
    
    def __init__(self, config: Optional[RiskCalculationConfig] = None):
        self.config = config or RiskCalculationConfig()
    
    def calculate(self, portfolio_data: Dict[str, Any]) -> float:
        """计算仓位风险
        
        Args:
            portfolio_data: 投资组合数据
            
        Returns:
            仓位风险值
        """
        try:
            positions = portfolio_data.get('positions', {})
            total_value = portfolio_data.get('total_value', 0.0)
            
            if total_value == 0:
                return 0.0
            
            # 计算最大单仓位占比
            max_position_ratio = 0.0
            for symbol, position in positions.items():
                position_value = position.get('value', 0.0)
                ratio = abs(position_value) / total_value
                max_position_ratio = max(max_position_ratio, ratio)
            
            return max_position_ratio
        except Exception as e:
            logger.error(f"仓位风险计算失败: {e}")
            return 0.0


class LiquidityCalculator:
    """流动性风险计算器"""
    
    def __init__(self, config: Optional[RiskCalculationConfig] = None):
        self.config = config or RiskCalculationConfig()
    
    def calculate(self, portfolio_data: Dict[str, Any]) -> float:
        """计算流动性风险
        
        Args:
            portfolio_data: 投资组合数据
            
        Returns:
            流动性风险评分 (0-1, 越高风险越大)
        """
        try:
            positions = portfolio_data.get('positions', {})
            
            if not positions:
                return 0.0
            
            # 简化的流动性评分：基于成交量和买卖价差
            liquidity_scores = []
            for symbol, position in positions.items():
                volume = position.get('volume', 0.0)
                spread = position.get('spread', 0.0)
                
                # 流动性评分：成交量越大、价差越小，流动性越好
                if volume > 0:
                    score = spread / np.log(1 + volume)
                else:
                    score = 1.0  # 最高风险
                
                liquidity_scores.append(score)
            
            # 返回平均流动性风险
            return np.mean(liquidity_scores) if liquidity_scores else 0.0
        except Exception as e:
            logger.error(f"流动性风险计算失败: {e}")
            return 0.0


class CorrelationCalculator:
    """相关性风险计算器"""
    
    def __init__(self, config: Optional[RiskCalculationConfig] = None):
        self.config = config or RiskCalculationConfig()
    
    def calculate(self, returns_matrix: np.ndarray) -> float:
        """计算投资组合的平均相关性
        
        Args:
            returns_matrix: 资产收益率矩阵 (n_assets x n_periods)
            
        Returns:
            平均相关系数
        """
        try:
            if returns_matrix.shape[0] < 2:
                return 0.0
            
            # 计算相关系数矩阵
            corr_matrix = np.corrcoef(returns_matrix)
            
            # 提取上三角（不包括对角线）
            upper_triangle = corr_matrix[np.triu_indices_from(corr_matrix, k=1)]
            
            # 返回平均相关系数
            return np.mean(np.abs(upper_triangle)) if len(upper_triangle) > 0 else 0.0
        except Exception as e:
            logger.error(f"相关性计算失败: {e}")
            return 0.0


class ConcentrationCalculator:
    """集中度风险计算器"""
    
    def __init__(self, config: Optional[RiskCalculationConfig] = None):
        self.config = config or RiskCalculationConfig()
    
    def calculate(self, portfolio_data: Dict[str, Any]) -> float:
        """计算投资组合集中度（赫芬达尔指数）
        
        Args:
            portfolio_data: 投资组合数据
            
        Returns:
            集中度指数 (0-1, 越高越集中)
        """
        try:
            positions = portfolio_data.get('positions', {})
            total_value = portfolio_data.get('total_value', 0.0)
            
            if total_value == 0 or not positions:
                return 0.0
            
            # 计算各资产权重
            weights = []
            for symbol, position in positions.items():
                position_value = position.get('value', 0.0)
                weight = abs(position_value) / total_value
                weights.append(weight)
            
            # 计算赫芬达尔指数 (HHI)
            hhi = sum([w**2 for w in weights])
            
            return hhi
        except Exception as e:
            logger.error(f"集中度计算失败: {e}")
            return 0.0


class SharpeRatioCalculator:
    """夏普比率计算器"""
    
    def __init__(self, config: Optional[RiskCalculationConfig] = None):
        self.config = config or RiskCalculationConfig()
    
    def calculate(self, returns: np.ndarray, risk_free_rate: float = 0.02) -> float:
        """计算夏普比率
        
        Args:
            returns: 收益率序列
            risk_free_rate: 无风险利率（年化）
            
        Returns:
            夏普比率
        """
        try:
            if len(returns) == 0:
                return 0.0
            
            # 计算平均收益和标准差
            mean_return = np.mean(returns)
            std_return = np.std(returns)
            
            if std_return == 0:
                return 0.0
            
            # 年化
            annualized_return = mean_return * 252
            annualized_std = std_return * np.sqrt(252)
            
            # 计算夏普比率
            sharpe = (annualized_return - risk_free_rate) / annualized_std
            
            return sharpe
        except Exception as e:
            logger.error(f"夏普比率计算失败: {e}")
            return 0.0


class BetaCalculator:
    """贝塔系数计算器"""
    
    def __init__(self, config: Optional[RiskCalculationConfig] = None):
        self.config = config or RiskCalculationConfig()
    
    def calculate(self, portfolio_returns: np.ndarray, 
                 market_returns: np.ndarray) -> float:
        """计算贝塔系数
        
        Args:
            portfolio_returns: 投资组合收益率
            market_returns: 市场收益率
            
        Returns:
            贝塔系数
        """
        try:
            if len(portfolio_returns) != len(market_returns):
                logger.warning("投资组合和市场收益率长度不匹配")
                return 1.0
            
            if len(portfolio_returns) < 2:
                return 1.0
            
            # 计算协方差和方差
            covariance = np.cov(portfolio_returns, market_returns)[0, 1]
            market_variance = np.var(market_returns)
            
            if market_variance == 0:
                return 1.0
            
            # 计算贝塔
            beta = covariance / market_variance
            
            return beta
        except Exception as e:
            logger.error(f"贝塔系数计算失败: {e}")
            return 1.0


class MaxDrawdownCalculator:
    """最大回撤计算器"""
    
    def __init__(self, config: Optional[RiskCalculationConfig] = None):
        self.config = config or RiskCalculationConfig()
    
    def calculate(self, equity_curve: np.ndarray) -> float:
        """计算最大回撤
        
        Args:
            equity_curve: 权益曲线
            
        Returns:
            最大回撤比例
        """
        try:
            if len(equity_curve) == 0:
                return 0.0
            
            # 计算累积最大值
            cumulative_max = np.maximum.accumulate(equity_curve)
            
            # 计算回撤
            drawdowns = (equity_curve - cumulative_max) / cumulative_max
            
            # 返回最大回撤（绝对值）
            max_drawdown = np.min(drawdowns)
            
            return abs(max_drawdown)
        except Exception as e:
            logger.error(f"最大回撤计算失败: {e}")
            return 0.0


# 导出所有计算器
__all__ = [
    'VolatilityCalculator',
    'PositionRiskCalculator',
    'LiquidityCalculator',
    'CorrelationCalculator',
    'ConcentrationCalculator',
    'SharpeRatioCalculator',
    'BetaCalculator',
    'MaxDrawdownCalculator'
]

