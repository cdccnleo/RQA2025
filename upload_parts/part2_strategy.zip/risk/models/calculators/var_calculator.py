"""VaR计算器

提供多种VaR计算方法：历史模拟法、蒙特卡洛法、参数法
"""

import logging
import numpy as np
from typing import Dict, Any, Optional
from datetime import datetime

from ..risk_types import RiskCalculationConfig, RiskCalculationResult, RiskMetricType

logger = logging.getLogger(__name__)


class VaRCalculator:
    """VaR (Value at Risk) 计算器
    
    支持多种VaR计算方法:
    - 历史模拟法
    - 蒙特卡洛模拟法
    - 参数法 (方差-协方差法)
    """
    
    def __init__(self, config: Optional[RiskCalculationConfig] = None):
        """初始化VaR计算器
        
        Args:
            config: 风险计算配置
        """
        self.config = config or RiskCalculationConfig()
        self.logger = logger
    
    def calculate_var(self, portfolio_data, method: str = 'historical', confidence_level: float = 0.95):
        """计算VaR

        Args:
            portfolio_data: 投资组合数据，包含收益率等信息
            method: 计算方法 ('historical', 'monte_carlo', 'parametric')
            confidence_level: 置信水平

        Returns:
            VaR值
        """
        # 设置置信水平供内部方法使用
        self._confidence_level = confidence_level

        if method == 'historical':
            return self.calculate_historical_var(portfolio_data)
        elif method == 'monte_carlo':
            return self.calculate_monte_carlo_var(portfolio_data)
        elif method == 'parametric':
            return self.calculate_parametric_var(portfolio_data)
        else:
            raise ValueError(f"不支持的VaR计算方法: {method}")
    
    def calculate_historical_var(self, portfolio_data) -> float:
        """历史模拟法计算VaR
        
        Args:
            portfolio_data: 投资组合数据
            
        Returns:
            历史VaR值
        """
        try:
            # 处理不同类型的输入
            if isinstance(portfolio_data, dict):
                returns = portfolio_data.get('returns', [])
            elif isinstance(portfolio_data, np.ndarray):
                returns = portfolio_data
            else:
                returns = portfolio_data

            if returns is None or len(returns) == 0:
                self.logger.warning("收益率数据为空，返回默认VaR")
                return 0.0

            returns_array = np.array(returns)
            # 使用传入的confidence_level参数，如果没有则使用配置中的默认值
            confidence_level = getattr(self, '_confidence_level', self.config.confidence_level)
            
            # 计算分位数
            var = np.percentile(returns_array, (1 - confidence_level) * 100)
            
            self.logger.debug(f"历史VaR计算完成: {var}")
            return abs(var)
            
        except Exception as e:
            self.logger.error(f"历史VaR计算失败: {e}")
            return 0.0
    
    def calculate_monte_carlo_var(self, portfolio_data) -> float:
        """蒙特卡洛模拟法计算VaR
        
        Args:
            portfolio_data: 投资组合数据
            
        Returns:
            蒙特卡洛VaR值
        """
        try:
            # 处理不同类型的输入
            if isinstance(portfolio_data, dict):
                returns = portfolio_data.get('returns', [])
            elif isinstance(portfolio_data, np.ndarray):
                returns = portfolio_data
            else:
                returns = portfolio_data

            if returns is None or len(returns) == 0:
                self.logger.warning("收益率数据为空，返回默认VaR")
                return 0.0

            returns_array = np.array(returns)
            mean = np.mean(returns_array)
            std = np.std(returns_array)

            # 蒙特卡洛模拟
            n_simulations = self.config.monte_carlo_simulations
            simulated_returns = np.random.normal(mean, std, n_simulations)

            # 计算VaR
            confidence_level = getattr(self, '_confidence_level', self.config.confidence_level)
            var = np.percentile(simulated_returns, (1 - confidence_level) * 100)
            
            self.logger.debug(f"蒙特卡洛VaR计算完成: {var}")
            return abs(var)
            
        except Exception as e:
            self.logger.error(f"蒙特卡洛VaR计算失败: {e}")
            return 0.0
    
    def calculate_parametric_var(self, portfolio_data) -> float:
        """参数法(方差-协方差法)计算VaR
        
        Args:
            portfolio_data: 投资组合数据
            
        Returns:
            参数法VaR值
        """
        try:
            # 处理不同类型的输入
            if isinstance(portfolio_data, dict):
                returns = portfolio_data.get('returns', [])
            elif isinstance(portfolio_data, np.ndarray):
                returns = portfolio_data
            else:
                returns = portfolio_data

            if returns is None or len(returns) == 0:
                self.logger.warning("收益率数据为空，返回默认VaR")
                return 0.0

            returns_array = np.array(returns)
            mean = np.mean(returns_array)
            std = np.std(returns_array)
            
            # 获取置信水平对应的Z分数
            from scipy import stats
            confidence_level = getattr(self, '_confidence_level', self.config.confidence_level)
            z_score = stats.norm.ppf(1 - confidence_level)
            
            # 计算VaR
            var = mean + z_score * std
            
            self.logger.debug(f"参数法VaR计算完成: {var}")
            return abs(var)
            
        except Exception as e:
            self.logger.error(f"参数法VaR计算失败: {e}")
            return 0.0
    
    def calculate_cvar(self, portfolio_data, method: str = 'historical', confidence_level: float = 0.95):
        """计算CVaR (Conditional Value at Risk)

        Args:
            portfolio_data: 投资组合数据
            method: 计算方法
            confidence_level: 置信水平

        Returns:
            CVaR值
        """
        try:
            # 设置置信水平供内部使用
            self._confidence_level = confidence_level

            # 先计算VaR
            var = self.calculate_var(portfolio_data, method, confidence_level)

            # 处理不同类型的输入
            if isinstance(portfolio_data, dict):
                returns = portfolio_data.get('returns', [])
            elif isinstance(portfolio_data, np.ndarray):
                returns = portfolio_data
            else:
                returns = portfolio_data

            if returns is None or len(returns) == 0:
                return var

            returns_array = np.array(returns)

            # 计算超过VaR的平均损失
            var_threshold = np.percentile(returns_array, (1 - confidence_level) * 100)

            # CVaR是超过VaR阈值的平均损失
            cvar = np.mean(returns_array[returns_array <= var_threshold])

            self.logger.debug(f"CVaR计算完成: {cvar}")
            return abs(cvar)
            
        except Exception as e:
            self.logger.error(f"CVaR计算失败: {e}")
            return 0.0
    
    def calculate_var_with_confidence_interval(self, 
                                               portfolio_data: Dict[str, Any],
                                               method: str = 'historical') -> RiskCalculationResult:
        """计算VaR并返回置信区间
        
        Args:
            portfolio_data: 投资组合数据
            method: 计算方法
            
        Returns:
            包含VaR值和置信区间的结果对象
        """
        var_value = self.calculate_var(portfolio_data, method)
        
        # 简化的置信区间计算（实际应该使用bootstrap等方法）
        confidence_interval = (var_value * 0.9, var_value * 1.1)
        
        result = RiskCalculationResult(
            metric_type=RiskMetricType.VAR,
            value=var_value,
            confidence_level=self.config.confidence_level,
            calculation_time=0.0,
            timestamp=datetime.now(),
            metadata={
                'method': method,
                'confidence_interval': confidence_interval
            }
        )
        
        return result

