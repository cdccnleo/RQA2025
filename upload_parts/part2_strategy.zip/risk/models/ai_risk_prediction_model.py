import time
#!/usr/bin/env python3
"""
# AI风险预测模型
提供基于机器学习的风险预测和异常检测功误"""

import logging
import numpy as np
import pandas as pd
from typing import Dict, List, Any, Optional, Tuple, Union
from datetime import datetime, timedelta
from dataclasses import dataclass, field
from enum import Enum
import threading
from collections import defaultdict, deque
import json
import pickle
import os
from sklearn.ensemble import RandomForestRegressor, IsolationForest
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
import xgboost as xgb
import lightgbm as lgb
from tensorflow import keras
import tensorflow as tf

logger = logging.getLogger(__name__)


class PredictionModelType(Enum):

    """预测模型类型"""
    RANDOM_FOREST = "random_forest"
    XGBOOST = "xgboost"
    LIGHTGBM = "lightgbm"
    LSTM = "lstm"
    AUTOENCODER = "autoencoder"
    ISOLATION_FOREST = "isolation_forest"


class RiskPredictionType(Enum):

    """风险预测类型"""
    VOLATILITY_FORECAST = "volatility_forecast"      # 波动率预误    DRAWDOWN_PREDICTION = "drawdown_prediction"     # 回撤预测
    # 相关性变化预误    EXTREME_EVENT_RISK = "extreme_event_risk"       # 极端事件风险预测
    CORRELATION_CHANGE = "correlation_change"
    # 流动性风险预误    MARKET_IMPACT = "market_impact"                 # 市场冲击预测
    LIQUIDITY_RISK = "liquidity_risk"


@dataclass
class PredictionModelConfig:

    """预测模型配置"""
    model_type: PredictionModelType = PredictionModelType.RANDOM_FOREST
    prediction_horizon: int = 1  # 预测时间跨度（天）
    training_window: int = 252   # 训练窗口（天）
    feature_window: int = 60     # 特征窗口（天）
    confidence_level: float = 0.95
    enable_feature_selection: bool = True
    enable_hyperparameter_tuning: bool = True
    max_features: int = 50
    random_state: int = 42


@dataclass
class PredictionResult:

    """预测结果"""
    prediction_type: RiskPredictionType
    predicted_value: float
    confidence_interval: Tuple[float, float]
    prediction_timestamp: datetime
    model_accuracy: float
    feature_importance: Dict[str, float] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class RiskPredictionData:

    """风险预测数据"""
    timestamp: datetime
    features: Dict[str, float]
    actual_risk_value: Optional[float] = None
    predicted_risk_value: Optional[float] = None
    prediction_error: Optional[float] = None


class AIRiskPredictionModel:

    """AI风险预测模型"""

    def __init__(self, config: Optional[PredictionModelConfig] = None):

        self.config = config or PredictionModelConfig()
        self.models = {}
        self.scalers = {}
        self.feature_selectors = {}
        self.training_data = defaultdict(lambda: deque(maxlen=1000))
        self.prediction_history = defaultdict(lambda: deque(maxlen=500))
        self.lock = threading.RLock()

        # 初始化模型
        self._initialize_models()

        logger.info(f"AI风险预测模型初始化完成，模型类型: {self.config.model_type}")

    def _initialize_models(self):
        """初始化预测模型"""
        for prediction_type in RiskPredictionType:
            self.models[prediction_type] = None
            self.scalers[prediction_type] = StandardScaler()
            self.feature_selectors[prediction_type] = None

    def train_model(self, prediction_type: RiskPredictionType,

    historical_data: List[RiskPredictionData],
    target_column: str = 'actual_risk_value') -> Dict[str, Any]:
        """
        训练预测模型

        Args:
            prediction_type: 预测类型
            historical_data: 历史数据
            target_column: 目标列名

        Returns:
            训练结果统计
        """
        try:
            logger.info(f"开始训练{prediction_type.value}模型")

            # 准备训练数据
            df = self._prepare_training_data(historical_data, target_column)
            if df.empty:
                raise ValueError("训练数据为空")

            # 特征选择
            if self.config.enable_feature_selection:
                df = self._select_features(df, prediction_type)

            # 分割训练和测试集
            X = df.drop(columns=[target_column])
            y = df[target_column]

            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=0.2, random_state=self.config.random_state, shuffle=False
            )

            # 标准化特征
            X_train_scaled = self.scalers[prediction_type].fit_transform(X_train)
            X_test_scaled = self.scalers[prediction_type].transform(X_test)

            # 训练模型
            model = self._create_model(prediction_type)
            model.fit(X_train_scaled, y_train)

            # 评估模型
            y_pred = model.predict(X_test_scaled)
            mse = mean_squared_error(y_test, y_pred)
            r2 = r2_score(y_test, y_pred)

            # 保存模型
            self.models[prediction_type] = model

            # 计算特征重要性
            feature_importance = self._calculate_feature_importance(
                model, X.columns.tolist(), prediction_type
            )

            training_stats = {
                'model_type': self.config.model_type.value,
                'training_samples': len(X_train),
                'test_samples': len(X_test),
                'mse': mse,
                'r2_score': r2,
                'feature_importance': feature_importance,
                'training_timestamp': datetime.now()
            }
            logger.info(f"模型训练完成: MSE={mse:.6f}, R²={r2:.4f}")
            return training_stats

        except Exception as e:
            logger.error(f"模型训练失败: {e}")
            raise


    def predict_risk(self, prediction_type: RiskPredictionType,
                      current_data: Dict[str, Any]) -> PredictionResult:
        """预测风险
        Args:
            prediction_type: 预测类型
            current_data: 当前数据

        Returns:
            预测结果
        """
        with self.lock:
            try:
                model = self.models.get(prediction_type)
                if model is None:
                    raise ValueError(f"模型{prediction_type.value}未训练")

                # 特征工程
                features = self._extract_features(current_data)
                features_df = pd.DataFrame([features])

                # 特征选择
                if self.config.enable_feature_selection:
                    features_df = self._apply_feature_selection(
                        features_df, prediction_type
                    )

                # 标准化
                features_scaled = self.scalers[prediction_type].transform(features_df)

                # 预测
                prediction = model.predict(features_scaled)[0]

                # 计算置信区间
                confidence_interval = self._calculate_confidence_interval(
                    model, features_scaled, prediction_type
                )

                # 创建预测结果
                result = PredictionResult(
                    prediction_type=prediction_type,
                    predicted_value=float(prediction),
                    confidence_interval=confidence_interval,
                    prediction_timestamp=datetime.now(),
                    model_accuracy=self._get_model_accuracy(prediction_type),
                    feature_importance=self._calculate_feature_importance(
                        model, features_df.columns.tolist(), prediction_type
                    ),
                    metadata={
                        'model_type': self.config.model_type.value,
                        'feature_count': len(features),
                        'prediction_horizon': self.config.prediction_horizon
                    }
                )

                # 保存预测历史
                prediction_data = RiskPredictionData(
                    timestamp=datetime.now(),
                    features=features,
                    predicted_risk_value=result.predicted_value
                )
                self.prediction_history[prediction_type].append(prediction_data)

                return result

            except Exception as e:
                logger.error(f"风险预测失败: {e}")
                raise


    def _prepare_training_data(self, historical_data: List[RiskPredictionData],
                               target_column: str) -> pd.DataFrame:
        """准备训练数据"""
        try:
            records = []
            for data in historical_data:
                if data.actual_risk_value is not None:
                    record = data.features.copy()
                    record[target_column] = data.actual_risk_value
                    records.append(record)

            df = pd.DataFrame(records)

            # 处理缺失值
            df = df.fillna(method='ffill').fillna(0)

            return df

        except Exception as e:
            logger.error(f"准备训练数据失败: {e}")
            return pd.DataFrame()


    def _select_features(self, df: pd.DataFrame,
                         prediction_type: RiskPredictionType) -> pd.DataFrame:
        """特征选择"""
        try:
            # 使用随机森林进行特征重要性排序
            if df.shape[1] > self.config.max_features:
                rf = RandomForestRegressor(
                    n_estimators=100,
                    random_state=self.config.random_state,
                    n_jobs=-1
                )

                X = df.drop(columns=['actual_risk_value'])
                y = df['actual_risk_value']

                rf.fit(X, y)
                feature_importance = dict(zip(X.columns, rf.feature_importances_))

                # 选择最重要的特征
                sorted_features = sorted(
                    feature_importance.items(),
                    key=lambda x: x[1],
                    reverse=True
                )[:self.config.max_features]

                selected_features = [f[0] for f in sorted_features]
                selected_features.append('actual_risk_value')

                # 保存特征选择器
                self.feature_selectors[prediction_type] = selected_features

                return df[selected_features]

            return df

        except Exception as e:
            logger.error(f"特征选择失败: {e}")
            return df


    def _apply_feature_selection(self, features_df: pd.DataFrame,
                                 prediction_type: RiskPredictionType) -> pd.DataFrame:
        """应用特征选择"""
        try:
            selected_features = self.feature_selectors.get(prediction_type)
            if selected_features:
                available_features = [f for f in selected_features
                                     if f in features_df.columns]
                return features_df[available_features]
            return features_df

        except Exception as e:
            logger.error(f"应用特征选择失败: {e}")
            return features_df


    def _create_model(self, prediction_type: RiskPredictionType):
        """创建预测模型"""
        try:
            if self.config.model_type == PredictionModelType.RANDOM_FOREST:
                return RandomForestRegressor(
                    n_estimators=200,
                    max_depth=10,
                    min_samples_split=5,
                    min_samples_leaf=2,
                    random_state=self.config.random_state,
                    n_jobs=-1
                )

            elif self.config.model_type == PredictionModelType.XGBOOST:
                return xgb.XGBRegressor(
                    n_estimators=200,
                    max_depth=6,
                    learning_rate=0.1,
                    subsample=0.8,
                    colsample_bytree=0.8,
                    random_state=self.config.random_state,
                    n_jobs=-1
                )

            elif self.config.model_type == PredictionModelType.LIGHTGBM:
                return lgb.LGBMRegressor(
                    n_estimators=200,
                    max_depth=6,
                    learning_rate=0.1,
                    subsample=0.8,
                    colsample_bytree=0.8,
                    random_state=self.config.random_state,
                    n_jobs=-1,
                    verbose=-1
                )

            elif self.config.model_type == PredictionModelType.ISOLATION_FOREST:
                return IsolationForest(
                    n_estimators=100,
                    contamination=0.1,
                    random_state=self.config.random_state,
                    n_jobs=-1
                )

            else:
                raise ValueError(f"不支持的模型类型: {self.config.model_type}")

            return None

        except Exception as e:
            logger.error(f"创建模型失败: {e}")
            raise


    def _extract_features(self, current_data: Dict[str, Any]) -> Dict[str, float]:
        """特征工程"""
        try:
            features = {}

            # 基础价格特征
            if 'price' in current_data:
                features['price'] = current_data['price']
                features['price_change'] = current_data.get('price_change', 0)
                features['price_volatility'] = current_data.get('price_volatility', 0)

            # 交易量特征
            if 'volume' in current_data:
                features['volume'] = current_data['volume']
                features['volume_change'] = current_data.get('volume_change', 0)

            # 技术指标特征
            technical_indicators = current_data.get('technical_indicators', {})
            for indicator, value in technical_indicators.items():
                features[f'tech_{indicator}'] = value

            # 市场特征
            market_data = current_data.get('market_data', {})
            for market_key, market_value in market_data.items():
                features[f'market_{market_key}'] = market_value

            # 时间特征
            if 'timestamp' in current_data:
                timestamp = current_data['timestamp']
                if isinstance(timestamp, str):
                    timestamp = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))

                features['hour_of_day'] = timestamp.hour
                features['day_of_week'] = timestamp.weekday()
                features['month_of_year'] = timestamp.month

            return features

        except Exception as e:
            logger.error(f"特征工程失败: {e}")
            return {}


    def _calculate_confidence_interval(self, model, features_scaled: np.ndarray,
                                       prediction_type: RiskPredictionType) -> Tuple[float, float]:
        """计算置信区间"""
        try:
            # 使用bootstrap方法估算置信区间
            n_bootstrap = 100
            predictions = []

            for _ in range(n_bootstrap):
                # 从训练数据中随机采样
                indices = np.secrets.choice(
                    len(features_scaled), len(features_scaled), replace=True)
                sample_features = features_scaled[indices]

                pred = model.predict(sample_features)
                predictions.append(np.mean(pred))

            predictions = np.array(predictions)
            lower_bound = np.percentile(predictions, (1 - self.config.confidence_level) * 100 / 2)
            upper_bound = np.percentile(
                predictions, 100 - (1 - self.config.confidence_level) * 100 / 2)

            return float(lower_bound), float(upper_bound)

        except Exception as e:
            logger.error(f"计算置信区间失败: {e}")
            return 0.0, 0.0


    def _calculate_feature_importance(self, model, feature_names: List[str],
                                       prediction_type: RiskPredictionType) -> Dict[str, float]:
        """计算特征重要性"""
        try:
            importance_dict = {}

            if hasattr(model, 'feature_importances_'):
                importances = model.feature_importances_
                importance_dict = dict(zip(feature_names, importances))
            elif hasattr(model, 'coef_'):
                # 线性模型的系数
                coef = model.coef_
                if len(coef) == len(feature_names):
                    importance_dict = dict(zip(feature_names, np.abs(coef)))
                else:
                    # 默认相等重要性
                    importance = 1.0 / len(feature_names)
                    importance_dict = {name: importance for name in feature_names}

            return importance_dict

        except Exception as e:
            logger.error(f"计算特征重要性失败: {e}")
            return {}


    def _get_model_accuracy(self, prediction_type: RiskPredictionType) -> float:
        """获取模型准确率"""
        try:
            # 这里应该从模型评估历史中获取准确率
            # 暂时返回默认值
            return 0.85

        except Exception as e:
            logger.error(f"获取模型准确率失败: {e}")
            return 0.0


    def get_model_status(self) -> Dict[str, Any]:

        """获取模型状态"""
        with self.lock:
            status = {
                'model_type': self.config.model_type.value,
                'prediction_horizon': self.config.prediction_horizon,
                'trained_models': [],
                'model_performance': {},
                'last_update': datetime.now().isoformat()
            }

            for prediction_type in RiskPredictionType:
                if self.models[prediction_type] is not None:
                    status['trained_models'].append(prediction_type.value)
                    # 这里可以添加模型性能指标

            return status


    def save_models(self, directory: str = "models/risk_prediction"):
        """保存模型"""
        try:
            os.makedirs(directory, exist_ok=True)

            for prediction_type, model in self.models.items():
                if model is not None:
                    model_path = os.path.join(directory, f"{prediction_type.value}_model.pkl")
                    with open(model_path, 'wb') as f:
                        pickle.dump(model, f)

                    scaler_path = os.path.join(directory, f"{prediction_type.value}_scaler.pkl")
                    with open(scaler_path, 'wb') as f:
                        pickle.dump(self.scalers[prediction_type], f)

            logger.info(f"模型已保存到目录: {directory}")

        except Exception as e:
            logger.error(f"保存模型失败: {e}")
            raise


    def load_models(self, directory: str = "models/risk_prediction"):
        """加载模型"""
        try:
            for prediction_type in RiskPredictionType:
                model_path = os.path.join(directory, f"{prediction_type.value}_model.pkl")
                scaler_path = os.path.join(directory, f"{prediction_type.value}_scaler.pkl")

                if os.path.exists(model_path):
                    with open(model_path, 'rb') as f:
                        self.models[prediction_type] = pickle.load(f)

                    with open(scaler_path, 'rb') as f:
                        self.scalers[prediction_type] = pickle.load(f)

            logger.info(f"模型已从目录加载: {directory}")

        except Exception as e:
            logger.error(f"加载模型失败: {e}")
            raise
