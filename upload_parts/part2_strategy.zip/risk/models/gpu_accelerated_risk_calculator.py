#!/usr/bin/env python3
"""
GPU加速风险计算器

利用GPU并行计算提升风险计算性能，支持蒙特卡洛模拟、矩阵运算等
"""

import logging
import numpy as np
from typing import Dict, List, Any, Optional
from datetime import datetime
from dataclasses import dataclass, field
from enum import Enum
import threading
from collections import defaultdict, deque
import time

logger = logging.getLogger(__name__)

# 尝试导入GPU计算库
try:
    import cupy as cp
    CUPY_AVAILABLE = True
    logger.info("CuPy GPU计算库可用")
except ImportError:
    CUPY_AVAILABLE = False
    logger.warning("CuPy不可用，将使用CPU模式")

try:
    from numba import cuda
    NUMBA_CUDA_AVAILABLE = True
    logger.info("Numba CUDA可用")
except ImportError:
    NUMBA_CUDA_AVAILABLE = False
logger.warning("Numba CUDA不可用，将使用CPU模式")

try:
    import torch
    import torch.cuda
    PYTORCH_CUDA_AVAILABLE = torch.cuda.is_available()
    TORCH_AVAILABLE = True
    logger.info("PyTorch可用")
except ImportError:
    PYTORCH_CUDA_AVAILABLE = False
    TORCH_AVAILABLE = False
    logger.warning("PyTorch不可用，将使用CPU模式")
    if PYTORCH_CUDA_AVAILABLE:
        logger.info("PyTorch CUDA可用")
    else:
        logger.warning("PyTorch CUDA不可用，将使用CPU模式")


class GPUBackend(Enum):

    """GPU后端类型"""
    CUPY = "cupy"
    NUMBA_CUDA = "numba_cuda"
    PYTORCH = "pytorch"
    CPU = "cpu"


class ComputationType(Enum):

    """计算类型"""
    MONTE_CARLO = "monte_carlo"          # 蒙特卡洛模拟
    MATRIX_OPERATIONS = "matrix_ops"     # 矩阵运算
    VECTOR_OPERATIONS = "vector_ops"     # 向量运算
    STATISTICAL_CALC = "statistical"     # 统计计算


@dataclass
class GPUConfig:

    """GPU配置"""
    backend: GPUBackend = GPUBackend.CPU
    device_id: int = 0
    memory_limit: float = 0.8  # 使用GPU内存误0%
    enable_memory_pool: bool = True
    enable_async_compute: bool = True
    thread_block_size: int = 256
    grid_size_multiplier: int = 4
    enable_profiling: bool = False


@dataclass
class ComputationResult:

    """计算结果"""
    computation_type: ComputationType
    result_data: Any
    computation_time: float
    gpu_memory_used: float
    backend_used: GPUBackend
    timestamp: datetime = field(default_factory=datetime.now)
    metadata: Dict[str, Any] = field(default_factory=dict)


class GPUAcceleratedRiskCalculator:

    """GPU加速风险计算器"""

    def __init__(self, config: Optional[GPUConfig] = None):

        self.config = config or GPUConfig()
        self.lock = threading.RLock()

        # 计算结果缓存
        self.computation_cache = defaultdict(lambda: deque(maxlen=1000))
        self.performance_stats = defaultdict(list)

        # GPU资源管理
        self.gpu_available = self._check_gpu_availability()
        self.memory_pool = None

        # 初始化GPU后端
        self._initialize_gpu_backend()

        logger.info(f"GPU加速风险计算器初始化完成，后端: {self.config.backend.value}")

    def _check_gpu_availability(self) -> bool:
        """检查GPU可用性"""
        try:
            if self.config.backend == GPUBackend.CUPY and CUPY_AVAILABLE:
                return cp.cuda.is_available()
            elif self.config.backend == GPUBackend.PYTORCH and PYTORCH_CUDA_AVAILABLE:
                return torch.cuda.is_available()
            elif self.config.backend == GPUBackend.NUMBA_CUDA and NUMBA_CUDA_AVAILABLE:
                return cuda.is_available()
            return False
        except Exception as e:
            logger.error(f"GPU可用性检查失败 {e}")
            return False

    def _initialize_gpu_backend(self):
        """初始化GPU后端"""
        try:
            if not self.gpu_available:
                logger.warning("GPU不可用，使用CPU模式")
                self.config.backend = GPUBackend.CPU
                return

            if self.config.backend == GPUBackend.CUPY and CUPY_AVAILABLE:
                self._initialize_cupy()
            elif self.config.backend == GPUBackend.PYTORCH and PYTORCH_CUDA_AVAILABLE:
                self._initialize_pytorch()
            elif self.config.backend == GPUBackend.NUMBA_CUDA and NUMBA_CUDA_AVAILABLE:
                self._initialize_numba_cuda()
            else:
                logger.warning("指定GPU后端不可用，切换到CPU模式")
                self.config.backend = GPUBackend.CPU

        except Exception as e:
            logger.error(f"GPU后端初始化失败 {e}")
            self.config.backend = GPUBackend.CPU

    def _initialize_cupy(self):
        """初始化CuPy后端"""
        try:
            cp.cuda.Device(self.config.device_id).use()

            if self.config.enable_memory_pool:
                # 设置内存池
                self.memory_pool = cp.cuda.MemoryPool()
                cp.cuda.set_allocator(self.memory_pool.malloc)

            logger.info(f"CuPy后端初始化完成，设备ID: {self.config.device_id}")

        except Exception as e:
            logger.error(f"CuPy初始化失败 {e}")
            raise

    def _initialize_pytorch(self):
        """初始化PyTorch后端"""
        try:
            torch.cuda.set_device(self.config.device_id)
            torch.backends.cudnn.benchmark = True
            logger.info(f"PyTorch后端初始化完成，设备ID: {self.config.device_id}")

        except Exception as e:
            logger.error(f"PyTorch初始化失败 {e}")
            raise

    def _initialize_numba_cuda(self):
        """初始化Numba CUDA后端"""
        try:
            cuda.select_device(self.config.device_id)
            logger.info(f"Numba CUDA后端初始化完成，设备ID: {self.config.device_id}")

        except Exception as e:
            logger.error(f"Numba CUDA初始化失败 {e}")
            raise

    def monte_carlo_var_calculation(self, returns: np.ndarray, positions: np.ndarray,

                                    confidence_level: float = 0.95,
                                    n_simulations: int = 10000) -> ComputationResult:
        """
    GPU加速蒙特卡洛VaR计算

    Args:
            returns: 历史收益率数误(n_assets, n_periods)
    positions: 持仓权重 (n_assets,)
    confidence_level: 置信水平
    n_simulations: 模拟次数

    Returns:
            计算结果
        """
        start_time = time.time()

        try:
            if self.config.backend == GPUBackend.CUPY and CUPY_AVAILABLE:
                return self._cupy_monte_carlo_var(returns, positions, confidence_level, n_simulations, start_time)
            elif self.config.backend == GPUBackend.PYTORCH and PYTORCH_CUDA_AVAILABLE:
                return self._pytorch_monte_carlo_var(returns, positions, confidence_level, n_simulations, start_time)
            else:
                return self._cpu_monte_carlo_var(returns, positions, confidence_level, n_simulations, start_time)

        except Exception as e:
            logger.error(f"蒙特卡洛VaR计算失败: {e}")
            return self._cpu_monte_carlo_var(returns, positions, confidence_level, n_simulations, start_time)

    def _cupy_monte_carlo_var(self, returns: np.ndarray, positions: np.ndarray,

                              confidence_level: float, n_simulations: int,
                              start_time: float) -> ComputationResult:
        """CuPy实现的蒙特卡洛VaR计算"""
        try:
            # 数据预处理
            returns_gpu = cp.asarray(returns)
            positions_gpu = cp.asarray(positions)

            # 计算协方差矩阵
            cov_matrix = cp.cov(returns_gpu)

            # Cholesky分解用于生成相关随机数
            try:
                L = cp.linalg.cholesky(cov_matrix)
            except cp.linalg.LinAlgError:
                # 如果协方差矩阵不是正定的，使用特征值分解
                eigenvalues, eigenvectors = cp.linalg.eigh(cov_matrix)
                eigenvalues = cp.maximum(eigenvalues, 0)  # 确保非负
                L = eigenvectors @ cp.sqrt(cp.diag(eigenvalues))

            # 生成随机数
            n_assets = len(positions)
            random_matrix = cp.secrets.normal(0, 1, (n_simulations, n_assets))

            # 生成相关随机收益
            correlated_returns = random_matrix @ L.T

            # 计算组合收益
            portfolio_returns = correlated_returns @ positions_gpu

            # 计算VaR
            var_percentile = (1 - confidence_level) * 100
            var_value = cp.percentile(portfolio_returns, var_percentile)

            # 计算预期 shortfall (CVaR)
            tail_returns = portfolio_returns[portfolio_returns <= var_value]
            cvar_value = cp.mean(tail_returns) if len(tail_returns) > 0 else var_value

            # 结果转换回CPU
            result_data = {
                'var': float(var_value),
                'cvar': float(cvar_value),
                'confidence_level': confidence_level,
                'n_simulations': n_simulations,
                'portfolio_returns_sample': cp.asnumpy(portfolio_returns[:1000])  # 只返回样本
            }

            computation_time = time.time() - start_time

            return ComputationResult(
                computation_type=ComputationType.MONTE_CARLO,
                result_data=result_data,
                computation_time=computation_time,
                gpu_memory_used=self._get_gpu_memory_usage(),
                backend_used=GPUBackend.CUPY,
                metadata={
                    'n_assets': n_assets,
                    'matrix_shape': cov_matrix.shape,
                    'gpu_device': self.config.device_id
                }
            )

        except Exception as e:
            logger.error(f"CuPy蒙特卡洛计算失败: {e}")
            raise

    def _pytorch_monte_carlo_var(self, returns: np.ndarray, positions: np.ndarray,

                                 confidence_level: float, n_simulations: int,
                                 start_time: float) -> ComputationResult:
        """PyTorch实现的蒙特卡洛VaR计算"""
        try:
            device = torch.device(f'cuda:{self.config.device_id}')

            # 数据预处理
            returns_tensor = torch.from_numpy(returns).float().to(device)
            positions_tensor = torch.from_numpy(positions).float().to(device)

            # 计算协方差矩阵
            cov_matrix = torch.cov(returns_tensor)

            # Cholesky分解
            try:
                L = torch.linalg.cholesky(cov_matrix)
            except RuntimeError:
                # 使用SVD分解作为备用
                U, S, V = torch.svd(cov_matrix)
                L = U @ torch.sqrt(torch.diag(S))

            # 生成随机数
            n_assets = len(positions)
            random_matrix = torch.randn(n_simulations, n_assets, device=device)

            # 生成相关随机收益
            correlated_returns = random_matrix @ L.T

            # 计算组合收益
            portfolio_returns = correlated_returns @ positions_tensor

            # 计算VaR
            var_percentile = int((1 - confidence_level) * n_simulations)
            sorted_returns, _ = torch.sort(portfolio_returns)
            var_value = sorted_returns[var_percentile]

            # 计算CVaR
            tail_returns = sorted_returns[:var_percentile]
            cvar_value = torch.mean(tail_returns) if len(tail_returns) > 0 else var_value

            result_data = {
                'var': float(var_value.cpu()),
                'cvar': float(cvar_value.cpu()),
                'confidence_level': confidence_level,
                'n_simulations': n_simulations,
                'portfolio_returns_sample': portfolio_returns[:1000].cpu().numpy()
            }

            computation_time = time.time() - start_time

            return ComputationResult(
                computation_type=ComputationType.MONTE_CARLO,
                result_data=result_data,
                computation_time=computation_time,
                gpu_memory_used=self._get_gpu_memory_usage(),
                backend_used=GPUBackend.PYTORCH,
                metadata={
                    'n_assets': n_assets,
                    'matrix_shape': cov_matrix.shape,
                    'gpu_device': self.config.device_id
                }
            )

        except Exception as e:
            logger.error(f"PyTorch蒙特卡洛计算失败: {e}")
            raise

    def _cpu_monte_carlo_var(self, returns: np.ndarray, positions: np.ndarray,
                             confidence_level: float, n_simulations: int,
                             start_time: float) -> ComputationResult:
        # CPU备选实现
        try:
            # 计算协方差矩阵
            cov_matrix = np.cov(returns)

            # Cholesky分解
            try:
                L = np.linalg.cholesky(cov_matrix)
            except np.linalg.LinAlgError:
                eigenvalues, eigenvectors = np.linalg.eigh(cov_matrix)
                eigenvalues = np.maximum(eigenvalues, 0)
                L = eigenvectors @ np.sqrt(np.diag(eigenvalues))

            # 生成随机数
            n_assets = len(positions)
            random_matrix = np.secrets.normal(0, 1, (n_simulations, n_assets))

            # 生成相关随机收益
            correlated_returns = random_matrix @ L.T

            # 计算组合收益
            portfolio_returns = correlated_returns @ positions

            # 计算VaR
            var_percentile = (1 - confidence_level) * 100
            var_value = np.percentile(portfolio_returns, var_percentile)

            # 计算CVaR
            tail_returns = portfolio_returns[portfolio_returns <= var_value]
            cvar_value = np.mean(tail_returns) if len(tail_returns) > 0 else var_value

            result_data = {
                'var': float(var_value),
                'cvar': float(cvar_value),
                'confidence_level': confidence_level,
                'n_simulations': n_simulations,
                'portfolio_returns_sample': portfolio_returns[:1000]
            }

            computation_time = time.time() - start_time

            return ComputationResult(
                computation_type=ComputationType.MONTE_CARLO,
                result_data=result_data,
                computation_time=computation_time,
                gpu_memory_used=0.0,
                backend_used=GPUBackend.CPU,
                metadata={
                    'n_assets': n_assets,
                    'matrix_shape': cov_matrix.shape
                }
            )

        except Exception as e:
            logger.error(f"CPU蒙特卡洛计算失败: {e}")
            raise

    def matrix_operations_accelerated(self, matrices: List[np.ndarray], operation: str = "eigenvalues") -> ComputationResult:
        start_time = time.time()

        try:
            if self.config.backend == GPUBackend.CUPY and CUPY_AVAILABLE:
                return self._cupy_matrix_operations(matrices, operation, start_time)
            elif self.config.backend == GPUBackend.PYTORCH and PYTORCH_CUDA_AVAILABLE:
                return self._pytorch_matrix_operations(matrices, operation, start_time)
            else:
                return self._cpu_matrix_operations(matrices, operation, start_time)

        except Exception as e:
            logger.error(f"矩阵运算失败: {e}")
            return self._cpu_matrix_operations(matrices, operation, start_time)

    def _cupy_matrix_operations(self, matrices: List[np.ndarray], operation: str,
                                start_time: float) -> ComputationResult:
        # Temporary implementation
        return ComputationResult(
            computation_type=ComputationType.MATRIX_OPERATIONS,
            result_data={},
            computation_time=time.time() - start_time,
            gpu_memory_used=0.0,
            backend_used=GPUBackend.CUPY,
            metadata={}
        )

    def _pytorch_matrix_operations(self, matrices: List[np.ndarray], operation: str,
                                   start_time: float) -> ComputationResult:
        # PyTorch实现的矩阵运算
        try:
            device = torch.device(f'cuda:{self.config.device_id}')

            # 将矩阵转换为PyTorch张量
            torch_matrices = [torch.from_numpy(matrix).float().to(device) for matrix in matrices]

            results = {}
            if operation == "eigenvalues":
                for i, matrix in enumerate(torch_matrices):
                    eigenvalues, eigenvectors = torch.linalg.eigh(matrix)
                    results[f'matrix_{i}'] = {
                        'eigenvalues': eigenvalues.cpu().numpy(),
                        'eigenvectors': eigenvectors.cpu().numpy()
                    }

            elif operation == "svd":
                for i, matrix in enumerate(torch_matrices):
                    U, S, V = torch.linalg.svd(matrix)
                    results[f'matrix_{i}'] = {
                        'U': U.cpu().numpy(),
                        'S': S.cpu().numpy(),
                        'V': V.cpu().numpy()
                    }

            elif operation == "inverse":
                for i, matrix in enumerate(torch_matrices):
                    inverse = torch.linalg.inv(matrix)
                    results[f'matrix_{i}'] = inverse.cpu().numpy()

            elif operation == "multiply":
                if len(torch_matrices) >= 2:
                    result = torch_matrices[0]
                    for matrix in torch_matrices[1:]:
                        result = torch.matmul(result, matrix)
                    results['product'] = result.cpu().numpy()

            computation_time = time.time() - start_time

            return ComputationResult(
                computation_type=ComputationType.MATRIX_OPERATIONS,
                result_data=results,
                computation_time=computation_time,
                gpu_memory_used=self._get_gpu_memory_usage(),
                backend_used=GPUBackend.PYTORCH,
                metadata={
                    'operation': operation,
                    'n_matrices': len(matrices),
                    'matrix_shapes': [m.shape for m in matrices]
                }
            )

        except Exception as e:
            logger.error(f"PyTorch矩阵运算失败: {e}")
            raise

    def _cpu_matrix_operations(self, matrices: List[np.ndarray], operation: str,
                               start_time: float) -> ComputationResult:
        # CPU备选实现
        try:
            results = {}
            if operation == "eigenvalues":
                for i, matrix in enumerate(matrices):
                    eigenvalues, eigenvectors = np.linalg.eigh(matrix)
                    results[f'matrix_{i}'] = {
                        'eigenvalues': eigenvalues,
                        'eigenvectors': eigenvectors
                    }

            elif operation == "svd":
                for i, matrix in enumerate(matrices):
                    U, S, V = np.linalg.svd(matrix)
                    results[f'matrix_{i}'] = {
                        'U': U,
                        'S': S,
                        'V': V
                    }

            elif operation == "inverse":
                for i, matrix in enumerate(matrices):
                    inverse = np.linalg.inv(matrix)
                    results[f'matrix_{i}'] = inverse

            elif operation == "multiply":
                result = matrices[0]
                for matrix in matrices[1:]:
                    result = np.matmul(result, matrix)
                results['product'] = result

            computation_time = time.time() - start_time

            return ComputationResult(
                computation_type=ComputationType.MATRIX_OPERATIONS,
                result_data=results,
                computation_time=computation_time,
                gpu_memory_used=0.0,
                backend_used=GPUBackend.CPU,
                metadata={
                    'operation': operation,
                    'n_matrices': len(matrices),
                    'matrix_shapes': [m.shape for m in matrices]
                }
            )

        except Exception as e:
            logger.error(f"CPU矩阵运算失败: {e}")
            raise

    def batch_risk_calculation(self, portfolio_list: List[Dict[str, Any]],
                               risk_types: List[str] = None) -> List[ComputationResult]:
        """
        批量风险计算

        Args:
            portfolio_list: 组合列表
            risk_types: 风险类型列表

        Returns:
            计算结果列表
        """
        if risk_types is None:
            risk_types = ['var', 'volatility', 'sharpe_ratio']

        results = []

        try:
            # 并行处理多个组合
            for portfolio_data in portfolio_list:
                portfolio_result = {}

                # 提取投资组合数据
                positions = portfolio_data.get('positions', {})
                prices = portfolio_data.get('prices', {})

                if not positions or not prices:
                    continue

                # 转换为numpy数组
                asset_symbols = list(positions.keys())
                position_values = np.array([positions[symbol] * prices.get(symbol, 0)
                                           for symbol in asset_symbols])

                # 计算权重
                total_value = np.sum(position_values)
                if total_value == 0:
                    continue

                weights = position_values / total_value

                # 模拟历史收益率数据（实际应用中应该使用真实数据）
                n_periods = 252  # 一年的交易日
                n_assets = len(asset_symbols)

                # 生成模拟的收益率数据
                np.random.seed(42)  # 确保可重复性
                returns_data = np.secrets.normal(0.0005, 0.02, (n_assets, n_periods))

                # 计算各种风险指标
                for risk_type in risk_types:
                    try:
                        if risk_type == 'var':
                            result = self.monte_carlo_var_calculation(
                                returns_data, weights, 0.95, 10000
                            )
                            portfolio_result['var'] = result.result_data['var']

                        elif risk_type == 'volatility':
                            # 计算组合波动率
                            cov_matrix = np.cov(returns_data)
                            portfolio_volatility = np.sqrt(weights.T @ cov_matrix @ weights)
                            portfolio_result['volatility'] = float(portfolio_volatility)

                        elif risk_type == 'sharpe_ratio':
                            # 计算夏普比率（简化版）
                            expected_return = np.mean(returns_data, axis=1) @ weights
                            volatility = portfolio_result.get('volatility', 0.02)
                            risk_free_rate = 0.02  # 无风险利率
                            sharpe = (expected_return - risk_free_rate) / \
                                volatility if volatility > 0 else 0
                            portfolio_result['sharpe_ratio'] = float(sharpe)

                    except Exception as e:
                        logger.error(f"计算{risk_type}失败: {e}")
                        continue

                # 创建批量结果
                batch_result = ComputationResult(
                    computation_type=ComputationType.STATISTICAL_CALC,
                    result_data={
                        'portfolio_id': portfolio_data.get('portfolio_id', 'unknown'),
                        'risk_metrics': portfolio_result,
                        'n_assets': n_assets,
                        'total_value': float(total_value)
                    },
                    computation_time=0.0,  # 批量计算的总时间
                    gpu_memory_used=self._get_gpu_memory_usage(),
                    backend_used=self.config.backend,
                    metadata={
                        'batch_size': len(portfolio_list),
                        'risk_types': risk_types
                    }
                )

                results.append(batch_result)

        except Exception as e:
            logger.error(f"批量风险计算失败: {e}")

            return results

    def _get_gpu_memory_usage(self) -> float:
        """获取GPU内存使用情况"""
        try:
            if self.config.backend == GPUBackend.CUPY and CUPY_AVAILABLE:
                mem_info = cp.cuda.runtime.memGetInfo()
                return (mem_info[1] - mem_info[0]) / mem_info[1]  # 已使用比例
            elif self.config.backend == GPUBackend.PYTORCH and PYTORCH_CUDA_AVAILABLE:
                return torch.cuda.memory_allocated() / torch.cuda.max_memory_allocated()
            else:
                return 0.0
        except Exception:
            return 0.0

    def get_performance_stats(self) -> Dict[str, Any]:
        """获取性能统计信息"""
        try:
            stats = {}
            for computation_type in ComputationType:
                if computation_type.value in self.performance_stats:
                    times = self.performance_stats[computation_type.value]
                    if times:
                        stats[computation_type.value] = {
                            'count': len(times),
                            'avg_time': np.mean(times),
                            'min_time': np.min(times),
                            'max_time': np.max(times),
                            'median_time': np.median(times)
                        }

            return {
                'gpu_available': self.gpu_available,
                'backend': self.config.backend.value,
                'device_id': self.config.device_id,
                'performance_stats': stats,
                'cache_size': len(self.computation_cache),
                'timestamp': datetime.now().isoformat()
            }

        except Exception as e:
            logger.error(f"获取性能统计失败: {e}")
            return {}

    def clear_cache(self):
        """清空计算缓存"""
        with self.lock:
            self.computation_cache.clear()
        logger.info("GPU计算缓存已清空")

    def optimize_gpu_settings(self):
        """优化GPU设置"""
        try:
            if self.config.backend == GPUBackend.CUPY and CUPY_AVAILABLE:
                # 优化CuPy设置
                cp.cuda.set_allocator(cp.cuda.MemoryPool().malloc)

            elif self.config.backend == GPUBackend.PYTORCH and PYTORCH_CUDA_AVAILABLE:
                # 优化PyTorch设置
                torch.backends.cudnn.benchmark = True
                torch.backends.cudnn.enabled = True

            logger.info("GPU设置已优化")

        except Exception as e:
            logger.error(f"GPU设置优化失败: {e}")
