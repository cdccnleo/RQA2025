# Define missing variables
from concurrent.futures import ThreadPoolExecutor, as_completed
from enum import Enum
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Callable
import logging
import numpy as np
import os
import sys
import json
import time
from src.backtest.engine import Backtester


backtester = None
returns = None
test_results = None
var_performance = None
var_sensitivity = None


#!/usr/bin/env python3
"""
# 风险模型测试和验误
构建全面的风险模型测试、验证和性能评估系统
创建时间: 2025-08-24 10:13:48"""


# 添加src目录到路径sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

try:
    from advanced_risk_models import (
        VaRModel, PortfolioOptimizer, RiskModelType,
        OptimizationObjective
    )
    print("误高级风险模型导入成功")
except ImportError as e:
    print(f"误高级风险模型导入失败: {e}")
    sys.exit(1)

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class TestType(Enum):

    """测试类型枚举"""
    UNIT_TEST = "unit_test"                 # 单元测试
    INTEGRATION_TEST = "integration_test"   # 集成测试
    PERFORMANCE_TEST = "performance_test"   # 性能测试
    STRESS_TEST = "stress_test"            # 压力测试
    BACKTEST = "backtest"                  # 回测测试
    SENSITIVITY_TEST = "sensitivity_test"  # 敏感性测试


class TestStatus(Enum):

    """测试状态枚举"""
    PENDING = "pending"     # 待执行
    RUNNING = "running"     # 运行中
    PASSED = "passed"       # 通过
    FAILED = "failed"       # 失败
    ERROR = "error"         # 错误
    SKIPPED = "skipped"     # 跳过


@dataclass
class TestResult:

    """测试结果"""
    test_id: str
    test_name: str
    test_type: TestType
    status: TestStatus
    execution_time: float
    metrics: Dict[str, Any]
    errors: List[str]
    warnings: List[str]
    start_time: datetime
    end_time: Optional[datetime] = None

    def __post_init__(self):
        if self.end_time is None:
            self.end_time = self.start_time + timedelta(seconds=self.execution_time)


class RiskModelTester:

    """风险模型测试器"""

    def __init__(self):
        self.test_results = []
        self.test_suites = {}
        self.baseline_metrics = {}

    def register_test_suite(self, suite_name: str, test_functions: List[Callable]):
        """注册测试套件"""
        self.test_suites[suite_name] = test_functions
        logger.info(f"测试套件已注误 {suite_name}")

    def run_test_suite(self, suite_name: str) -> List[TestResult]:
        """运行测试套件"""
        if suite_name not in self.test_suites:
            raise ValueError(f"测试套件不存在 {suite_name}")

        test_functions = self.test_suites[suite_name]
        results = []

        logger.info(f"开始执行测试套件 {suite_name}")

        for test_func in test_functions:
            try:
                start_time = datetime.now()

                # 执行测试
                test_result = test_func()

                execution_time = (datetime.now() - start_time).total_seconds()

                if isinstance(test_result, dict):
                    # 测试通过
                    result = TestResult(
                        test_id=f"{suite_name}_{test_func.__name__}_{int(start_time.timestamp())}",
                        test_name=test_func.__name__,
                        test_type=TestType.UNIT_TEST,
                        status=TestStatus.PASSED,
                        execution_time=execution_time,
                        metrics=test_result,
                        errors=[],
                        warnings=[],
                        start_time=start_time
                    )
                elif isinstance(test_result, Exception):
                    # 测试失败
                    result = TestResult(
                        test_id=f"{suite_name}_{test_func.__name__}_{int(start_time.timestamp())}",
                        test_name=test_func.__name__,
                        test_type=TestType.UNIT_TEST,
                        status=TestStatus.FAILED,
                        execution_time=execution_time,
                        metrics={},
                        errors=[str(test_result)],
                        warnings=[],
                        start_time=start_time
                    )
                else:
                    # 无效测试结果
                    result = TestResult(
                        test_id=f"{suite_name}_{test_func.__name__}_{int(start_time.timestamp())}",
                        test_name=test_func.__name__,
                        test_type=TestType.UNIT_TEST,
                        status=TestStatus.ERROR,
                        execution_time=execution_time,
                        metrics={},
                        errors=["Invalid test result"],
                        warnings=[],
                        start_time=start_time
                    )

                results.append(result)

            except Exception as e:
                # 测试执行错误
                result = TestResult(
                    test_id=f"{suite_name}_{test_func.__name__}_{int(start_time.timestamp())}",
                    test_name=test_func.__name__,
                    test_type=TestType.UNIT_TEST,
                    status=TestStatus.ERROR,
                    execution_time=0.0,
                    metrics={},
                    errors=[str(e)],
                    warnings=[],
                    start_time=start_time
                )
                results.append(result)

        logger.info(
            f"测试套件执行完成: {suite_name}, 通过: {sum(1 for r in results if r.status == TestStatus.PASSED)}/{len(results)}")
        self.test_results.extend(results)

        return results

    def run_parallel_tests(self, suite_name: str, max_workers: int = 4) -> List[TestResult]:
        """并行运行测试"""
        if suite_name not in self.test_suites:
            raise ValueError(f"测试套件不存在 {suite_name}")

        test_functions = self.test_suites[suite_name]
        results = []

        logger.info(f"开始并行执行测试套件 {suite_name}")

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            # 提交所有测试
            future_to_test = {
                executor.submit(self._run_single_test, test_func, suite_name): test_func
                for test_func in test_functions
            }

            # 收集结果
            for future in as_completed(future_to_test):
                result = future.result()
                if result:
                    results.append(result)

        logger.info(
            f"并行测试执行完成: {suite_name}, 通过: {sum(1 for r in results if r.status == TestStatus.PASSED)}/{len(results)}")
        self.test_results.extend(results)

        return results

    def _run_single_test(self, test_func: Callable, suite_name: str) -> Optional[TestResult]:
        """运行单个测试"""
        try:
            start_time = datetime.now()

            # 执行测试
            test_result = test_func()

            execution_time = (datetime.now() - start_time).total_seconds()

            if isinstance(test_result, dict):
                return TestResult(
                    test_id=f"{suite_name}_{test_func.__name__}_{int(start_time.timestamp())}",
                    test_name=test_func.__name__,
                    test_type=TestType.UNIT_TEST,
                    status=TestStatus.PASSED,
                    execution_time=execution_time,
                    metrics=test_result,
                    errors=[],
                    warnings=[],
                    start_time=start_time
                )
            else:
                return TestResult(
                    test_id=f"{suite_name}_{test_func.__name__}_{int(start_time.timestamp())}",
                    test_name=test_func.__name__,
                    test_type=TestType.UNIT_TEST,
                    status=TestStatus.FAILED,
                    execution_time=execution_time,
                    metrics={},
                    errors=["Test failed"],
                    warnings=[],
                    start_time=start_time
                )

        except Exception as e:
            return TestResult(
                test_id=f"{suite_name}_{test_func.__name__}_{int(start_time.timestamp())}",
                test_name=test_func.__name__,
                test_type=TestType.UNIT_TEST,
                status=TestStatus.ERROR,
                execution_time=0.0,
                metrics={},
                errors=[str(e)],
                warnings=[],
                start_time=start_time
            )


class PerformanceTester:

    """性能测试器"""

    def __init__(self):
        self.performance_metrics = {}
        self.baseline_performance = {}

    def benchmark_var_calculation(self, data_sizes: List[int], model_types: List[RiskModelType]) -> Dict[str, Any]:
        """VaR计算性能基准测试"""
        results = {}

        for n_samples in data_sizes:
            results[n_samples] = {}

            # 生成测试数据
            np.random.seed(42)
            returns = np.random.normal(0.001, 0.02, n_samples)

            for model_type in model_types:
                start_time = datetime.now()

                # 创建和拟合模型
                model = VaRModel(model_type)
                model.fit(returns)

                # 计算VaR
                var_result = model.calculate_var(confidence_level=0.95, time_horizon=1)

                execution_time = (datetime.now() - start_time).total_seconds()

                results[n_samples][model_type.value] = {
                    'execution_time': execution_time,
                    'var_value': var_result.var_value,
                    'cvar_value': var_result.cvar_value,
                    'throughput': n_samples / execution_time if execution_time > 0 else 0
                }

        return results

    def benchmark_portfolio_optimization(self, asset_counts: List[int],
                                         objectives: List[OptimizationObjective]) -> Dict[str, Any]:
        """投资组合优化性能基准测试"""
        results = {}

        for n_assets in asset_counts:
            results[n_assets] = {}

            # 生成测试数据
            np.random.seed(42)
            expected_returns = np.random.normal(0.001, 0.005, n_assets)
            cov_matrix = np.random.randn(n_assets, n_assets)
            cov_matrix = cov_matrix @ cov_matrix.T  # 确保正定

            for objective in objectives:
                start_time = datetime.now()

                # 执行优化
                optimizer = PortfolioOptimizer(objective)
                optimization_result = optimizer.optimize(expected_returns, cov_matrix)

                execution_time = (datetime.now() - start_time).total_seconds()

                results[n_assets][objective.value] = {
                    'execution_time': execution_time,
                    'convergence_status': optimization_result.convergence_status if optimization_result else 'failed',
                    'sharpe_ratio': optimization_result.sharpe_ratio if optimization_result else 0,
                    'throughput': n_assets / execution_time if execution_time > 0 else 0
                }

        return results

    def stress_test_system(self, concurrent_users: List[int], duration: int = 60) -> Dict[str, Any]:
        """系统压力测试"""
        results = {}

        for n_users in concurrent_users:
            results[n_users] = {
                'total_requests': 0,
                'successful_requests': 0,
                'failed_requests': 0,
                'average_response_time': 0,
                'max_response_time': 0,
                'min_response_time': float('inf'),
                'error_rate': 0
            }

            response_times = []

            # 简化的压力测试

            def simulate_request():
                start_time = datetime.now()
                # 模拟处理时间
                time.sleep(np.random.uniform(0.1, 0.5))
                end_time = datetime.now()

                response_time = (end_time - start_time).total_seconds()
                return response_time, np.random.random() > 0.05  # 95% 成功率

            with ThreadPoolExecutor(max_workers=n_users) as executor:
                futures = [executor.submit(simulate_request) for _ in range(n_users * 10)]

            for future in as_completed(futures):
                response_time, success = future.result()
                response_times.append(response_time)

                results[n_users]['total_requests'] += 1
                if success:
                    results[n_users]['successful_requests'] += 1
                else:
                    results[n_users]['failed_requests'] += 1

            # 计算统计信息
            if response_times:
                results[n_users]['average_response_time'] = np.mean(response_times)
                results[n_users]['max_response_time'] = np.max(response_times)
                results[n_users]['min_response_time'] = np.min(response_times)
                results[n_users]['error_rate'] = results[n_users]['failed_requests'] / \
                    results[n_users]['total_requests']

        return results


class SensitivityTester:

    """敏感性测试器"""

    def __init__(self):
        self.sensitivity_results = {}

    def test_var_sensitivity(self, returns: np.ndarray, parameters: Dict[str, List[float]]) -> Dict[str, Any]:
        """VaR敏感性测试"""
        results = {}

        for param_name, param_values in parameters.items():
            results[param_name] = []

        for param_value in param_values:
            # 创建模型并设置参数
            model = VaRModel(RiskModelType.PARAMETRIC)

            if param_name == 'confidence_level':
                model.fit(returns)
                var_result = model.calculate_var(confidence_level=param_value)
            elif param_name == 'time_horizon':
                model.fit(returns)
                var_result = model.calculate_var(time_horizon=int(param_value))
            else:
                continue

            results[param_name].append({
                'parameter_value': param_value,
                'var_value': var_result.var_value,
                'cvar_value': var_result.cvar_value,
                'execution_time': var_result.calculation_time
            })

        return results

    def test_portfolio_sensitivity(self, expected_returns: np.ndarray, cov_matrix: np.ndarray,
                                   parameters: Dict[str, List[float]]) -> Dict[str, Any]:
        """投资组合优化敏感性测试"""
        results = {}

        for param_name, param_values in parameters.items():
            results[param_name] = []

        for param_value in param_values:
            # 创建优化器并设置参数
            optimizer = PortfolioOptimizer()

            if param_name == 'risk_aversion':
                # 简化的风险厌恶参数测试
                adjusted_returns = expected_returns * param_value
                optimization_result = optimizer.optimize(adjusted_returns, cov_matrix)
            else:
                optimization_result = optimizer.optimize(expected_returns, cov_matrix)

            if optimization_result:
                results[param_name].append({
                    'parameter_value': param_value,
                    'expected_return': optimization_result.expected_return,
                    'expected_volatility': optimization_result.expected_volatility,
                    'sharpe_ratio': optimization_result.sharpe_ratio,
                    'execution_time': optimization_result.optimization_time
                })

        return results


class Backtester:

    """回测测试器"""

    def __init__(self):
        self.backtest_results = {}

    def rolling_window_backtest(self, returns: np.ndarray, model_factory: Callable,
                                window_size: int = 250, step_size: int = 21) -> Dict[str, Any]:
        """滚动窗口回测"""
        n_periods = len(returns)
        predictions = []
        actuals = []

        for i in range(window_size, n_periods - step_size, step_size):
            # 训练数据
            train_returns = returns[i - window_size:i]

            # 创建和训练模型
            model = model_factory()
            model.fit(train_returns)

            # 预测下一期
            # 这里简化为使用历史均值作为预测
            predicted_return = np.mean(train_returns[-step_size:])

            # 实际值
            actual_return = np.mean(returns[i:i + step_size])

            predictions.append(predicted_return)
            actuals.append(actual_return)

        # 计算回测指标
        predictions = np.array(predictions)
        actuals = np.array(actuals)

        mse = np.mean((predictions - actuals) ** 2)
        rmse = np.sqrt(mse)
        mae = np.mean(np.abs(predictions - actuals))

        # 计算准确性（简化为相关系数）
        correlation = np.corrcoef(predictions, actuals)[0, 1]

        return {
            'total_predictions': len(predictions),
            'mse': mse,
            'rmse': rmse,
            'mae': mae,
            'correlation': correlation,
            'predictions': predictions.tolist(),
            'actuals': actuals.tolist(),
            'window_size': window_size,
            'step_size': step_size
        }


class TestReportGenerator:

    """测试报告生成器"""

    def __init__(self):
        self.reports = {}

    def generate_comprehensive_report(self, test_results: List[TestResult],
                                      performance_results: Dict[str, Any] = None) -> Dict[str, Any]:
        """生成综合测试报告"""
        # 统计基本信息
        total_tests = len(test_results)
        passed_tests = sum(1 for r in test_results if r.status == TestStatus.PASSED)
        failed_tests = sum(1 for r in test_results if r.status == TestStatus.FAILED)
        error_tests = sum(1 for r in test_results if r.status == TestStatus.ERROR)

        # 计算通过率
        pass_rate = passed_tests / total_tests if total_tests > 0 else 0

        # 统计执行时间
        total_execution_time = sum(r.execution_time for r in test_results)
        avg_execution_time = total_execution_time / total_tests if total_tests > 0 else 0

        # 按测试类型分组
        tests_by_type = {}
        for result in test_results:
            test_type = result.test_type.value
            if test_type not in tests_by_type:
                tests_by_type[test_type] = []
            tests_by_type[test_type].append(result)

        # 生成报告
        report = {
            'report_id': f"risk_test_{int(datetime.now().timestamp())}",
            'generated_at': datetime.now().isoformat(),
            'summary': {
                'total_tests': total_tests,
                'passed_tests': passed_tests,
                'failed_tests': failed_tests,
                'error_tests': error_tests,
                'pass_rate': pass_rate,
                'total_execution_time': total_execution_time,
                'avg_execution_time': avg_execution_time
            },
            'tests_by_type': tests_by_type,
            'failed_tests_detail': [
                {
                    'test_id': r.test_id,
                    'test_name': r.test_name,
                    'errors': r.errors,
                    'warnings': r.warnings,
                    'execution_time': r.execution_time
                }
                for r in test_results if r.status in [TestStatus.FAILED, TestStatus.ERROR]
            ],
            'performance_results': performance_results or {},
            'recommendations': self._generate_recommendations(test_results, pass_rate)
        }

        return report

    def _generate_recommendations(self, test_results: List[TestResult], pass_rate: float) -> List[str]:
        """生成建议"""
        recommendations = []

        if pass_rate < 0.8:
            recommendations.append("测试通过率较低，建议检查测试用例质量和被测代码")

        failed_tests = [r for r in test_results if r.status == TestStatus.FAILED]
        if len(failed_tests) > 5:
            recommendations.append("失败测试用例较多，建议优先修复高影响力的测试")

        error_tests = [r for r in test_results if r.status == TestStatus.ERROR]
        if len(error_tests) > 0:
            recommendations.append("存在测试执行错误，建议检查测试环境和依赖")

        slow_tests = [r for r in test_results if r.execution_time > 10.0]
        if len(slow_tests) > 0:
            recommendations.append("存在执行时间较长的测试，建议优化测试效率")

        return recommendations

    def export_report(self, report: Dict[str, Any], output_path: str):
        """导出报告"""
        os.makedirs(os.path.dirname(output_path), exist_ok=True)

        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(report, f, ensure_ascii=False, indent=2)

        logger.info(f"测试报告已导出 {output_path}")

# 创建默认测试函数


def test_var_historical_model():
    """测试历史模拟法VaR模型"""
    try:
        # 生成测试数据
        np.random.seed(42)
        returns = np.random.normal(0.001, 0.02, 1000)

        # 创建和拟合模型
        model = VaRModel(RiskModelType.HISTORICAL)
        model.fit(returns)

        # 计算VaR
        result = model.calculate_var(confidence_level=0.95)

        # 验证结果
        assert result.var_value > 0, "VaR值应该为正"
        assert result.cvar_value >= result.var_value, "CVaR应该大于等于VaR"
        assert result.calculation_time >= 0, "计算时间应该为非负数"

        return {
            'var_value': result.var_value,
            'cvar_value': result.cvar_value,
            'execution_time': result.calculation_time,
            'status': 'passed'
        }

    except Exception as e:
        return e


def test_var_parametric_model():
    """测试参数法VaR模型"""
    try:
        # 生成测试数据
        np.random.seed(42)
        returns = np.random.normal(0.001, 0.02, 1000)

        # 创建和拟合模型
        model = VaRModel(RiskModelType.PARAMETRIC)
        model.fit(returns)

        # 计算VaR
        result = model.calculate_var(confidence_level=0.95)

        # 验证结果
        assert result.var_value > 0, "VaR值应该为正"
        assert result.calculation_time >= 0, "计算时间应该为非负数"

        return {
            'var_value': result.var_value,
            'distribution': 'normal',  # 简化为正态分布
            'execution_time': result.calculation_time,
            'status': 'passed'
        }

    except Exception as e:
        return e


def test_portfolio_optimization():
    """测试投资组合优化"""
    try:
        # 生成测试数据
        np.random.seed(42)
        n_assets = 5
        expected_returns = np.random.normal(0.001, 0.005, n_assets)
        cov_matrix = np.random.randn(n_assets, n_assets)
        cov_matrix = cov_matrix @ cov_matrix.T  # 确保正定

        # 创建优化器
        optimizer = PortfolioOptimizer(OptimizationObjective.MAX_SHARPE)

        # 执行优化
        result = optimizer.optimize(expected_returns, cov_matrix)

        # 验证结果
        assert result is not None, "优化结果不应为空"
        assert result.expected_volatility >= 0, "波动率应该为非负"
        assert len(result.weights) == n_assets, "权重数量应该等于资产数量"
        assert np.isclose(np.sum(result.weights), 1.0), "权重和应该等于1"

        return {
            'expected_return': result.expected_return,
            'expected_volatility': result.expected_volatility,
            'sharpe_ratio': result.sharpe_ratio,
            'execution_time': result.optimization_time,
            'status': 'passed'
        }

    except Exception as e:
        return e


def main():
    """主函数 - 风险模型测试演示"""
    print("🧪 RQA2025风险模型测试和验证")
    print("=" * 60)

    # 创建测试器
    tester = RiskModelTester()

    # 注册测试套件
    test_functions = [
        test_var_historical_model,
        test_var_parametric_model,
        test_portfolio_optimization
    ]

    tester.register_test_suite('core_risk_models', test_functions)

    # 运行测试
    print("🔬 运行核心风险模型测试...")
    test_results = tester.run_test_suite('core_risk_models')

    # 显示测试结果
    passed_tests = sum(1 for r in test_results if r.status == TestStatus.PASSED)
    total_tests = len(test_results)

    print(f"\n📊 测试结果: {passed_tests}/{total_tests} 通过")

    for result in test_results:
        status_icon = "✅" if result.status == TestStatus.PASSED else "❌" if result.status == TestStatus.FAILED else "⚠️"
    print(f"   {status_icon} {result.test_name}: {result.status.value} ({result.execution_time:.2f}s)")

    if result.errors:
        print(f"      错误: {result.errors[0]}")

    # 性能测试
    print("\n" + "=" * 60)
    print("误性能测试")

    performance_tester = PerformanceTester()

    # VaR计算性能测试
    print("\n🔬 VaR计算性能测试...")
    data_sizes = [1000, 5000, 10000]
    model_types = [RiskModelType.HISTORICAL, RiskModelType.PARAMETRIC]

    var_performance = performance_tester.benchmark_var_calculation(data_sizes, model_types)

    print("   数据规模 | 模型类型 | 计算时间 | 吞吐量")
    print("   ---------|----------|----------|--------")
    for size in data_sizes:
        for model_type in model_types:
            perf = var_performance[size][model_type.value]
    print(
        f"   {size:8} | {model_type.value:8} | {perf['execution_time']:8.3f}s | {perf['throughput']:8.0f}")

    # 敏感性测试
    print("\n" + "=" * 60)
    print("📈 敏感性测试")

    sensitivity_tester = SensitivityTester()

    # 生成测试数据
    np.random.seed(42)
    returns = np.random.normal(0.001, 0.02, 1000)

    # VaR敏感性测误    print("\n🔬 VaR敏感性测误..")
    var_sensitivity_params = {
        'confidence_level': [0.90, 0.95, 0.99],
        'time_horizon': [1, 5, 10]
    }

    var_sensitivity = sensitivity_tester.test_var_sensitivity(returns, var_sensitivity_params)

    for param_name, results in var_sensitivity.items():
        print(f"   {param_name}:")
    for result in results:
        print(f"     误{result['parameter_value']}, VaR={result['var_value']:.4f}")

    # 回测测试
    print("\n" + "=" * 60)
    print("📉 回测测试")

    backtester = Backtester()

    print("\n🔬 执行滚动窗口回测...")

    def create_var_model():
        return VaRModel(RiskModelType.HISTORICAL)

    backtest_result = backtester.rolling_window_backtest(
        returns, create_var_model, window_size=100, step_size=10
    )

    print(f"   预测数量: {backtest_result['total_predictions']}")
    print(f"   RMSE: {backtest_result['rmse']:.6f}")
    print(f"   MAE: {backtest_result['mae']:.6f}")
    print(f"   相关系数: {backtest_result['correlation']:.4f}")

    # 生成综合报告
    print("\n" + "=" * 60)
    print("📋 生成测试报告")

    report_generator = TestReportGenerator()
    comprehensive_report = report_generator.generate_comprehensive_report(
        test_results, {
            'var_performance': var_performance,
            'var_sensitivity': var_sensitivity,
            'backtest_result': backtest_result
        }
    )

    # 保存报告
    report_path = "models / risk / reports / risk_model_test_report.json"
    report_generator.export_report(comprehensive_report, report_path)

    print(f"   报告已保存 {report_path}")
    print(f"   测试通过率 {comprehensive_report['summary']['pass_rate']:.1%}")
    print(f"   总执行时间 {comprehensive_report['summary']['total_execution_time']:.2f}秒")

    if comprehensive_report['recommendations']:
        print("   建议:")
        for rec in comprehensive_report['recommendations']:
            print(f"     - {rec}")

    print("\n🎉 风险模型测试和验证演示完成！")
    print("   专业的测试和验证系统已准备就绪")
    print("   可以支持风险模型的全面质量保证")

    return {
        'test_results': test_results,
        'performance_results': var_performance,
        'sensitivity_results': var_sensitivity,
        'backtest_results': backtest_result,
        'comprehensive_report': comprehensive_report
    }


if __name__ == "__main__":
    results = main()
