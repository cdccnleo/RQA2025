import logging
#!/usr/bin/env python3
"""
# 高级风险模型

构建专业的金融风险模型，包括VaR、CVaR、压力测试、风险组合优化等
创建时间: 2025-08-24 10:13:48"""

import numpy as np
import pandas as pd
import warnings
from typing import Dict, List, Any, Optional, Tuple, Callable
from datetime import datetime
from dataclasses import dataclass
from enum import Enum
import scipy.stats as stats
from scipy.optimize import minimize
import matplotlib.pyplot as plt

# 添加src目录到路径sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

try:
    from .realtime_risk_monitor import RiskType, RiskLevel, RiskIndicator
    print("风险监控模块导入成功")
except ImportError as e:
    print(f"风险监控模块导入失败: {e}")
    # 使用默认实现

    class RiskType:
        MARKET_RISK = "market_risk"
        CREDIT_RISK = "credit_risk"
        LIQUIDITY_RISK = "liquidity_risk"
        OPERATIONAL_RISK = "operational_risk"

    class RiskLevel:
        LOW = "low"
        MEDIUM = "medium"
        HIGH = "high"
        CRITICAL = "critical"

    class RiskIndicator:
        def __init__(self, name, value, level):
            self.name = name
            self.value = value
            self.level = level

# 配置matplotlib
plt.style.use('seaborn-v0_8')
warnings.filterwarnings('ignore')

# Logger setup
logger = logging.getLogger(__name__)


class RiskModelType(Enum):

    """风险模型类型枚举"""
    HISTORICAL = "historical"           # 历史模拟
    PARAMETRIC = "parametric"           # 参数
    MONTE_CARLO = "monte_carlo"         # 蒙特卡洛模拟
    EXTREME_VALUE = "extreme_value"     # 极值理论
    GARCH = "garch"                     # GARCH模型
    STOCHASTIC_VOLATILITY = "stochastic_volatility"  # 随机波动率


class OptimizationObjective(Enum):

    """优化目标枚举"""
    MAX_SHARPE = "max_sharpe"           # 最大化夏普比率
    MIN_VARIANCE = "min_variance"       # 最小化方差
    MAX_RETURN = "max_return"           # 最大化收益
    MAX_DIVERSIFICATION = "max_diversification"  # 最大化分散化
    MIN_CVAR = "min_cvar"               # 最小化CVaR
    RISK_PARITY = "risk_parity"         # 风险平价
    BLACK_LITTERMAN = "black_litterman"  # Black - Litterman模型


@dataclass
class RiskModelResult:

    """风险模型结果"""
    model_type: RiskModelType
    confidence_level: float
    time_horizon: int  # 天数
    var_value: float
    cvar_value: float
    expected_shortfall: float
    calculation_time: float
    sample_size: int
    convergence_status: str
    warnings: List[str] = None

    def __post_init__(self):

        if self.warnings is None:
            self.warnings = []


@dataclass
class PortfolioOptimizationResult:

    """投资组合优化结果"""
    objective: OptimizationObjective
    weights: np.ndarray
    expected_return: float
    expected_volatility: float
    sharpe_ratio: float
    diversification_ratio: float
    optimization_time: float
    constraints_satisfied: bool
    convergence_status: str


class VaRModel:

    """VaR模型"""

    def __init__(self, model_type: RiskModelType = RiskModelType.HISTORICAL):

        self.model_type = model_type
        self.fitted = False
        self.parameters = {}

    def fit(self, returns: np.ndarray, **kwargs):
        """拟合模型"""
        if self.model_type == RiskModelType.HISTORICAL:
            self._fit_historical(returns, **kwargs)
        elif self.model_type == RiskModelType.PARAMETRIC:
            self._fit_parametric(returns, **kwargs)
        elif self.model_type == RiskModelType.MONTE_CARLO:
            self._fit_monte_carlo(returns, **kwargs)
        else:
            raise ValueError(f"不支持的模型类型: {self.model_type}")

        self.fitted = True

    def _fit_historical(self, returns: np.ndarray, **kwargs):
        """历史模拟法拟合"""
        self.parameters = {
            'returns': returns.copy(),
            'method': 'historical'
        }

    def _fit_parametric(self, returns: np.ndarray, **kwargs):
        """参数法拟合"""
        # 正态分布参数估计
        mu = np.mean(returns)
        sigma = np.std(returns)

        # 检查分布正态性
        _, p_value = stats.shapiro(returns)
        distribution = 'normal' if p_value > 0.05 else 't'

        if distribution == 't':
            # t分布参数估计
            df, _, _ = stats.t.fit(returns)
            self.parameters = {
                'mu': mu,
                'sigma': sigma,
                'distribution': distribution,
                'df': df
            }
        else:
            self.parameters = {
                'mu': mu,
                'sigma': sigma,
                'distribution': distribution
            }

    def _fit_monte_carlo(self, returns: np.ndarray, **kwargs):
        """蒙特卡洛模拟拟合"""
        n_simulations = kwargs.get('n_simulations', 10000)

        # 基于历史数据的模拟
        mu = np.mean(returns)
        sigma = np.std(returns)

        # 生成模拟数据
        simulated_returns = np.random.normal(mu, sigma, n_simulations)

        self.parameters = {
            'mu': mu,
            'sigma': sigma,
            'simulated_returns': simulated_returns,
            'n_simulations': n_simulations
        }

    def calculate_var(self, confidence_level: float = 0.95,
                      time_horizon: int = 1) -> RiskModelResult:
        """计算VaR"""
        if not self.fitted:
            raise ValueError("模型尚未拟合")

        start_time = datetime.now()

        if self.model_type == RiskModelType.HISTORICAL:
            var_value = self._calculate_var_historical(confidence_level, time_horizon)
        elif self.model_type == RiskModelType.PARAMETRIC:
            var_value = self._calculate_var_parametric(confidence_level, time_horizon)
        elif self.model_type == RiskModelType.MONTE_CARLO:
            var_value = self._calculate_var_monte_carlo(confidence_level, time_horizon)
        else:
            raise ValueError(f"不支持的模型类型: {self.model_type}")

        # 计算CVaR
        cvar_value = self._calculate_cvar(confidence_level, time_horizon)

        # 计算预期短缺
        expected_shortfall = self._calculate_expected_shortfall(confidence_level, time_horizon)

        calculation_time = (datetime.now() - start_time).total_seconds()

        return RiskModelResult(
            model_type=self.model_type,
            confidence_level=confidence_level,
            time_horizon=time_horizon,
            var_value=var_value,
            cvar_value=cvar_value,
            expected_shortfall=expected_shortfall,
            calculation_time=calculation_time,
            sample_size=len(self.parameters.get('returns', [])),
            convergence_status='success'
        )

    def predict(self, data: np.ndarray, confidence_level: float = 0.95) -> float:
        """预测VaR值

        Args:
            data: 输入数据 (收益率等)
            confidence_level: 置信水平

        Returns:
            预测的VaR值
        """
        if not self.fitted:
            raise ValueError("模型尚未拟合")

        # 使用已拟合的参数进行预测
        if self.model_type == RiskModelType.HISTORICAL:
            returns = self.parameters['returns']
            scaled_returns = returns * np.sqrt(1)  # 单期预测
            quantile = 1 - confidence_level
            var_value = np.percentile(scaled_returns, quantile * 100)
            return -abs(var_value)  # VaR通常表示为负数
        elif self.model_type == RiskModelType.PARAMETRIC:
            mu = self.parameters['mu']
            sigma = self.parameters['sigma']
            from scipy import stats
            z_score = stats.norm.ppf(1 - confidence_level)
            var_value = mu + z_score * sigma
            return -abs(var_value)  # VaR通常表示为负数
        elif self.model_type == RiskModelType.MONTE_CARLO:
            # 使用存储的模拟结果
            simulated_returns = self.parameters.get('simulated_returns', [])
            if not simulated_returns:
                raise ValueError("没有可用的模拟数据")
            quantile = 1 - confidence_level
            var_value = np.percentile(simulated_returns, quantile * 100)
            return -abs(var_value)  # VaR通常表示为负数
        else:
            raise ValueError(f"不支持的模型类型: {self.model_type}")

    def _calculate_var_historical(self, confidence_level: float, time_horizon: int) -> float:
        """历史模拟法计算VaR"""
        returns = self.parameters['returns']
        scaled_returns = returns * np.sqrt(time_horizon)

        # 计算分位数
        quantile = 1 - confidence_level
        var_value = np.percentile(scaled_returns, quantile * 100)

        return abs(var_value)

    def _calculate_var_parametric(self, confidence_level: float, time_horizon: int) -> float:
        """参数法计算VaR"""
        mu = self.parameters['mu']
        sigma = self.parameters['sigma']
        distribution = self.parameters['distribution']

        # 时间调整
        adjusted_sigma = sigma * np.sqrt(time_horizon)

        if distribution == 't':
            df = self.parameters['df']
            # t分布VaR
            quantile = stats.t.ppf(1 - confidence_level, df)
            var_value = -(mu * time_horizon + adjusted_sigma * quantile)
        else:
            # 正态分布VaR
            quantile = stats.norm.ppf(1 - confidence_level)
            var_value = -(mu * time_horizon + adjusted_sigma * quantile)

        return var_value

    def _calculate_var_monte_carlo(self, confidence_level: float, time_horizon: int) -> float:
        """蒙特卡洛模拟计算VaR"""
        simulated_returns = self.parameters['simulated_returns']
        scaled_returns = simulated_returns * np.sqrt(time_horizon)

        # 计算分位数
        quantile = 1 - confidence_level
        var_value = np.percentile(scaled_returns, quantile * 100)

        return abs(var_value)

    def _calculate_cvar(self, confidence_level: float, time_horizon: int) -> float:
        """计算CVaR"""
        if self.model_type == RiskModelType.HISTORICAL:
            returns = self.parameters['returns']
            scaled_returns = returns * np.sqrt(time_horizon)
        elif self.model_type == RiskModelType.MONTE_CARLO:
            simulated_returns = self.parameters['simulated_returns']
            scaled_returns = simulated_returns * np.sqrt(time_horizon)
        else:
            # 参数法生成模拟数据
            mu = self.parameters['mu']
            sigma = self.parameters['sigma']
            n_sim = 10000
            scaled_returns = np.random.normal(
                mu * time_horizon, sigma * np.sqrt(time_horizon), n_sim)

        # 计算CVaR
        quantile = 1 - confidence_level
        var_threshold = np.percentile(scaled_returns, quantile * 100)
        tail_losses = scaled_returns[scaled_returns <= var_threshold]

        return abs(np.mean(tail_losses)) if len(tail_losses) > 0 else 0

    def _calculate_expected_shortfall(self, confidence_level: float, time_horizon: int) -> float:
        """计算预期短缺"""
        # 简化为CVaR的别名
        return self._calculate_cvar(confidence_level, time_horizon)


class StressTestModel:

    """压力测试模型"""

    def __init__(self):
        self.scenarios = {}
        self.baseline_metrics = {}

    def define_scenario(self, scenario_name: str, shock_function: Callable, description: str = ""):
        """定义压力测试情景"""
        self.scenarios[scenario_name] = {
            'shock_function': shock_function,
            'description': description,
            'created_at': datetime.now()
        }

    def run_stress_test(self, portfolio_returns: np.ndarray,
                        scenario_name: str) -> Dict[str, Any]:
        """运行压力测试"""
        if scenario_name not in self.scenarios:
            raise ValueError(f"情景 {scenario_name} 未定义")

        scenario = self.scenarios[scenario_name]
        shock_function = scenario['shock_function']

        # 应用冲击
        stressed_returns = shock_function(portfolio_returns)

        # 计算压力下的风险指标
        var_model = VaRModel(RiskModelType.HISTORICAL)
        var_model.fit(stressed_returns)

        stress_result = var_model.calculate_var(confidence_level=0.99, time_horizon=1)

        # 计算相对变化
        baseline_var = self.baseline_metrics.get('var_99', stress_result.var_value)
        var_change = (stress_result.var_value - baseline_var) / baseline_var

        return {
            'scenario': scenario_name,
            'description': scenario['description'],
            'stressed_var': stress_result.var_value,
            'stressed_cvar': stress_result.cvar_value,
            'var_change': var_change,
            'max_drawdown': self._calculate_drawdown(stressed_returns),
            'volatility_increase': np.std(stressed_returns) / np.std(portfolio_returns),
            'test_time': datetime.now().isoformat()
        }

    def _calculate_drawdown(self, returns: np.ndarray) -> float:
        """计算最大回误"""
        cumulative = np.cumprod(1 + returns)
        peak = np.maximum.accumulate(cumulative)
        drawdown = (cumulative - peak) / peak
        return abs(np.min(drawdown))

    def create_market_crash_scenario(self, crash_severity: float = 0.3) -> Callable:
        """创建市场崩盘情景"""

        def market_crash_shock(returns):
            # 在随机时间点应用崩盘冲击
            crash_point = np.random.randint(len(returns) // 4, 3 * len(returns) // 4)

            # 应用崩盘冲击
            shocked_returns = returns.copy()
            shocked_returns[crash_point:crash_point + 5] -= crash_severity

            return shocked_returns

        return market_crash_shock

    def create_interest_rate_shock_scenario(self, rate_change: float = 0.025) -> Callable:
        """创建利率冲击情景"""

        def interest_rate_shock(returns):
            # 利率变化对不同资产的影响
            shocked_returns = returns.copy()

            # 假设利率上升对债券和股票的不同影响
            bond_impact = -rate_change * 2
            stock_impact = -rate_change * 0.5

            # 简化的资产分配影响
            shocked_returns *= (1 + bond_impact * 0.4 + stock_impact * 0.6)

            return shocked_returns

        return interest_rate_shock


class PortfolioOptimizer:
    """投资组合优化器"""

    def __init__(self, objective = OptimizationObjective.MAX_SHARPE):
        if isinstance(objective, str):
            # 将字符串转换为枚举
            objective = OptimizationObjective(objective)
        self.objective = objective
        self.constraints = []
        self.bounds = None

    def add_constraint(self, constraint_function: Callable, constraint_type: str = 'ineq'):
        """添加约束条件"""
        self.constraints.append({
            'function': constraint_function,
            'type': constraint_type
        })

    def set_bounds(self, bounds: List[Tuple[float, float]]):
        """设置边界条件"""
        self.bounds = bounds

    def optimize(self, expected_returns: np.ndarray, cov_matrix: np.ndarray,
                 current_weights: Optional[np.ndarray] = None) -> PortfolioOptimizationResult:
        """执行投资组合优化"""
        start_time = datetime.now()

        n_assets = len(expected_returns)

        # 设置初始权重
        if current_weights is None:
            x0 = np.ones(n_assets) / n_assets
        else:
            x0 = current_weights.copy()

        # 设置边界
        if self.bounds is None:
            self.bounds = [(0, 1) for _ in range(n_assets)]

        # 定义目标函数
        if self.objective == OptimizationObjective.MAX_SHARPE:
            objective_func = self._negative_sharpe_ratio
        elif self.objective == OptimizationObjective.MIN_VARIANCE:
            objective_func = self._portfolio_variance
        elif self.objective == OptimizationObjective.MIN_CVAR:
            objective_func = self._portfolio_cvar
        else:
            raise ValueError(f"不支持的优化目标: {self.objective}")

        # 权重求和约束

        def weight_sum_constraint(weights):
            return np.sum(weights) - 1.0

        constraints = [{'type': 'eq', 'fun': weight_sum_constraint}]

        # 添加用户定义的约束
        for constraint in self.constraints:
            constraints.append(constraint)

        # 执行优化
        try:
            result = minimize(
                objective_func,
                x0,
                args=(expected_returns, cov_matrix),
                method='SLSQP',
                bounds=self.bounds,
                constraints=constraints,
                options={'maxiter': 1000, 'ftol': 1e-9}
            )

            optimization_time = (datetime.now() - start_time).total_seconds()

            if result.success:
                optimal_weights = result.x

                # 计算优化后的指标
                portfolio_return = np.sum(optimal_weights * expected_returns)
                portfolio_volatility = np.sqrt(optimal_weights.T @ cov_matrix @ optimal_weights)
                sharpe_ratio = portfolio_return / portfolio_volatility if portfolio_volatility > 0 else 0

                # 计算分散化比率
                diversification_ratio = self._calculate_diversification_ratio(
                    optimal_weights, cov_matrix)

                return PortfolioOptimizationResult(
                    objective=self.objective,
                    weights=optimal_weights,
                    expected_return=portfolio_return,
                    expected_volatility=portfolio_volatility,
                    sharpe_ratio=sharpe_ratio,
                    diversification_ratio=diversification_ratio,
                    optimization_time=optimization_time,
                    constraints_satisfied=True,
                    convergence_status='success'
                )
            else:
                # 优化失败，返回等权重组合
                fallback_weights = np.ones(n_assets) / n_assets
                fallback_return = np.sum(fallback_weights * expected_returns)
                fallback_volatility = np.sqrt(fallback_weights.T @ cov_matrix @ fallback_weights)
                fallback_sharpe = fallback_return / fallback_volatility if fallback_volatility > 0 else 0

                return PortfolioOptimizationResult(
                    objective=self.objective,
                    weights=fallback_weights,
                    expected_return=fallback_return,
                    expected_volatility=fallback_volatility,
                    sharpe_ratio=fallback_sharpe,
                    diversification_ratio=0.5,
                    optimization_time=optimization_time,
                    constraints_satisfied=False,
                    convergence_status=f'failed: {result.message}'
                )

        except Exception as e:
            logger.error(f"投资组合优化失败: {e}")
            return None

    def _negative_sharpe_ratio(self, weights: np.ndarray, expected_returns: np.ndarray,
                               cov_matrix: np.ndarray) -> float:
        """负夏普比率（用于最大化）"""
        portfolio_return = np.sum(weights * expected_returns)
        portfolio_volatility = np.sqrt(weights.T @ cov_matrix @ weights)

        if portfolio_volatility == 0:
            return 0

        sharpe_ratio = portfolio_return / portfolio_volatility
        return -sharpe_ratio  # 取负值用于最小化

    def _portfolio_variance(self, weights: np.ndarray, expected_returns: np.ndarray,
                            cov_matrix: np.ndarray) -> float:
        """投资组合方差"""
        return weights.T @ cov_matrix @ weights

    def _portfolio_cvar(self, weights: np.ndarray, expected_returns: np.ndarray,
                        cov_matrix: np.ndarray) -> float:
        """投资组合CVaR（简化为VaR的近似）"""
        # 这里简化为投资组合波动率
        return np.sqrt(weights.T @ cov_matrix @ weights)

    def _calculate_diversification_ratio(self, weights: np.ndarray, cov_matrix: np.ndarray) -> float:
        """计算分散化比率"""
        # 计算加权平均波动率
        individual_vols = np.sqrt(np.diag(cov_matrix))
        weighted_avg_vol = np.sum(weights * individual_vols)

        # 计算投资组合波动率
        portfolio_vol = np.sqrt(weights.T @ cov_matrix @ weights)

        if weighted_avg_vol == 0:
            return 0

        return portfolio_vol / weighted_avg_vol


class RiskModelValidator:
    """风险模型验证器"""

    def __init__(self):
        self.validation_results = {}

    def backtest_var(self, returns: np.ndarray, var_model: VaRModel,
                     confidence_level: float = 0.95, window_size: int = 250) -> Dict[str, Any]:
        """VaR回测"""
        violations = []
        var_values = []

        for i in range(window_size, len(returns)):
            # 使用历史数据拟合模型
            historical_returns = returns[i - window_size:i]
            var_model.fit(historical_returns)

            # 计算VaR
            var_result = var_model.calculate_var(confidence_level, time_horizon=1)
            var_values.append(var_result.var_value)

            # 检查是否发生违误
            actual_return = returns[i]
            if actual_return < -var_result.var_value:
                violations.append({
                    'date': i,
                    'actual_return': actual_return,
                    'var_value': var_result.var_value,
                    'violation_ratio': abs(actual_return) / var_result.var_value
                })

        # 计算回测统计
        violation_rate = len(violations) / len(var_values)
        expected_violation_rate = 1 - confidence_level

        # Kupiec检误
        kupiec_statistic = self._kupiec_test(
            violation_rate, expected_violation_rate, len(var_values))

        return {
            'total_observations': len(var_values),
            'violations': len(violations),
            'violation_rate': violation_rate,
            'expected_violation_rate': expected_violation_rate,
            'kupiec_statistic': kupiec_statistic,
            'kupiec_p_value': 1 - stats.chi2.cdf(kupiec_statistic, 1),
            'violation_details': violations[-10:],  # 最后10个违反记录
            'backtest_period': f"{window_size}天滚动窗口"
        }

    def _kupiec_test(self, violation_rate: float, expected_rate: float, n: int) -> float:
        """Kupiec比例检验"""
        if violation_rate == 0:
            return np.inf

        lr = (1 - violation_rate) ** (n - n * violation_rate) * \
            violation_rate ** (n * violation_rate) / \
             ((1 - expected_rate) ** (n - n * expected_rate) *
              expected_rate ** (n * expected_rate))

        return -2 * np.log(lr)

    def validate_portfolio_optimization(self, optimization_result: PortfolioOptimizationResult,
                                        historical_returns: pd.DataFrame) -> Dict[str, Any]:
        """验证投资组合优化结果"""
        # 计算历史表现
        weights = optimization_result.weights
        historical_portfolio_returns = historical_returns.dot(weights)

        # 计算实际指标
        actual_return = np.mean(historical_portfolio_returns)
        actual_volatility = np.std(historical_portfolio_returns)
        actual_sharpe = actual_return / actual_volatility if actual_volatility > 0 else 0

        # 计算最大回撤
        cumulative_returns = np.cumprod(1 + historical_portfolio_returns)
        peak = np.maximum.accumulate(cumulative_returns)
        drawdown = (cumulative_returns - peak) / peak
        max_drawdown = abs(np.min(drawdown))

        # 计算跟踪误差（相对于等权重组合）
        equal_weights = np.ones(len(weights)) / len(weights)
        equal_weight_returns = historical_returns.dot(equal_weights)
        tracking_error = np.std(historical_portfolio_returns - equal_weight_returns)

        return {
            'historical_period': len(historical_returns),
            'actual_return': actual_return,
            'actual_volatility': actual_volatility,
            'actual_sharpe': actual_sharpe,
            'max_drawdown': max_drawdown,
            'tracking_error': tracking_error,
            'return_difference': actual_return - optimization_result.expected_return,
            'volatility_difference': actual_volatility - optimization_result.expected_volatility,
            'optimization_quality': 'good' if tracking_error < 0.05 else 'fair' if tracking_error < 0.1 else 'poor'
        }

    def create_sample_market_data() -> pd.DataFrame:
        """创建示例市场数据"""
        np.random.seed(42)

        # 创建5只股票的日收益率数据
        n_days = 500

        # 基础参数
        mu = np.array([0.001, 0.0008, 0.0012, 0.0009, 0.0011])  # 期望收益率
        sigma = np.array([0.02, 0.025, 0.018, 0.022, 0.019])    # 波动率
        # 创建协方差矩阵
        corr_matrix = np.array([
            [1.0, 0.3, 0.2, 0.1, 0.1],
            [0.3, 1.0, 0.4, 0.2, 0.1],
            [0.2, 0.4, 1.0, 0.3, 0.2],
            [0.1, 0.2, 0.3, 1.0, 0.4],
            [0.1, 0.1, 0.2, 0.4, 1.0]
        ])

        cov_matrix = np.outer(sigma, sigma) * corr_matrix

        # 生成收益率数据
        returns_data = np.secrets.multivariate_normal(mu, cov_matrix, n_days)

        # 创建DataFrame
        dates = pd.date_range('2023-01-01', periods=n_days, freq='D')
        asset_names = ['AAPL', 'GOOGL', 'MSFT', 'AMZN', 'TSLA']

        returns_df = pd.DataFrame(returns_data, columns=asset_names, index=dates)

        return returns_df

    @classmethod
    def main(cls):
        """主函数 - 高级风险模型演示"""
        print("🎯 RQA2025高级风险模型")
        print("=" * 50)

        # 创建示例市场数据
        print("📊 创建示例市场数据...")
        market_data = cls.create_sample_market_data()
        print(f"市场数据创建完成，形状 {market_data.shape}")
        print(f"   资产数量: {len(market_data.columns)}")
        print(f"   数据周期: {len(market_data)}天")

        # 显示数据统计
        print("\n📈 数据统计:")
        print(market_data.describe().round(4))

        # 1. VaR模型演示
        print("\n" + "=" * 50)
        print("📉 VaR模型演示")

        # 选择第一只股票的收益率
        returns = market_data['AAPL'].values

        # 创建不同类型的VaR模型
        models = {
            '历史模拟法': VaRModel(RiskModelType.HISTORICAL),
            '参数法': VaRModel(RiskModelType.PARAMETRIC),
            '蒙特卡洛模拟': VaRModel(RiskModelType.MONTE_CARLO)
        }

        var_results = {}

        for model_name, model in models.items():
            print(f"\n🔧 训练{model_name}...")
            model.fit(returns, n_simulations=10000)

            # 计算VaR
            result = model.calculate_var(confidence_level=0.95, time_horizon=1)
            var_results[model_name] = result

            print(f"   VaR(95%): {result.var_value:.4f}")
            print(f"   CVaR(95%): {result.cvar_value:.4f}")
            print(f"   计算时间: {result.calculation_time:.4f}秒")

        # 2. 压力测试演示
        print("\n" + "=" * 50)
        print("📊 压力测试演示")

        stress_model = StressTestModel()

        # 定义压力测试情景
        stress_model.define_scenario(
            '市场崩盘情景',
            stress_model.create_market_crash_scenario(crash_severity=0.4),
            '模拟40%的市场崩溃'
        )

        stress_model.define_scenario(
            '利率冲击情景',
            stress_model.create_interest_rate_shock_scenario(rate_change=0.03),
            '模拟3%的利率上升'
        )

        # 设置基准VaR
        stress_model.baseline_metrics['var_99'] = var_results['历史模拟法'].var_value

        # 运行压力测试
        for scenario in ['市场崩盘情景', '利率冲击情景']:
            print(f"\n🧪 运行{scenario}...")
            stress_result = stress_model.run_stress_test(returns, scenario)

            print(f"   压力下VaR: {stress_result['stressed_var']:.4f}")
            print(f"   VaR变化: {stress_result['var_change']:.2%}")
            print(f"   最大回撤: {stress_result['max_drawdown']:.2%}")
            print(f"   波动率增加: {stress_result['volatility_increase']:.2f}倍")

        # 3. 投资组合优化演示
        print("\n" + "=" * 50)
        print("🎯 投资组合优化演示")

        # 计算资产的期望收益率和协方差矩阵
        expected_returns = market_data.mean().values
        cov_matrix = market_data.cov().values

        print(f"   资产期望收益: {expected_returns}")
        print(f"   协方差矩阵形状: {cov_matrix.shape}")

        # 创建优化器
        optimizer = PortfolioOptimizer(OptimizationObjective.MAX_SHARPE)

        # 添加约束条件

        def long_only_constraint(weights):
            return weights  # 权重 >= 0 的约束在边界中处理
        optimizer.add_constraint(long_only_constraint, 'ineq')

        # 执行优化
        print("\n🔍 执行最大夏普比率优化...")
        optimization_result = optimizer.optimize(expected_returns, cov_matrix)

        if optimization_result:
            print(f"   优化状态: {optimization_result.convergence_status}")
            print(f"   期望收益: {optimization_result.expected_return:.4f}")
            print(f"   期望波动率: {optimization_result.expected_volatility:.4f}")
            print(f"   夏普比率: {optimization_result.sharpe_ratio:.4f}")
            print(f"   分散化比率: {optimization_result.diversification_ratio:.4f}")
            print(f"   优化时间: {optimization_result.optimization_time:.4f}秒")

            print("   最优权重:")
            for i, (asset, weight) in enumerate(zip(market_data.columns, optimization_result.weights)):
                print(f"     {asset}: {weight:.4f}")

        # 4. 模型验证演示
        print("\n" + "=" * 50)
        print("📊 模型验证演示")

        validator = RiskModelValidator()

        # VaR回测验证
        print("\n🔬 执行VaR回测验证...")
        backtest_result = validator.backtest_var(returns, models['历史模拟法'],
                                                 confidence_level=0.95, window_size=100)

        print(f"   观测数量: {backtest_result['total_observations']}")
        print(f"   违反次数: {backtest_result['violations']}")
        print(f"   实际违反率: {backtest_result['violation_rate']:.2%}")
        print(f"   期望违反率: {backtest_result['expected_violation_rate']:.2%}")
        print(f"   Kupiec p值: {backtest_result['kupiec_p_value']:.4f}")

        if backtest_result['kupiec_p_value'] > 0.05:
            print("   ✅ 模型通过Kupiec检验")
        else:
            print("   ❌ 模型未通过Kupiec检验")

        # 投资组合优化验证
        if optimization_result:
            print("\n📊 执行投资组合优化验证...")
            validation_result = validator.validate_portfolio_optimization(
                optimization_result, market_data
            )

            print(f"   历史周期: {validation_result['historical_period']}天")
            print(f"   实际收益: {validation_result['actual_return']:.4f}")
            print(f"   实际波动率: {validation_result['actual_volatility']:.4f}")
            print(f"   最大回撤: {validation_result['max_drawdown']:.2%}")
            print(f"   跟踪误差: {validation_result['tracking_error']:.4f}")
            print(f"   优化质量: {validation_result['optimization_quality']}")

        print("\n🎉 高级风险模型演示完成!")
        print("   专业的风险模型和优化算法已准备就绪!")
        print("   可以支持复杂的金融风险管理和投资组合优化")

        return {
            'var_results': var_results,
            'stress_test_results': stress_result,
            'optimization_result': optimization_result,
            'backtest_result': backtest_result,
            'validation_result': validation_result if optimization_result else None
        }

def calculate_expected_shortfall(returns: np.ndarray, confidence_level: float = 0.95) -> float:
    """
    计算期望亏空 (Expected Shortfall)

    Args:
        returns: 收益序列
        confidence_level: 置信水平

    Returns:
        float: 期望亏空值
    """
    if len(returns) == 0:
        raise ValueError("收益序列不能为空")

    # 计算VaR
    var_percentile = (1 - confidence_level) * 100
    var_value = np.percentile(returns, var_percentile)

    # 计算ES：VaR以下收益的平均值
    tail_returns = returns[returns <= var_value]

    if len(tail_returns) == 0:
        return var_value

    return float(np.mean(tail_returns))


def decompose_portfolio_risk(
    weights: np.ndarray,
    cov_matrix: np.ndarray,
    expected_returns: Optional[np.ndarray] = None) -> Dict[str, Any]:
    """
    分解投资组合风险

    Args:
        weights: 权重向量
        cov_matrix: 协方差矩阵
        expected_returns: 期望收益向量

    Returns:
        Dict[str, Any]: 风险分解结果
    """
    start_time = datetime.now()

    n_assets = len(weights)

    # 计算总风险
    portfolio_variance = np.dot(weights.T, np.dot(cov_matrix, weights))
    portfolio_volatility = np.sqrt(portfolio_variance)

    # 计算各资产的风险贡献
    marginal_contributions = np.dot(cov_matrix, weights)
    risk_contributions = weights * marginal_contributions

    # 计算百分比贡献
    total_risk_contribution = np.sum(risk_contributions)
    risk_contribution_percentages = risk_contributions / total_risk_contribution if total_risk_contribution != 0 else np.zeros(n_assets)

    # 计算多样化效应
    individual_volatilities = np.sqrt(np.diag(cov_matrix))
    weighted_volatility = np.sum(weights * individual_volatilities)
    diversification_ratio = portfolio_volatility / weighted_volatility if weighted_volatility != 0 else 1.0

    end_time = datetime.now()

    return {
        'portfolio_volatility': portfolio_volatility,
        'asset_risk_contributions': risk_contributions.tolist(),
        'risk_contribution_percentages': risk_contribution_percentages.tolist(),
        'diversification_ratio': diversification_ratio,
        'calculation_time': (end_time - start_time).total_seconds()
    }


    if __name__ == "__main__":
        results = main()
