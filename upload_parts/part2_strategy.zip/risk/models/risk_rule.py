"""风险规则定义"""
from typing import Dict, Any, List
from enum import Enum
import logging

logger = logging.getLogger(__name__)


class RiskRuleType(Enum):
    """风险规则类型"""
    THRESHOLD = "threshold"
    TREND = "trend"
    VOLATILITY = "volatility"
    CORRELATION = "correlation"
    PORTFOLIO = "portfolio"


class RiskRule:
    """风险规则基类"""

    def __init__(self, rule_id: str, rule_type: RiskRuleType, config: Dict[str, Any]):
        self.rule_id = rule_id
        self.rule_type = rule_type
        self.config = config
        self.enabled = True
        self.last_triggered = None

    def evaluate(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """评估风险规则"""
        raise NotImplementedError("子类必须实现evaluate方法")

    def is_triggered(self, data: Dict[str, Any]) -> bool:
        """检查规则是否被触发"""
        result = self.evaluate(data)
        return result.get('triggered', False)

    def get_description(self) -> str:
        """获取规则描述"""
        return f"{self.rule_type.value} rule: {self.rule_id}"


class ThresholdRule(RiskRule):
    """阈值规则"""

    def __init__(self, rule_id: str, metric_name: str, threshold: float, operator: str = "gt"):
        super().__init__(
            rule_id=rule_id,
            rule_type=RiskRuleType.THRESHOLD,
            config={
                'metric_name': metric_name,
                'threshold': threshold,
                'operator': operator
            }
        )
        self.metric_name = metric_name
        self.threshold = threshold
        self.operator = operator

    def evaluate(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """评估阈值规则"""
        if self.metric_name not in data:
            return {'triggered': False, 'reason': f'Metric {self.metric_name} not found'}

        value = data[self.metric_name]

        triggered = False
        if self.operator == "gt" and value > self.threshold:
            triggered = True
        elif self.operator == "lt" and value < self.threshold:
            triggered = True
        elif self.operator == "ge" and value >= self.threshold:
            triggered = True
        elif self.operator == "le" and value <= self.threshold:
            triggered = True

        if triggered:
            self.last_triggered = data.get('timestamp')

        return {
            'triggered': triggered,
            'metric_value': value,
            'threshold': self.threshold,
            'operator': self.operator
        }


class VolatilityRule(RiskRule):
    """波动率规则"""

    def __init__(self, rule_id: str, window: int = 20, threshold: float = 0.05):
        super().__init__(
            rule_id=rule_id,
            rule_type=RiskRuleType.VOLATILITY,
            config={
                'window': window,
                'threshold': threshold
            }
        )
        self.window = window
        self.threshold = threshold
        self.price_history = []

    def evaluate(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """评估波动率规则"""
        if 'price' not in data:
            return {'triggered': False, 'reason': 'Price data not found'}

        price = data['price']
        self.price_history.append(price)

        # 保持窗口大小
        if len(self.price_history) > self.window:
            self.price_history.pop(0)

        if len(self.price_history) < 2:
            return {'triggered': False, 'reason': 'Insufficient data'}

        # 计算波动率（简化版）
        returns = []
        for i in range(1, len(self.price_history)):
            ret = (self.price_history[i] - self.price_history[i-1]) / self.price_history[i-1]
            returns.append(ret)

        if not returns:
            return {'triggered': False, 'reason': 'No returns calculated'}

        volatility = sum(abs(r) for r in returns) / len(returns)

        triggered = volatility > self.threshold

        if triggered:
            self.last_triggered = data.get('timestamp')

        return {
            'triggered': triggered,
            'volatility': volatility,
            'threshold': self.threshold,
            'window_size': len(self.price_history)
        }


class RiskRuleEngine:
    """风险规则引擎"""

    def __init__(self):
        self.rules: Dict[str, RiskRule] = {}
        self.rule_groups: Dict[str, List[str]] = {}

    def add_rule(self, rule: RiskRule, group: str = "default") -> bool:
        """添加风险规则"""
        try:
            self.rules[rule.rule_id] = rule

            if group not in self.rule_groups:
                self.rule_groups[group] = []

            if rule.rule_id not in self.rule_groups[group]:
                self.rule_groups[group].append(rule.rule_id)

            logger.info(f"添加风险规则: {rule.rule_id} 到组: {group}")
            return True
        except Exception as e:
            logger.error(f"添加风险规则失败: {e}")
            return False

    def remove_rule(self, rule_id: str) -> bool:
        """移除风险规则"""
        try:
            if rule_id in self.rules:
                del self.rules[rule_id]

                # 从所有组中移除
                for group in self.rule_groups.values():
                    if rule_id in group:
                        group.remove(rule_id)

                logger.info(f"移除风险规则: {rule_id}")
                return True
            return False
        except Exception as e:
            logger.error(f"移除风险规则失败: {e}")
            return False

    def evaluate_rules(self, data: Dict[str, Any], group: str = None) -> Dict[str, Any]:
        """评估风险规则"""
        results = {
            'total_rules': 0,
            'triggered_rules': [],
            'rule_results': {},
            'summary': {
                'total_triggered': 0,
                'high_priority_triggers': 0
            }
        }

        # 确定要评估的规则
        if group and group in self.rule_groups:
            rule_ids = self.rule_groups[group]
        else:
            rule_ids = list(self.rules.keys())

        results['total_rules'] = len(rule_ids)

        for rule_id in rule_ids:
            if rule_id in self.rules:
                rule = self.rules[rule_id]
                try:
                    rule_result = rule.evaluate(data)
                    results['rule_results'][rule_id] = rule_result

                    if rule_result.get('triggered', False):
                        results['triggered_rules'].append({
                            'rule_id': rule_id,
                            'rule_type': rule.rule_type.value,
                            'result': rule_result
                        })
                        results['summary']['total_triggered'] += 1

                        # 检查是否为高优先级触发（简化逻辑）
                        if rule.rule_type in [RiskRuleType.THRESHOLD]:
                            results['summary']['high_priority_triggers'] += 1

                except Exception as e:
                    logger.error(f"评估规则 {rule_id} 失败: {e}")
                    results['rule_results'][rule_id] = {
                        'error': str(e),
                        'triggered': False
                    }

        return results

    def get_rule_status(self) -> Dict[str, Any]:
        """获取规则状态"""
        return {
            'total_rules': len(self.rules),
            'rule_groups': self.rule_groups,
            'rules': {
                rule_id: {
                    'type': rule.rule_type.value,
                    'enabled': rule.enabled,
                    'last_triggered': rule.last_triggered
                }
                for rule_id, rule in self.rules.items()
            }
        }

    def enable_rule(self, rule_id: str) -> bool:
        """启用规则"""
        if rule_id in self.rules:
            self.rules[rule_id].enabled = True
            return True
        return False

    def disable_rule(self, rule_id: str) -> bool:
        """禁用规则"""
        if rule_id in self.rules:
            self.rules[rule_id].enabled = False
            return True
        return False
