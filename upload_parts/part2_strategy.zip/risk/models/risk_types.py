"""风险计算引擎类型定义"""

from enum import Enum
from dataclasses import dataclass, field
from typing import Dict, Any, Tuple, Union
from datetime import datetime


class RiskMetricType(Enum):
    """风险指标类型枚举"""
    VAR = "var"  # Value at Risk
    CVAR = "cvar"  # Conditional Value at Risk
    VOLATILITY = "volatility"  # 波动率
    SHARPE = "sharpe"  # 夏普比率
    MAX_DRAWDOWN = "max_drawdown"  # 最大回撤
    BETA = "beta"  # 贝塔系数
    CORRELATION = "correlation"  # 相关性
    LIQUIDITY = "liquidity"  # 流动性
    CONCENTRATION = "concentration"  # 集中度
    POSITION = "position"  # 仓位风险
    STRESS_TEST = "stress_test"  # 压力测试


class ConfidenceLevel(Enum):
    """置信水平枚举"""
    CL_90 = 0.90
    CL_95 = 0.95
    CL_99 = 0.99


@dataclass
class RiskCalculationConfig:
    """风险计算配置"""
    confidence_level: float = 0.95
    time_horizon: int = 1
    simulation_count: int = 10000
    enable_cache: bool = True
    enable_gpu: bool = False
    enable_parallel: bool = True
    max_workers: int = 4
    historical_window_days: int = 252  # 默认一年交易日数


@dataclass
class RiskCalculationResult:
    """风险计算结果"""
    metric_type: Union[str, RiskMetricType]
    value: float
    confidence_level: float
    calculation_time: float
    timestamp: datetime
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class PortfolioRiskProfile:
    """投资组合风险画像"""
    var: float
    cvar: float
    volatility: float
    max_drawdown: float
    sharpe_ratio: float
    beta: float
    timestamp: datetime
    metadata: Dict[str, Any] = field(default_factory=dict)


__all__ = [
    'RiskMetricType',
    'ConfidenceLevel',
    'RiskCalculationConfig',
    'RiskCalculationResult',
    'PortfolioRiskProfile'
]

