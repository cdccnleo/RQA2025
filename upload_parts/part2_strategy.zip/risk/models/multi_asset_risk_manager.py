#!/usr/bin/env python3
"""
# 多资产风险管理器

支持股票、期货、外汇、期权等多种资产类别的风险计算和管理
"""

import logging
import numpy as np
from typing import Dict, Any, Optional
from datetime import datetime
from dataclasses import dataclass, field
from enum import Enum
import threading
from collections import defaultdict, deque

logger = logging.getLogger(__name__)


class AssetType(Enum):

    """资产类型枚举"""
    STOCK = "stock"                    # 股票
    FUTURE = "future"                  # 期货
    OPTION = "option"                  # 期权
    FOREX = "forex"                    # 外汇
    BOND = "bond"                      # 债券
    COMMODITY = "commodity"            # 商品
    CRYPTO = "crypto"                  # 加密货币
    ETF = "etf"                        # ETF
    INDEX = "index"                    # 指数


class AssetClass(Enum):

    """资产大类枚举"""
    EQUITY = "equity"                  # 权益类
    FIXED_INCOME = "fixed_income"      # 固定收益
    DERIVATIVES = "derivatives"        # 衍生品
    COMMODITIES = "commodities"        # 商品
    CURRENCIES = "currencies"          # 货币
    ALTERNATIVE = "alternative"        # 另类投资


@dataclass
class AssetConfig:

    """资产配置"""
    asset_type: AssetType
    symbol: str
    currency: str = "CNY"              # 计价货币
    exchange: str = ""                 # 交易所
    contract_size: float = 1.0         # 合约规模
    tick_size: float = 0.01            # 最小价格变动
    multiplier: float = 1.0            # 合约乘数
    margin_requirement: float = 0.0    # 保证金要求
    trading_hours: Dict[str, str] = field(default_factory=dict)  # 交易时间


@dataclass
class AssetPosition:

    """资产持仓"""
    symbol: str
    asset_type: AssetType
    quantity: float                    # 持仓数量
    average_price: float              # 平均成本价
    current_price: float              # 当前价格
    market_value: float               # 市值
    unrealized_pnl: float             # 未实现盈亏
    currency: str = "CNY"             # 计价货币


@dataclass
class MultiAssetRiskMetrics:

    """多资产风险指标"""
    total_value: float = 0.0           # 总市值
    total_risk: float = 0.0            # 总风险
    portfolio_volatility: float = 0.0  # 组合波动率
    portfolio_var: float = 0.0         # 组合VaR
    diversification_ratio: float = 0.0  # 多元化比率
    concentration_index: float = 0.0   # 集中度指数
    # 按资产类别划分的风险
    asset_class_risk: Dict[AssetClass, float] = field(default_factory=dict)
    asset_type_risk: Dict[AssetType, float] = field(default_factory=dict)

    # 相关性矩阵
    correlation_matrix: Dict[str, Dict[str, float]] = field(default_factory=dict)

    timestamp: datetime = field(default_factory=datetime.now)


@dataclass
class AssetSpecificRisk:

    """资产特定风险"""
    symbol: str
    asset_type: AssetType
    volatility: float = 0.0            # 波动率
    beta: float = 1.0                  # 贝塔系数
    liquidity_risk: float = 0.0        # 流动性风险
    credit_risk: float = 0.0           # 信用风险
    market_risk: float = 0.0           # 市场风险
    specific_risk: float = 0.0         # 特质风险

    # 衍生品特定风险
    delta: float = 0.0                 # Delta (期权)
    gamma: float = 0.0                 # Gamma (期权)
    vega: float = 0.0                  # Vega (期权)
    theta: float = 0.0                 # Theta (期权)
    rho: float = 0.0                   # Rho (期权)

    timestamp: datetime = field(default_factory=datetime.now)


class MultiAssetRiskManager:

    """多资产风险管理器"""

    def __init__(self, config: Optional[Dict[str, Any]] = None):

        self.config = config or {}
        self.lock = threading.RLock()

        # 资产配置管理
        self.asset_configs: Dict[str, AssetConfig] = {}
        self.asset_class_mapping: Dict[AssetType,
                                       AssetClass] = self._initialize_asset_class_mapping()

        # 持仓管理
        self.positions: Dict[str, AssetPosition] = {}

        # 风险指标缓存
        self.risk_cache = defaultdict(lambda: deque(maxlen=1000))
        self.correlation_cache = defaultdict(lambda: deque(maxlen=500))

        # 市场数据缓存
        self.market_data_cache = defaultdict(lambda: deque(maxlen=1000))

    logger.info("多资产风险管理器初始化完成")

    def _initialize_asset_class_mapping(self) -> Dict[AssetType, AssetClass]:
        """初始化资产类型到资产大类的映射"""
        return {
            AssetType.STOCK: AssetClass.EQUITY,
            AssetType.ETF: AssetClass.EQUITY,
            AssetType.INDEX: AssetClass.EQUITY,
            AssetType.FUTURE: AssetClass.DERIVATIVES,
            AssetType.OPTION: AssetClass.DERIVATIVES,
            AssetType.FOREX: AssetClass.CURRENCIES,
            AssetType.BOND: AssetClass.FIXED_INCOME,
            AssetType.COMMODITY: AssetClass.COMMODITIES,
            AssetType.CRYPTO: AssetClass.ALTERNATIVE
        }

    def register_asset(self, asset_config: AssetConfig):
        """注册资产配置"""
        with self.lock:
            self.asset_configs[asset_config.symbol] = asset_config
        logger.info(f"注册资产: {asset_config.symbol} ({asset_config.asset_type.value})")

    def update_position(self, symbol: str, quantity: float, price: float,

                        current_price: Optional[float] = None):
        """更新持仓信息"""
        with self.lock:
            if symbol not in self.asset_configs:
                logger.warning(f"资产 {symbol} 未注册，使用默认配置")
                # 创建默认配置

                default_config = AssetConfig(
                    asset_type=AssetType.STOCK,
                    symbol=symbol
                )
                self.register_asset(default_config)

            asset_config = self.asset_configs[symbol]

            if current_price is None:
                current_price = price

            # 计算市值和未实现盈亏
            market_value = quantity * current_price
            unrealized_pnl = (current_price - price) * quantity

            position = AssetPosition(
                symbol=symbol,
                asset_type=asset_config.asset_type,
                quantity=quantity,
                average_price=price,
                current_price=current_price,
                market_value=market_value,
                unrealized_pnl=unrealized_pnl,
                currency=asset_config.currency
            )

            self.positions[symbol] = position
            logger.debug(f"更新持仓: {symbol}, 数量: {quantity}, 市值: {market_value:.2f}")

    def calculate_portfolio_risk(self, market_data: Optional[Dict[str, Dict[str, Any]]] = None) -> MultiAssetRiskMetrics:
        """
        计算多资产组合风险
        Args:
            market_data: 市场数据字典 {symbol: data}

        Returns:
            多资产风险指标
        """
        with self.lock:
            try:
                if not self.positions:
                    return MultiAssetRiskMetrics()

                # 更新市场数据
                if market_data:
                    self._update_market_data(market_data)

                # 计算基础风险指标
                risk_metrics = self._calculate_basic_risk_metrics()

                # 计算相关性矩阵
                risk_metrics.correlation_matrix = self._calculate_correlation_matrix()

                # 计算多元化指标
                risk_metrics.diversification_ratio = self._calculate_diversification_ratio()

                # 计算集中度指标
                risk_metrics.concentration_index = self._calculate_concentration_index()

                # 按资产类别分组计算风险
                risk_metrics.asset_class_risk = self._calculate_asset_class_risk()
                risk_metrics.asset_type_risk = self._calculate_asset_type_risk()

                return risk_metrics

            except Exception as e:
                logger.error(f"计算组合风险失败: {e}")
                return MultiAssetRiskMetrics()

    def _calculate_basic_risk_metrics(self) -> MultiAssetRiskMetrics:
        """计算基础风险指标"""
        try:
            metrics = MultiAssetRiskMetrics()

            # 计算总市值
            total_value = 0.0
            position_values = []
            position_weights = []

            for position in self.positions.values():
                position_value = abs(position.market_value)
                total_value += position_value
                position_values.append(position_value)
                position_weights.append(position_value / max(total_value, 1))

            metrics.total_value = total_value

            if not position_values:
                return metrics

            # 计算组合波动率（简化版，使用加权平均）
            asset_volatilities = []
            for symbol, position in self.positions.items():
                asset_risk = self._calculate_asset_specific_risk(symbol, position)
                asset_volatilities.append(asset_risk.volatility)

            if asset_volatilities:
                # 加权平均波动率
                metrics.portfolio_volatility = np.average(
                    asset_volatilities,
                    weights=position_weights
                )

                # 估算VaR（简化版）
                metrics.portfolio_var = (
                    metrics.portfolio_volatility
                    * metrics.total_value
                    * 2.33  # 99% 置信水平下的Z分数
                )

            metrics.total_risk = metrics.portfolio_var

            return metrics

        except Exception as e:
            logger.error(f"计算基础风险指标失败: {e}")
            return MultiAssetRiskMetrics()

    def _calculate_correlation_matrix(self) -> Dict[str, Dict[str, float]]:
        """计算相关性矩阵"""
        try:
            symbols = list(self.positions.keys())
            if len(symbols) < 2:
                return {}

            correlation_matrix = {}

            # 使用历史收益率数据计算相关性
            for i, symbol1 in enumerate(symbols):
                correlation_matrix[symbol1] = {}
                for symbol2 in symbols:
                    if symbol1 == symbol2:
                        correlation_matrix[symbol1][symbol2] = 1.0
                    else:
                        # 从缓存中获取历史相关性数据
                        correlation_key = f"{symbol1}_{symbol2}"
                        if correlation_key in self.correlation_cache:
                            recent_correlations = list(self.correlation_cache[correlation_key])
                            if recent_correlations:
                                correlation_matrix[symbol1][symbol2] = recent_correlations[-1]
                            else:
                                correlation_matrix[symbol1][symbol2] = 0.0
                        else:
                            # 默认相关性（根据资产类型估算）
                            correlation_matrix[symbol1][symbol2] = self._estimate_default_correlation(
                                self.positions[symbol1].asset_type,
                                self.positions[symbol2].asset_type
                            )

            return correlation_matrix

        except Exception as e:
            logger.error(f"计算相关性矩阵失败: {e}")
            return {}

    def _estimate_default_correlation(self, asset_type1: AssetType, asset_type2: AssetType) -> float:
        """估算默认相关性"""
        try:
            # 相同资产类型的高相关性
            if asset_type1 == asset_type2:
                return 0.8

            # 不同资产类型的基本相关性
            correlation_map = {
                (AssetType.STOCK, AssetType.BOND): 0.1,
                (AssetType.STOCK, AssetType.COMMODITY): 0.2,
                (AssetType.STOCK, AssetType.FOREX): 0.1,
                (AssetType.BOND, AssetType.COMMODITY): 0.0,
                (AssetType.BOND, AssetType.FOREX): 0.3,
                (AssetType.COMMODITY, AssetType.FOREX): 0.4,
            }

            # 检查正向和反向映射
            for (type1, type2), corr in correlation_map.items():
                if (asset_type1 == type1 and asset_type2 == type2) or \
                   (asset_type1 == type2 and asset_type2 == type1):
                    return corr

            # 默认相关性
            return 0.2

        except Exception as e:
            logger.error(f"估算默认相关性失败: {e}")
            return 0.0

    def _calculate_diversification_ratio(self) -> float:
        """计算多元化比率"""
        try:
            if not self.positions:
                return 0.0

            position_values = [abs(p.market_value) for p in self.positions.values()]
            total_value = sum(position_values)

            if total_value == 0:
                return 0.0

            # 计算Herfindahl-Hirschman指数的倒数作为多元化比率
            hhi = sum((value / total_value) ** 2 for value in position_values)
            diversification_ratio = 1 / hhi if hhi > 0 else 0.0

            return diversification_ratio

        except Exception as e:
            logger.error(f"计算多元化比率失败: {e}")
            return 0.0

    def _calculate_concentration_index(self) -> float:
        """计算集中度指数"""
        try:
            if not self.positions:
                return 0.0

            position_values = [abs(p.market_value) for p in self.positions.values()]
            total_value = sum(position_values)

            if total_value == 0:
                return 0.0

            # 计算最大持仓占比
            max_position_ratio = max(value / total_value for value in position_values)
            concentration_index = max_position_ratio

            return concentration_index

        except Exception as e:
            logger.error(f"计算集中度指数失败: {e}")
            return 0.0

    def _calculate_asset_class_risk(self) -> Dict[AssetClass, float]:
        """计算按资产大类的风险分布"""
        try:
            asset_class_values = defaultdict(float)
            asset_class_risk = {}

            # 按资产大类汇总市值
            for symbol, position in self.positions.items():
                asset_class = self.asset_class_mapping.get(
                    position.asset_type, AssetClass.ALTERNATIVE)
                asset_class_values[asset_class] += abs(position.market_value)

            total_value = sum(asset_class_values.values())
            if total_value == 0:
                return {}

            # 计算各资产大类的风险占比（简化版）
            for asset_class, value in asset_class_values.items():
                # 使用市值占比作为风险占比的近似
                asset_class_risk[asset_class] = value / total_value

            return asset_class_risk

        except Exception as e:
            logger.error(f"计算资产大类风险失败: {e}")
            return {}

    def _calculate_asset_type_risk(self) -> Dict[AssetType, float]:
        """计算按资产类型的风险分布"""
        try:
            asset_type_values = defaultdict(float)
            asset_type_risk = {}

            # 按资产类型汇总市值
            for symbol, position in self.positions.items():
                asset_type_values[position.asset_type] += abs(position.market_value)

            total_value = sum(asset_type_values.values())
            if total_value == 0:
                return {}

            # 计算各资产类型的风险占比
            for asset_type, value in asset_type_values.items():
                asset_type_risk[asset_type] = value / total_value

            return asset_type_risk

        except Exception as e:
            logger.error(f"计算资产类型风险失败: {e}")
            return {}

    def _calculate_asset_specific_risk(self, symbol: str, position: AssetPosition) -> AssetSpecificRisk:
        """计算资产特定风险"""
        try:
            asset_risk = AssetSpecificRisk(
                symbol=symbol,
                asset_type=position.asset_type,
                timestamp=datetime.now()
            )

            # 从市场数据缓存中获取波动率等指标
            if symbol in self.market_data_cache and self.market_data_cache[symbol]:
                recent_data = self.market_data_cache[symbol][-1]

                # 获取波动率
                asset_risk.volatility = recent_data.get('volatility', 0.02)

                # 获取流动性指标
                daily_volume = recent_data.get('daily_volume', 1000000)
                avg_volume = recent_data.get('avg_volume', daily_volume)
                asset_risk.liquidity_risk = 1 / (avg_volume / 1000000 + 1)  # 流动性风险
                # 估算贝塔系数（简化版）
                asset_risk.beta = recent_data.get('beta', 1.0)

                # 估算信用风险和市场风险
                if position.asset_type == AssetType.BOND:
                    asset_risk.credit_risk = 0.05  # 债券信用风险较高
                elif position.asset_type in [AssetType.STOCK, AssetType.ETF]:
                    asset_risk.market_risk = asset_risk.volatility * 0.8
                    asset_risk.specific_risk = asset_risk.volatility * 0.2
                elif position.asset_type in [AssetType.FUTURE, AssetType.OPTION]:
                    # 衍生品风险更高
                    asset_risk.market_risk = asset_risk.volatility * 1.2
                    asset_risk.specific_risk = asset_risk.volatility * 0.5

                    # 期权Greeks（简化估算）
                    if position.asset_type == AssetType.OPTION:
                        asset_risk.delta = 0.6  # Delta
                        asset_risk.gamma = 0.1  # Gamma
                        asset_risk.vega = 0.2   # Vega
                        asset_risk.theta = -0.05  # Theta
                        asset_risk.rho = 0.1    # Rho

            return asset_risk

        except Exception as e:
            logger.error(f"计算资产特定风险失败: {e}")
            return AssetSpecificRisk(symbol=symbol, asset_type=position.asset_type)

    def _update_market_data(self, market_data: Dict[str, Dict[str, Any]]):
        """更新市场数据"""
        try:
            for symbol, data in market_data.items():
                data_record = {
                    'timestamp': datetime.now(),
                    'symbol': symbol,
                    **data
                }
                self.market_data_cache[symbol].append(data_record)

                # 更新持仓的当前价格
                if symbol in self.positions and 'price' in data:
                    self.positions[symbol].current_price = data['price']
                    # 重新计算市值和未实现盈亏
                    position = self.positions[symbol]
                    position.market_value = position.quantity * position.current_price
                    position.unrealized_pnl = (position.current_price -
                                               position.average_price) * position.quantity

        except Exception as e:
            logger.error(f"更新市场数据失败: {e}")

    def get_asset_allocation(self) -> Dict[str, Any]:
        """获取资产配置信息"""
        try:
            allocation = {
                'total_positions': len(self.positions),
                'asset_class_allocation': {},
                'asset_type_allocation': {},
                'currency_allocation': {},
                'geographic_allocation': {},
                'sector_allocation': {}
            }

            if not self.positions:
                return allocation

            # 计算总市值
            total_value = sum(abs(p.market_value) for p in self.positions.values())

            # 按资产大类分组
            asset_class_values = defaultdict(float)
            asset_type_values = defaultdict(float)
            currency_values = defaultdict(float)

            for position in self.positions.values():
                asset_class = self.asset_class_mapping.get(
                    position.asset_type, AssetClass.ALTERNATIVE)
                asset_class_values[asset_class] += abs(position.market_value)
                asset_type_values[position.asset_type] += abs(position.market_value)
                currency_values[position.currency] += abs(position.market_value)

            # 计算占比
            for asset_class, value in asset_class_values.items():
                allocation['asset_class_allocation'][asset_class.value] = value / total_value

            for asset_type, value in asset_type_values.items():
                allocation['asset_type_allocation'][asset_type.value] = value / total_value

            for currency, value in currency_values.items():
                allocation['currency_allocation'][currency] = value / total_value

            return allocation

        except Exception as e:
            logger.error(f"获取资产配置失败: {e}")
            return {}

    def get_risk_attribution(self) -> Dict[str, Any]:
        """获取风险归因分析"""
        try:
            attribution = {
                'total_risk': 0.0,
                'systematic_risk': 0.0,
                'idiosyncratic_risk': 0.0,
                'asset_risk_contribution': {},
                'factor_risk_contribution': {}
            }

            if not self.positions:
                return attribution

            # 计算总风险
            risk_metrics = self.calculate_portfolio_risk()
            attribution['total_risk'] = risk_metrics.portfolio_volatility

            # 估算系统性风险和特质风险
            total_market_risk = 0.0
            total_specific_risk = 0.0

            for symbol, position in self.positions.items():
                asset_risk = self._calculate_asset_specific_risk(symbol, position)
                total_market_risk += asset_risk.market_risk
                total_specific_risk += asset_risk.specific_risk

                # 资产风险贡献
                position_weight = abs(position.market_value) / risk_metrics.total_value
                attribution['asset_risk_contribution'][symbol] = {
                    'weight': position_weight,
                    'risk_contribution': position_weight * asset_risk.volatility
                }

            attribution['systematic_risk'] = total_market_risk
            attribution['idiosyncratic_risk'] = total_specific_risk

            return attribution

        except Exception as e:
            logger.error(f"获取风险归因失败: {e}")
            return {}

    def generate_risk_report(self) -> Dict[str, Any]:
        """生成风险报告"""
        try:
            report = {
                'report_timestamp': datetime.now(),
                'portfolio_summary': self.get_asset_allocation(),
                'risk_metrics': {},
                'risk_attribution': self.get_risk_attribution(),
                'recommendations': []
            }

            # 计算风险指标
            risk_metrics = self.calculate_portfolio_risk()
            report['risk_metrics'] = {
                'total_value': risk_metrics.total_value,
                'total_risk': risk_metrics.total_risk,
                'portfolio_volatility': risk_metrics.portfolio_volatility,
                'portfolio_var': risk_metrics.portfolio_var,
                'diversification_ratio': risk_metrics.diversification_ratio,
                'concentration_index': risk_metrics.concentration_index
            }

            # 生成建议
            recommendations = []

            # 多元化建议
            if risk_metrics.diversification_ratio < 5:
                recommendations.append({
                    'type': 'diversification',
                    'priority': 'high',
                    'message': '建议增加资产多元化，当前多元化比率较低',
                    'action': '考虑增加不同资产类别的配置'
                })

            # 集中度建议
            if risk_metrics.concentration_index > 0.3:
                recommendations.append({
                    'type': 'concentration',
                    'priority': 'high',
                    'message': '单一资产占比过高，存在集中风险',
                    'action': '建议降低最大持仓占比'
                })

            # 波动率建议
            if risk_metrics.portfolio_volatility > 0.25:
                recommendations.append({
                    'type': 'volatility',
                    'priority': 'medium',
                    'message': '组合波动率较高',
                    'action': '考虑增加低波动率资产配置'
                })

            report['recommendations'] = recommendations

            return report

        except Exception as e:
            logger.error(f"生成风险报告失败: {e}")
            return {}
