# Trading HFT Module
