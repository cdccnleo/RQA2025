# 模型层API文档

## 概述

模型层（src/models）提供了完整的机器学习模型、训练、评估、预测和部署功能。采用分层架构设计，确保模型处理的模块化和可扩展性。

## 架构分层

### 1. 核心组件层
提供基础模型、模型管理和模型评估功能。

### 2. 训练器模块层
提供模型训练、验证和优化功能。

### 3. 预测器模块层
提供模型预测和推理功能。

### 4. 评估器模块层
提供模型评估和指标计算功能。

### 5. 部署模块层
提供模型部署和服务功能。

### 6. 集成模块层
提供模型集成和集成学习功能。

## 核心组件

### BaseModel

基础模型类，定义模型的标准接口。

### 具体模型实现

#### XGBoostModel

XGBoost模型的具体实现。

```python
from src.models import XGBoostModel

# 创建XGBoost模型
config = {
    'n_estimators': 100,
    'max_depth': 6,
    'learning_rate': 0.1,
    'random_state': 42
}
model = XGBoostModel(config)

# 训练模型
model.train(X_train, y_train)

# 预测
predictions = model.predict(X_test)

# 评估
metrics = model.evaluate(X_test, y_test)
```

#### RandomForestModel

RandomForest模型的具体实现。

```python
from src.models import RandomForestModel

# 创建RandomForest模型
config = {
    'n_estimators': 100,
    'max_depth': 10,
    'random_state': 42
}
model = RandomForestModel(config)

# 训练模型
model.train(X_train, y_train)

# 预测
predictions = model.predict(X_test)

# 评估
metrics = model.evaluate(X_test, y_test)
```

### ModelFactory

模型工厂类，提供统一的模型创建接口。

```python
from src.models import ModelFactory

# 创建XGBoost模型
xgb_model = ModelFactory.create_model('xgboost', {
    'n_estimators': 100,
    'max_depth': 6
})

# 创建RandomForest模型
rf_model = ModelFactory.create_model('random_forest', {
    'n_estimators': 100,
    'max_depth': 10
})

# 列出可用模型类型
available_models = ModelFactory.list_available_models()
print(f"可用模型类型: {available_models}")
```

```python
from src.models import BaseModel

class CustomModel(BaseModel):
    """自定义模型实现"""
    
    def __init__(self, config=None):
        super().__init__(config)
        self.model = None
        self.is_trained = False
    
    def train(self, X, y, **kwargs):
        """训练模型"""
        # 实现训练逻辑
        self.model = self._create_model()
        self.model.fit(X, y)
        self.is_trained = True
        return self
    
    def predict(self, X):
        """预测"""
        if not self.is_trained:
            raise ValueError("模型未训练")
        return self.model.predict(X)
    
    def save(self, path):
        """保存模型"""
        # 实现保存逻辑
        pass
    
    def load(self, path):
        """加载模型"""
        # 实现加载逻辑
        pass
```

### ModelManager

模型管理器，负责模型的创建、管理和生命周期。

```python
from src.models import ModelManager

# 初始化模型管理器
manager = ModelManager()

# 创建模型
model = manager.create_model(
    model_type='xgboost',
    config={
        'n_estimators': 100,
        'max_depth': 6,
        'learning_rate': 0.1
    }
)

# 注册模型
manager.register_model('my_model', model)

# 获取模型
retrieved_model = manager.get_model('my_model')

# 列出所有模型
models = manager.list_models()
print(f"已注册模型: {models}")

# 删除模型
manager.delete_model('my_model')

# 保存模型
manager.save_model('my_model', 'models/my_model.pkl')

# 加载模型
loaded_model = manager.load_model('models/my_model.pkl')
```

### ModelEvaluator

模型评估器，负责模型性能评估和指标计算。

```python
from src.models import ModelEvaluator

# 初始化模型评估器
evaluator = ModelEvaluator()

# 评估模型
metrics = evaluator.evaluate(
    model=trained_model,
    X_test=X_test,
    y_test=y_test,
    metrics=['accuracy', 'precision', 'recall', 'f1', 'auc']
)

print(f"准确率: {metrics['accuracy']:.4f}")
print(f"精确率: {metrics['precision']:.4f}")
print(f"召回率: {metrics['recall']:.4f}")
print(f"F1分数: {metrics['f1']:.4f}")
print(f"AUC: {metrics['auc']:.4f}")

# 交叉验证
cv_scores = evaluator.cross_validate(
    model=model,
    X=X,
    y=y,
    cv=5,
    scoring='accuracy'
)

print(f"交叉验证分数: {cv_scores}")
print(f"平均分数: {cv_scores.mean():.4f}")
print(f"标准差: {cv_scores.std():.4f}")

# 混淆矩阵
confusion_matrix = evaluator.confusion_matrix(
    model=trained_model,
    X_test=X_test,
    y_test=y_test
)

print(f"混淆矩阵:\n{confusion_matrix}")

# 分类报告
classification_report = evaluator.classification_report(
    model=trained_model,
    X_test=X_test,
    y_test=y_test
)

print(f"分类报告:\n{classification_report}")
```

## 训练器模块

### ModelTrainer

模型训练器，负责模型训练和优化。

```python
from src.models import ModelTrainer

# 初始化模型训练器
trainer = ModelTrainer()

# 训练模型
trained_model = trainer.train(
    model=model,
    X_train=X_train,
    y_train=y_train,
    validation_data=(X_val, y_val),
    epochs=100,
    batch_size=32,
    callbacks=['early_stopping', 'model_checkpoint']
)

# 获取训练历史
history = trainer.get_training_history()
print(f"训练损失: {history['loss']}")
print(f"验证损失: {history['val_loss']}")

# 超参数优化
best_params = trainer.optimize_hyperparameters(
    model=model,
    X_train=X_train,
    y_train=y_train,
    param_grid={
        'n_estimators': [50, 100, 200],
        'max_depth': [3, 6, 9],
        'learning_rate': [0.01, 0.1, 0.2]
    },
    cv=5,
    scoring='accuracy'
)

print(f"最佳参数: {best_params}")

# 特征重要性
feature_importance = trainer.get_feature_importance(trained_model)
print(f"特征重要性: {feature_importance}")
```

### ModelValidator

模型验证器，负责模型验证和诊断。

```python
from src.models import ModelValidator

# 初始化模型验证器
validator = ModelValidator()

# 验证模型
validation_results = validator.validate(
    model=trained_model,
    X_val=X_val,
    y_val=y_val
)

print(f"验证结果: {validation_results}")

# 模型诊断
diagnosis = validator.diagnose_model(
    model=trained_model,
    X_train=X_train,
    y_train=y_train,
    X_val=X_val,
    y_val=y_val
)

print(f"模型诊断: {diagnosis}")

# 过拟合检测
overfitting_detected = validator.detect_overfitting(
    model=trained_model,
    X_train=X_train,
    y_train=y_train,
    X_val=X_val,
    y_val=y_val
)

if overfitting_detected:
    print("检测到过拟合，建议调整模型参数")
```

## 预测器模块

### ModelPredictor

模型预测器，负责模型预测和推理。

```python
from src.models import ModelPredictor

# 初始化模型预测器
predictor = ModelPredictor()

# 单次预测
prediction = predictor.predict(
    model=trained_model,
    X=X_new
)

print(f"预测结果: {prediction}")

# 批量预测
predictions = predictor.predict_batch(
    model=trained_model,
    X_batch=X_batch,
    batch_size=1000
)

print(f"批量预测结果: {predictions}")

# 概率预测
probabilities = predictor.predict_proba(
    model=trained_model,
    X=X_new
)

print(f"预测概率: {probabilities}")

# 置信度预测
confidence_scores = predictor.predict_with_confidence(
    model=trained_model,
    X=X_new
)

print(f"置信度分数: {confidence_scores}")
```

### ModelInference

模型推理器，负责高性能推理和实时预测。

```python
from src.models import ModelInference

# 初始化模型推理器
inference = ModelInference()

# 实时推理
real_time_predictions = inference.real_time_predict(
    model=trained_model,
    data_stream=data_stream,
    batch_size=1
)

# 异步推理
async_predictions = inference.async_predict(
    model=trained_model,
    X=X_large,
    max_workers=4
)

# 推理性能监控
performance_metrics = inference.monitor_performance(
    model=trained_model,
    X_test=X_test,
    y_test=y_test
)

print(f"推理延迟: {performance_metrics['latency']}ms")
print(f"吞吐量: {performance_metrics['throughput']} requests/sec")
```

## 评估器模块

### ModelMetrics

模型指标计算器，提供各种评估指标。

```python
from src.models import ModelMetrics

# 初始化模型指标计算器
metrics_calculator = ModelMetrics()

# 分类指标
classification_metrics = metrics_calculator.calculate_classification_metrics(
    y_true=y_test,
    y_pred=predictions
)

print(f"分类指标: {classification_metrics}")

# 回归指标
regression_metrics = metrics_calculator.calculate_regression_metrics(
    y_true=y_test,
    y_pred=predictions
)

print(f"回归指标: {regression_metrics}")

# 自定义指标
custom_metrics = metrics_calculator.calculate_custom_metrics(
    y_true=y_test,
    y_pred=predictions,
    custom_functions={
        'custom_score': lambda y_true, y_pred: custom_score_function(y_true, y_pred)
    }
)

print(f"自定义指标: {custom_metrics}")
```

## 部署模块

### ModelDeployer

模型部署器，负责模型部署和版本管理。

```python
from src.models import ModelDeployer

# 初始化模型部署器
deployer = ModelDeployer()

# 部署模型
deployment_info = deployer.deploy_model(
    model=trained_model,
    deployment_name='production_model',
    deployment_config={
        'replicas': 3,
        'resources': {
            'cpu': '1',
            'memory': '2Gi'
        },
        'autoscaling': {
            'min_replicas': 1,
            'max_replicas': 10
        }
    }
)

print(f"部署信息: {deployment_info}")

# 模型版本管理
version_info = deployer.create_version(
    model=trained_model,
    version='v1.0.0',
    description='Initial production model'
)

print(f"版本信息: {version_info}")

# 回滚模型
rollback_info = deployer.rollback_model(
    deployment_name='production_model',
    target_version='v0.9.0'
)

print(f"回滚信息: {rollback_info}")
```

### ModelServing

模型服务器，提供模型服务API。

```python
from src.models import ModelServing

# 初始化模型服务
serving = ModelServing()

# 启动服务
service_info = serving.start_service(
    model=trained_model,
    port=8080,
    host='0.0.0.0'
)

print(f"服务信息: {service_info}")

# 健康检查
health_status = serving.health_check()
print(f"健康状态: {health_status}")

# 服务统计
service_stats = serving.get_service_stats()
print(f"服务统计: {service_stats}")

# 停止服务
serving.stop_service()
```

## 集成模块

### EnsembleModel

集成模型，提供模型集成功能。

```python
from src.models import EnsembleModel

# 初始化集成模型
ensemble = EnsembleModel()

# 添加模型到集成
ensemble.add_model('model1', model1)
ensemble.add_model('model2', model2)
ensemble.add_model('model3', model3)

# 设置集成策略
ensemble.set_strategy('voting')  # 'voting', 'stacking', 'blending'

# 训练集成模型
trained_ensemble = ensemble.train(
    X_train=X_train,
    y_train=y_train
)

# 集成预测
ensemble_predictions = ensemble.predict(X_test)

print(f"集成预测结果: {ensemble_predictions}")

# 获取模型权重
model_weights = ensemble.get_model_weights()
print(f"模型权重: {model_weights}")
```

### ModelEnsemble

模型集成器，提供高级集成学习功能。

```python
from src.models import ModelEnsemble

# 初始化模型集成器
ensemble_learner = ModelEnsemble()

# 创建集成
ensemble = ensemble_learner.create_ensemble(
    base_models=[model1, model2, model3],
    meta_model=meta_model,
    strategy='stacking'
)

# 训练集成
trained_ensemble = ensemble_learner.train_ensemble(
    ensemble=ensemble,
    X_train=X_train,
    y_train=y_train,
    cv_folds=5
)

# 集成预测
ensemble_predictions = ensemble_learner.predict_ensemble(
    ensemble=trained_ensemble,
    X_test=X_test
)

print(f"集成预测结果: {ensemble_predictions}")

# 集成评估
ensemble_metrics = ensemble_learner.evaluate_ensemble(
    ensemble=trained_ensemble,
    X_test=X_test,
    y_test=y_test
)

print(f"集成评估指标: {ensemble_metrics}")
```

## 典型用法

### 1. 完整模型训练流程

```python
from src.models import ModelManager, ModelTrainer, ModelEvaluator, ModelFactory

# 1. 使用模型工厂创建模型
xgb_model = ModelFactory.create_model('xgboost', {
    'n_estimators': 100,
    'max_depth': 6,
    'learning_rate': 0.1
})

# 2. 模型训练
trainer = ModelTrainer()
trained_model = trainer.train(
    model=xgb_model,
    X_train=X_train,
    y_train=y_train,
    validation_data=(X_val, y_val)
)

# 3. 模型评估
evaluator = ModelEvaluator()
metrics = evaluator.evaluate(
    model=trained_model,
    X_test=X_test,
    y_test=y_test
)

print(f"模型性能: {metrics}")

# 4. 保存模型
manager = ModelManager()
manager.save_model('trained_model', trained_model, 'models/trained_model.pkl')
```

### 2. 多模型比较

```python
from src.models import ModelFactory, ModelEvaluator

# 创建多个模型
models = {
    'xgboost': ModelFactory.create_model('xgboost', {'n_estimators': 100}),
    'random_forest': ModelFactory.create_model('random_forest', {'n_estimators': 100})
}

# 训练所有模型
trainer = ModelTrainer()
trained_models = {}
for name, model in models.items():
    trained_models[name] = trainer.train(model, X_train, y_train)

# 评估所有模型
evaluator = ModelEvaluator()
for name, model in trained_models.items():
    metrics = evaluator.evaluate(model, X_test, y_test)
    print(f"{name} 性能: {metrics}")
```

### 2. 模型集成学习

```python
from src.models import ModelEnsemble, ModelEvaluator

# 创建集成
ensemble_learner = ModelEnsemble()
ensemble = ensemble_learner.create_ensemble(
    base_models=[rf_model, xgb_model, lgb_model],
    meta_model=lr_model,
    strategy='stacking'
)

# 训练集成
trained_ensemble = ensemble_learner.train_ensemble(
    ensemble=ensemble,
    X_train=X_train,
    y_train=y_train
)

# 评估集成
evaluator = ModelEvaluator()
ensemble_metrics = evaluator.evaluate(
    model=trained_ensemble,
    X_test=X_test,
    y_test=y_test
)

print(f"集成模型性能: {ensemble_metrics}")
```

### 3. 模型部署和服务

```python
from src.models import ModelDeployer, ModelServing

# 部署模型
deployer = ModelDeployer()
deployment_info = deployer.deploy_model(
    model=trained_model,
    deployment_name='production_model'
)

# 启动服务
serving = ModelServing()
service_info = serving.start_service(
    model=trained_model,
    port=8080
)

print(f"模型已部署并启动服务: {service_info}")
```

## 集成建议

### 1. 与特征层集成

```python
from src.features import FeatureEngineer, FeatureSelector
from src.models import ModelTrainer, ModelEvaluator

# 特征工程
engineer = FeatureEngineer()
features = engineer.extract_features(data)

# 特征选择
selector = FeatureSelector()
selected_features = selector.select_features(features, target_column='target')

# 模型训练
trainer = ModelTrainer()
trained_model = trainer.train(model, selected_features, target)

# 模型评估
evaluator = ModelEvaluator()
metrics = evaluator.evaluate(trained_model, X_test, y_test)

print(f"模型性能: {metrics}")
```

### 2. 与数据层集成

```python
from src.data import DataManager
from src.models import ModelManager, ModelTrainer

# 数据层提供数据
data_manager = DataManager()
stock_data = data_manager.load_data('stock', start_date, end_date, frequency)

# 模型层处理数据
manager = ModelManager()
model = manager.create_model('xgboost')

trainer = ModelTrainer()
trained_model = trainer.train(model, stock_data.features, stock_data.target)

print(f"模型训练完成，数据形状: {stock_data.features.shape}")
```

### 3. 与基础设施层集成

```python
from src.infrastructure import UnifiedConfigManager, ICacheManager
from src.models import ModelManager, ModelDeployer

# 使用统一配置管理
config_manager = UnifiedConfigManager()
model_config = config_manager.get('models')

# 使用统一缓存接口
cache: ICacheManager = config_manager.get_cache_manager()

# 模型管理
manager = ModelManager(config=model_config)
model = manager.create_model('xgboost')

# 缓存模型
cache.set('model_key', model, ttl=3600)

# 部署模型
deployer = ModelDeployer()
deployment_info = deployer.deploy_model(model, 'production_model')
```

## 配置说明

### 模型配置

```python
model_config = {
    'xgboost': {
        'n_estimators': 100,
        'max_depth': 6,
        'learning_rate': 0.1,
        'subsample': 0.8,
        'colsample_bytree': 0.8
    },
    'random_forest': {
        'n_estimators': 100,
        'max_depth': 10,
        'min_samples_split': 2,
        'min_samples_leaf': 1
    },
    'lightgbm': {
        'n_estimators': 100,
        'max_depth': 6,
        'learning_rate': 0.1,
        'num_leaves': 31
    }
}
```

### 训练配置

```python
training_config = {
    'validation_split': 0.2,
    'random_state': 42,
    'n_jobs': -1,
    'verbose': 1,
    'early_stopping': True,
    'patience': 10
}
```

### 评估配置

```python
evaluation_config = {
    'metrics': ['accuracy', 'precision', 'recall', 'f1', 'auc'],
    'cv_folds': 5,
    'scoring': 'accuracy',
    'random_state': 42
}
```

## 错误处理

### 常见异常

```python
from src.models import ModelTrainingError, ModelEvaluationError

try:
    trained_model = trainer.train(model, X_train, y_train)
except ModelTrainingError as e:
    print(f"模型训练失败: {e}")
    # 实现降级策略
    trained_model = load_cached_model()
except ModelEvaluationError as e:
    print(f"模型评估失败: {e}")
    # 使用默认评估
    metrics = default_evaluation()
```

### 错误恢复

```python
# 重试机制
max_retries = 3
for attempt in range(max_retries):
    try:
        trained_model = trainer.train(model, X_train, y_train)
        break
    except Exception as e:
        if attempt == max_retries - 1:
            raise e
        print(f"第{attempt + 1}次尝试失败，重试...")
        time.sleep(1)
```

## 性能优化

### 1. 并行训练

```python
from src.models import ModelTrainer

# 启用并行训练
trainer = ModelTrainer(parallel=True, n_jobs=4)

# 并行训练多个模型
models = [model1, model2, model3]
trained_models = trainer.train_parallel(
    models=models,
    X_train=X_train,
    y_train=y_train
)
```

### 2. 模型缓存

```python
from src.models import ModelManager
from src.infrastructure import ICacheManager

# 使用缓存
cache: ICacheManager = get_cache_manager()

# 检查缓存
cache_key = f"model_{hash(str(model_config))}"
if cache.exists(cache_key):
    model = cache.get(cache_key)
else:
    manager = ModelManager()
    model = manager.create_model('xgboost', model_config)
    cache.set(cache_key, model, ttl=3600)
```

### 3. 内存优化

```python
from src.models import ModelTrainer

# 使用内存优化的训练器
trainer = ModelTrainer(memory_efficient=True)

# 分批训练大数据
for batch in data_batches:
    trained_batch = trainer.train_batch(model, batch)
    # 处理结果
```

## 最佳实践

### 1. 模型训练流程

```python
# 推荐的模型训练流程
def model_training_pipeline(X, y, model_type='xgboost'):
    """完整的模型训练流程"""
    
    # 1. 数据分割
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
    
    # 2. 模型创建
    manager = ModelManager()
    model = manager.create_model(model_type)
    
    # 3. 模型训练
    trainer = ModelTrainer()
    trained_model = trainer.train(model, X_train, y_train)
    
    # 4. 模型评估
    evaluator = ModelEvaluator()
    metrics = evaluator.evaluate(trained_model, X_test, y_test)
    
    return trained_model, metrics
```

### 2. 模型监控

```python
from src.models import ModelManager
import logging

logger = logging.getLogger(__name__)

def train_model_with_monitoring(X, y, model_type):
    """带监控的模型训练"""
    manager = ModelManager()
    
    try:
        model = manager.create_model(model_type)
        trainer = ModelTrainer()
        trained_model = trainer.train(model, X, y)
        logger.info(f"模型训练成功: {model_type}")
        return trained_model
    except Exception as e:
        logger.error(f"模型训练失败: {e}")
        raise
```

### 3. 模型版本管理

```python
from src.models import ModelManager
import hashlib

def save_model_with_version(model, base_path):
    """保存模型并管理版本"""
    manager = ModelManager()
    
    # 生成模型哈希
    model_hash = hashlib.md5(str(model.get_params()).encode()).hexdigest()[:8]
    
    # 保存模型和元数据
    model_path = f"{base_path}_{model_hash}.pkl"
    metadata_path = f"{base_path}_{model_hash}_metadata.json"
    
    manager.save_model('versioned_model', model, model_path)
    manager.save_metadata('versioned_model', metadata_path)
    
    return model_path, metadata_path
```

## 总结

模型层作为RQA系统的核心组件，提供了完整的机器学习模型解决方案。通过分层架构设计，确保了模型处理的模块化和可扩展性。通过标准化的接口和丰富的功能，为上层应用提供了高质量的模型服务。

建议在实际使用中：
1. 根据具体需求选择合适的模型类型和训练方法
2. 定期监控模型性能和预测质量
3. 及时处理异常和错误情况
4. 遵循最佳实践，确保模型的可维护性和可扩展性 