# 具体模型实现文档

## 概述

本文档详细记录了模型层中具体模型实现的详细信息，包括XGBoostModel、RandomForestModel和ModelFactory的实现。

## 实现架构

### 1. 具体模型实现层

#### XGBoostModel
- **文件位置**: `src/models/concrete_models.py`
- **继承关系**: `XGBoostModel(BaseModel)`
- **功能**: XGBoost回归模型的具体实现
- **主要特性**:
  - 支持自定义参数配置
  - 自动处理训练历史记录
  - 提供完整的评估指标
  - 支持模型保存和加载

#### RandomForestModel
- **文件位置**: `src/models/concrete_models.py`
- **继承关系**: `RandomForestModel(BaseModel)`
- **功能**: RandomForest回归模型的具体实现
- **主要特性**:
  - 支持自定义参数配置
  - 自动处理训练历史记录
  - 提供完整的评估指标
  - 支持特征重要性分析

### 2. 模型工厂模式

#### ModelFactory
- **文件位置**: `src/models/concrete_models.py`
- **功能**: 统一模型创建接口
- **主要特性**:
  - 支持多种模型类型
  - 统一的配置管理
  - 易于扩展新模型类型

## 详细实现

### XGBoostModel实现

```python
class XGBoostModel(BaseModel):
    """XGBoost模型实现"""
    
    def __init__(self, model_config: Dict[str, Any]):
        super().__init__(model_config)
        self.model_type = 'xgboost'
        self.model = None
        
        # 默认参数
        default_params = {
            'n_estimators': 100,
            'max_depth': 6,
            'learning_rate': 0.1,
            'random_state': 42
        }
        
        self.model_params.update(default_params)
        self.model_params.update(model_config)
    
    def train(self, X: pd.DataFrame, y: pd.Series) -> None:
        """训练XGBoost模型"""
        try:
            import xgboost as xgb
            self.model = xgb.XGBRegressor(**self.model_params)
            self.model.fit(X, y)
            self.is_trained = True
            
            # 记录训练历史
            self.training_history.append({
                'model_type': 'xgboost',
                'params': self.model_params,
                'feature_count': len(X.columns),
                'sample_count': len(X)
            })
            
        except ImportError:
            raise ImportError("请安装xgboost: pip install xgboost")
        except Exception as e:
            logger.error(f"XGBoost模型训练失败: {e}")
            raise
```

### RandomForestModel实现

```python
class RandomForestModel(BaseModel):
    """RandomForest模型实现"""
    
    def __init__(self, model_config: Dict[str, Any]):
        super().__init__(model_config)
        self.model_type = 'random_forest'
        self.model = None
        
        default_params = {
            'n_estimators': 100,
            'max_depth': 10,
            'random_state': 42
        }
        
        self.model_params.update(default_params)
        self.model_params.update(model_config)
    
    def train(self, X: pd.DataFrame, y: pd.Series) -> None:
        """训练RandomForest模型"""
        try:
            from sklearn.ensemble import RandomForestRegressor
            self.model = RandomForestRegressor(**self.model_params)
            self.model.fit(X, y)
            self.is_trained = True
            
            # 记录训练历史
            self.training_history.append({
                'model_type': 'random_forest',
                'params': self.model_params,
                'feature_count': len(X.columns),
                'sample_count': len(X)
            })
            
        except ImportError:
            raise ImportError("请安装scikit-learn: pip install scikit-learn")
        except Exception as e:
            logger.error(f"RandomForest模型训练失败: {e}")
            raise
```

### ModelFactory实现

```python
class ModelFactory:
    """模型工厂类"""
    
    _model_registry = {
        'xgboost': XGBoostModel,
        'random_forest': RandomForestModel
    }
    
    @classmethod
    def create_model(cls, model_type: str, config: Optional[Dict[str, Any]] = None) -> BaseModel:
        """创建模型实例"""
        if model_type not in cls._model_registry:
            raise ValueError(f"不支持的模型类型: {model_type}")
        
        model_class = cls._model_registry[model_type]
        config = config or {}
        
        return model_class(config)
    
    @classmethod
    def list_available_models(cls) -> list:
        """列出所有可用的模型类型"""
        return list(cls._model_registry.keys())
```

## 配置管理

### 默认参数配置

#### XGBoost默认参数
```python
default_params = {
    'n_estimators': 100,      # 树的数量
    'max_depth': 6,           # 最大深度
    'learning_rate': 0.1,     # 学习率
    'random_state': 42        # 随机种子
}
```

#### RandomForest默认参数
```python
default_params = {
    'n_estimators': 100,      # 树的数量
    'max_depth': 10,          # 最大深度
    'random_state': 42        # 随机种子
}
```

### 配置合并机制

所有模型都支持配置合并机制：
1. 首先使用默认参数
2. 然后合并用户提供的配置
3. 用户配置会覆盖默认参数

```python
# 示例：配置合并
config = {'n_estimators': 50, 'max_depth': 4}
model = XGBoostModel(config)

# 结果：n_estimators=50, max_depth=4, learning_rate=0.1, random_state=42
```

## 测试覆盖

### 测试用例统计

- **XGBoostModel测试**: 5个测试用例
- **RandomForestModel测试**: 5个测试用例
- **ModelFactory测试**: 5个测试用例
- **集成测试**: 4个测试用例

### 测试覆盖范围

1. **模型初始化测试**
   - 验证默认参数设置
   - 验证配置合并机制
   - 验证模型类型设置

2. **配置管理测试**
   - 验证参数更新
   - 验证配置验证
   - 验证特征管理

3. **错误处理测试**
   - 验证未训练模型预测
   - 验证未训练模型评估
   - 验证不支持的模型类型

4. **集成测试**
   - 验证模型工厂集成
   - 验证配置管理集成
   - 验证评估功能集成

## 使用示例

### 基本使用

```python
from src.models import ModelFactory

# 创建XGBoost模型
xgb_model = ModelFactory.create_model('xgboost', {
    'n_estimators': 100,
    'max_depth': 6,
    'learning_rate': 0.1
})

# 训练模型
xgb_model.train(X_train, y_train)

# 预测
predictions = xgb_model.predict(X_test)

# 评估
metrics = xgb_model.evaluate(X_test, y_test)
print(f"模型性能: {metrics}")
```

### 多模型比较

```python
from src.models import ModelFactory, ModelEvaluator

# 创建多个模型
models = {
    'xgboost': ModelFactory.create_model('xgboost', {'n_estimators': 100}),
    'random_forest': ModelFactory.create_model('random_forest', {'n_estimators': 100})
}

# 训练和评估所有模型
evaluator = ModelEvaluator()
results = {}

for name, model in models.items():
    model.train(X_train, y_train)
    metrics = evaluator.evaluate(model, X_test, y_test)
    results[name] = metrics

# 比较结果
for name, metrics in results.items():
    print(f"{name}: {metrics}")
```

### 配置管理

```python
from src.models import XGBoostModel

# 创建模型
model = XGBoostModel({
    'n_estimators': 50,
    'max_depth': 4
})

# 更新配置
model.set_model_params({'n_estimators': 100})

# 设置特征名称
model.set_feature_names(['feature1', 'feature2', 'feature3'])

# 设置目标变量名称
model.set_target_name('target')
```

## 扩展指南

### 添加新模型类型

1. **创建新模型类**
```python
class NewModel(BaseModel):
    def __init__(self, model_config: Dict[str, Any]):
        super().__init__(model_config)
        self.model_type = 'new_model'
        # 实现具体逻辑
```

2. **注册到ModelFactory**
```python
ModelFactory._model_registry['new_model'] = NewModel
```

3. **添加测试用例**
```python
def test_new_model_initialization(self):
    config = {'param1': 100}
    model = NewModel(config)
    assert model.model_type == 'new_model'
```

## 性能优化

### 内存优化
- 使用默认参数减少内存占用
- 支持模型保存和加载
- 训练历史记录可配置

### 计算优化
- 支持并行训练（通过底层库）
- 批量预测支持
- 评估指标计算优化

## 错误处理

### 常见错误及解决方案

1. **ImportError: 请安装xgboost**
   - 解决方案: `pip install xgboost`

2. **ImportError: 请安装scikit-learn**
   - 解决方案: `pip install scikit-learn`

3. **ValueError: 模型未训练**
   - 解决方案: 先调用train方法训练模型

4. **ValueError: 不支持的模型类型**
   - 解决方案: 检查模型类型名称，或添加新模型类型

## 总结

具体模型实现层为RQA系统提供了：
1. **完整的模型实现**: XGBoost和RandomForest的具体实现
2. **统一的创建接口**: ModelFactory提供统一的模型创建方式
3. **灵活的配置管理**: 支持默认参数和用户配置的合并
4. **全面的测试覆盖**: 19个测试用例确保功能正确性
5. **易于扩展**: 支持添加新的模型类型

这些实现为上层应用提供了高质量的模型服务，支持完整的机器学习工作流程。 