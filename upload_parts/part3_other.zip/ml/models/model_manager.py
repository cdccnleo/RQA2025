#!/usr/bin/env python3
"""精简版模型管理器，实现单元测试所需的核心行为。"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional

from .model_metadata_classes import ModelMetadata

try:  # pragma: no cover
    from src.core.integration import get_models_adapter as _get_models_adapter
except ImportError:  # pragma: no cover
    class _FallbackAdapter:
        def get_models_logger(self):
            return logging.getLogger(__name__)

        def get_model_storage(self):
            return _InMemoryStorage()

        def get_feature_store(self):
            return None

    def _get_models_adapter():
        return _FallbackAdapter()


def get_models_adapter():
    return _get_models_adapter()


class _InMemoryStorage:
    """极简模型存储适配器，用于无依赖环境。"""

    def __init__(self):
        self._models: Dict[str, Any] = {}

    def save_model(self, model_id: str, version: str, model: Any) -> None:  # pragma: no cover
        self._models[(model_id, version)] = model

    def load_model(self, model_id: str, version: Optional[str] = None) -> Any:
        key = (model_id, version or "default")
        return self._models.get(key)


@dataclass
class ModelRegistryEntry:
    model_id: str
    version: str
    model_type: str
    status: str = "draft"
    metadata: ModelMetadata = field(default_factory=ModelMetadata)
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)

    def update_metadata(self, updates: Dict[str, Any]) -> None:
        self.metadata.update(updates)
        self.updated_at = datetime.utcnow()


class ModelManager:
    """管理模型注册、元数据与推理入口。"""

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        adapter = get_models_adapter()
        self.logger = adapter.get_models_logger()
        self.storage_adapter = getattr(adapter, "get_model_storage", lambda: _InMemoryStorage())()
        self.feature_store = getattr(adapter, "get_feature_store", lambda: None)()
        self.config = config or {}
        self.registry: Dict[str, ModelRegistryEntry] = {}

    # 基础管理能力 ---------------------------------------------------------
    def register_model(self, entry: ModelRegistryEntry) -> None:
        self.logger.info("注册模型: %s v%s", entry.model_id, entry.version)
        self.registry[entry.model_id] = entry

    def list_models(self) -> List[str]:
        return sorted(self.registry.keys())

    def get_model_metadata(self, model_id: str) -> Optional[ModelMetadata]:
        entry = self.registry.get(model_id)
        return entry.metadata if entry else None

    def update_model_metadata(self, model_id: str, updates: Dict[str, Any]) -> None:
        entry = self.registry.get(model_id)
        if not entry:
            raise KeyError(f"模型不存在: {model_id}")
        entry.update_metadata(updates)

    # 推理相关 --------------------------------------------------------------
    def load_model(self, model_id: str, version: Optional[str] = None):
        self.logger.debug("加载模型: %s@%s", model_id, version or "default")
        return self.storage_adapter.load_model(model_id, version)

    def predict(self, model_id: str, data, version: Optional[str] = None, **_) -> Any:
        model = self.load_model(model_id, version)
        if model is None:
            raise ValueError(f"模型未找到: {model_id}")
        if not hasattr(model, "predict"):
            raise ValueError("加载的对象不支持 predict 接口")
        return model.predict(data)


__all__ = ["ModelManager", "ModelRegistryEntry", "get_models_adapter"]

