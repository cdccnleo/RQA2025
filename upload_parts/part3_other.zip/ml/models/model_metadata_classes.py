from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List


@dataclass
class ModelMetadata:
    """轻量模型元数据定义，便于单元测试构造与更新。"""

    description: str = ""
    created_by: str = ""
    tags: List[str] = field(default_factory=list)
    extra: Dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)

    def update(self, updates: Dict[str, Any]) -> "ModelMetadata":
        for key, value in updates.items():
            if key in {"description", "created_by", "tags"}:
                setattr(self, key, value)
            else:
                self.extra[key] = value
        self.updated_at = datetime.utcnow()
        return self


__all__ = ["ModelMetadata"]

