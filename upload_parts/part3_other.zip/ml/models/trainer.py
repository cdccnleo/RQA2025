from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional

import pandas as pd


@dataclass
class TrainingSummary:
    model_id: str
    metrics: Dict[str, float]
    epochs: int = 0
    trained: bool = False


class ModelTrainer:
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or {}
        self.keep_history = bool(self.config.get("record_history", False))
        self.learning_rate = float(self.config.get("learning_rate", 0.01))
        self.history: list[Dict[str, float]] = []

    def train(
        self,
        model: Any,
        X: pd.DataFrame,
        y: pd.Series,
        validation_data: Optional[pd.DataFrame] = None,
    ) -> TrainingSummary:
        if not hasattr(model, "fit") or not hasattr(model, "predict"):
            raise TypeError("模型必须实现 fit 与 predict 方法")
        if X.empty or y.empty:
            raise ValueError("训练数据不能为空")

        model.fit(X, y)
        metrics: Dict[str, float] = {"loss": 0.0}
        if hasattr(model, "score"):
            try:
                metrics["score"] = float(model.score(X, y))
            except Exception:
                metrics["score"] = 0.0

        if validation_data is not None and not validation_data.empty and hasattr(model, "predict"):
            val = validation_data
            preds = model.predict(val)
            metrics["val_samples"] = len(preds)

        if self.keep_history:
            self.history.append(metrics.copy())

        return TrainingSummary(
            model_id=self.config.get("model_id", "model"),
            metrics=metrics,
            epochs=int(self.config.get("epochs", 1)),
            trained=True,
        )

    def get_history(self) -> list[Dict[str, float]]:
        return list(self.history)

__all__ = ["ModelTrainer", "TrainingSummary"]

