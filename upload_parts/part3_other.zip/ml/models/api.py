from __future__ import annotations

from typing import Any, Dict

from .model_manager import ModelManager, ModelRegistryEntry


class ModelAPI:
    def __init__(self, manager: ModelManager):
        self.manager = manager

    def register(self, entry: ModelRegistryEntry) -> None:
        self.manager.register_model(entry)

    def list_models(self):
        return self.manager.list_models()


__all__ = ["ModelAPI"]

