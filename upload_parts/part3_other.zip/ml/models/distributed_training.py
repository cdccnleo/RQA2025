"""轻量的分布式训练调度器。"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Dict, List


@dataclass
class TrainingResult:
    worker_id: int
    status: str


class DistributedTrainer:
    def __init__(self, workers: List[Callable[[], str]]):
        if not workers:
            raise ValueError("至少需要一个worker")
        self.workers = workers

    def run(self) -> List[TrainingResult]:
        results: List[TrainingResult] = []
        for idx, worker in enumerate(self.workers):
            status = worker()
            results.append(TrainingResult(worker_id=idx, status=status))
        return results


__all__ = ["DistributedTrainer", "TrainingResult"]

