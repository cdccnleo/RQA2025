"""模型类型、状态与特征类型的轻量定义。"""

from __future__ import annotations

from typing import Iterable, Set

MODEL_TYPES: Set[str] = {
    "linear_regression",
    "logistic_regression",
    "decision_tree",
    "random_forest",
    "xgboost",
    "neural_network",
    "transformer",
    "ensemble",
    "naive_bayes",
    "kmeans",
    "pca",
    "arima",
    "knn",
    "custom",
}

MODEL_STATUSES: Set[str] = {
    "training",
    "trained",
    "validated",
    "deployed",
    "failed",
    "deprecated",
}

FEATURE_TYPES: Set[str] = {
    "numeric",
    "categorical",
    "text",
    "time_series",
    "image",
    "custom",
}


def is_valid_model_type(model_type: str) -> bool:
    return model_type in MODEL_TYPES


def is_valid_status(status: str) -> bool:
    return status in MODEL_STATUSES


def is_valid_feature_type(feature_type: str) -> bool:
    return feature_type in FEATURE_TYPES


def list_model_types() -> Iterable[str]:
    return sorted(MODEL_TYPES)


__all__ = [
    "MODEL_TYPES",
    "MODEL_STATUSES",
    "FEATURE_TYPES",
    "is_valid_model_type",
    "is_valid_status",
    "is_valid_feature_type",
    "list_model_types",
]

