"""简化模型工厂，用于实例化已注册的模型构建函数。"""

from __future__ import annotations

from typing import Any, Callable, Dict, Iterable


class ModelFactory:
    _registry: Dict[str, Callable[[Dict[str, Any]], Any]] = {}

    @classmethod
    def register(cls, model_type: str, builder: Callable[[Dict[str, Any]], Any]) -> None:
        if model_type in cls._registry:
            raise ValueError(f"模型类型已存在: {model_type}")
        cls._registry[model_type] = builder

    @classmethod
    def create(cls, model_type: str, config: Dict[str, Any] | None = None) -> Any:
        if model_type not in cls._registry:
            raise ValueError(f"不支持的模型类型: {model_type}")
        return cls._registry[model_type](config or {})

    @classmethod
    def list_models(cls) -> Iterable[str]:
        return sorted(cls._registry.keys())


ModelFactory._registry = {
    "baseline": lambda cfg: {"type": "baseline", "config": cfg},
}


__all__ = ["ModelFactory"]
