"""轻量化网络组件定义，提供统一的信息、状态与处理接口。"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, Iterable, List, Optional


@dataclass
class NetworkComponent:
    network_id: int
    component_type: str = "Network"
    created_at: datetime = field(default_factory=datetime.utcnow)

    def get_network_id(self) -> int:
        return self.network_id

    def get_info(self) -> Dict[str, Any]:
        return {
            "network_id": self.network_id,
            "component_type": self.component_type,
            "component_name": f"{self.component_type}_Component_{self.network_id}",
            "created_at": self.created_at.isoformat(),
        }

    def get_status(self) -> Dict[str, Any]:
        return {
            "network_id": self.network_id,
            "status": "active",
            "component_type": self.component_type,
        }

    def process(self, data: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "network_id": self.network_id,
            "component_type": self.component_type,
            "processed_at": datetime.utcnow().isoformat(),
            "input": data,
        }


class NetworkComponentFactory:
    def __init__(self, supported_ids: Optional[Iterable[int]] = None) -> None:
        self.supported_ids = list(supported_ids or [])
        self.components: Dict[int, NetworkComponent] = {}

    def register(self, component: NetworkComponent) -> None:
        if self.supported_ids and component.network_id not in self.supported_ids:
            raise ValueError("不支持的 network_id")
        self.components[component.network_id] = component

    def create_component(self, network_id: int, **kwargs: Any) -> NetworkComponent:
        if self.supported_ids and network_id not in self.supported_ids:
            raise ValueError("不支持的 network_id")
        component = NetworkComponent(network_id=network_id, **kwargs)
        self.components[network_id] = component
        return component

    def get_component(self, network_id: int) -> Optional[NetworkComponent]:
        return self.components.get(network_id)

    def list_components(self) -> List[int]:
        return sorted(self.components.keys())


__all__ = ["NetworkComponent", "NetworkComponentFactory"]

