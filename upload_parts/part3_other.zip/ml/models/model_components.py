"""统一模型组件的轻量实现，提供基础信息与处理流程。"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, Iterable, List, Optional


@dataclass
class ModelComponent:
    model_id: int
    component_type: str = "Model"
    created_at: datetime = field(default_factory=datetime.utcnow)

    def get_model_id(self) -> int:
        return self.model_id

    def get_info(self) -> Dict[str, Any]:
        return {
            "model_id": self.model_id,
            "component_type": self.component_type,
            "component_name": f"{self.component_type}_Component_{self.model_id}",
            "created_at": self.created_at.isoformat(),
        }

    def get_status(self) -> Dict[str, Any]:
        return {
            "model_id": self.model_id,
            "status": "active",
            "component_type": self.component_type,
        }

    def process(self, data: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "model_id": self.model_id,
            "component_type": self.component_type,
            "processed_at": datetime.utcnow().isoformat(),
            "input": data,
        }


class ModelComponentFactory:
    def __init__(self, supported_ids: Optional[Iterable[int]] = None) -> None:
        self.supported_ids = list(supported_ids or [])
        self.components: Dict[int, ModelComponent] = {}

    def register(self, component: ModelComponent) -> None:
        if self.supported_ids and component.model_id not in self.supported_ids:
            raise ValueError("不支持的 model_id")
        self.components[component.model_id] = component

    def create_component(self, model_id: int, **kwargs: Any) -> ModelComponent:
        if self.supported_ids and model_id not in self.supported_ids:
            raise ValueError("不支持的 model_id")
        component = ModelComponent(model_id=model_id, **kwargs)
        self.components[model_id] = component
        return component

    def get_component(self, model_id: int) -> Optional[ModelComponent]:
        return self.components.get(model_id)

    def list_components(self) -> List[int]:
        return sorted(self.components.keys())


__all__ = ["ModelComponent", "ModelComponentFactory"]
