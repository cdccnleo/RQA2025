from __future__ import annotations

from typing import Any, Dict, Iterable, Tuple
import random


def _normalize_search_space(space: Dict[str, Iterable[Any]]) -> Dict[str, Tuple[Any, ...]]:
    return {key: tuple(values) for key, values in space.items()}


class ModelAutoML:
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.search_space = _normalize_search_space(config.get("search_space", {}))
        self.history: Dict[str, Any] = {}

    def search(self) -> Dict[str, Any]:
        if not self.search_space:
            result = {"best_model": "baseline", "score": 0.0}
        else:
            params = {key: random.choice(values) for key, values in self.search_space.items()}
            result = {"best_model": "generated", "params": params, "score": 1.0}
        self.history = result
        return result


__all__ = ["ModelAutoML"]

