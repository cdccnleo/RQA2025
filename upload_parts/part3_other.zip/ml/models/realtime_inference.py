"""实时推理轻量引擎，提供缓存与异步执行占位实现。"""

from __future__ import annotations

import asyncio
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from typing import Any, Callable, Dict, Optional

import numpy as np
import pandas as pd


@dataclass
class AsyncJob:
    model_id: str
    payload: pd.DataFrame
    future: asyncio.Future


class RealTimeInferenceEngine:
    def __init__(
        self,
        dispatcher: Callable[[str], Any],
        cache_enabled: bool = True,
        max_workers: int = 4,
    ):
        self.dispatcher = dispatcher
        self.cache_enabled = cache_enabled
        self.executor = ThreadPoolExecutor(max_workers=max_workers)
        self.cache: Dict[tuple, np.ndarray] = {}

    def _build_cache_key(self, model_id: str, data: pd.DataFrame) -> tuple:
        return model_id, tuple(data.values.flatten())

    async def predict_async(self, model_id: str, data: pd.DataFrame) -> np.ndarray:
        if not isinstance(data, pd.DataFrame):
            raise TypeError("输入必须为 pandas.DataFrame")

        cache_key = self._build_cache_key(model_id, data)
        if self.cache_enabled and cache_key in self.cache:
            return self.cache[cache_key]

        model = self.dispatcher(model_id)
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(self.executor, model.predict, data)
        array = np.asarray(result)
        if self.cache_enabled:
            self.cache[cache_key] = array
        return array

    def predict(self, model_id: str, data: pd.DataFrame) -> np.ndarray:
        return asyncio.run(self.predict_async(model_id, data))

    def clear_cache(self) -> None:
        self.cache.clear()

    def shutdown(self) -> None:
        self.executor.shutdown(wait=True)


__all__ = ["RealTimeInferenceEngine"]
