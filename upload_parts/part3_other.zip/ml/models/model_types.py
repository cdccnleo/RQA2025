"""模型状态常量。"""

from __future__ import annotations

from typing import Set

MODEL_STATUSES: Set[str] = {
    "loading",
    "ready",
    "training",
    "predicting",
    "error",
    "unloaded",
}


def is_valid_status(status: str) -> bool:
    return status in MODEL_STATUSES


__all__ = ["MODEL_STATUSES", "is_valid_status"]

