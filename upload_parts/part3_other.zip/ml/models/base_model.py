"""
基础模型类
定义所有模型的通用接口
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, List
import pandas as pd
import numpy as np

try:  # pragma: no cover
    import joblib  # noqa: F401
except ImportError:  # pragma: no cover
    joblib = None


class BaseModel(ABC):

    """基础模型抽象类"""

    def __init__(self, model_config: Dict[str, Any]):
        """
        初始化模型

        Args:
            model_config: 模型配置字典
        """
        self.model_config = model_config
        self.model = None
        self._is_trained = False
        self.training_history = []
        self.feature_names = []
        self.target_name = None
        self.model_type = None
        self.model_params = {}

    @property
    def config(self) -> Dict[str, Any]:
        """获取模型配置"""
        return self.model_config

    def set_model_params(self, params: Dict[str, Any]) -> None:
        """
        设置模型参数

        Args:
            params: 模型参数字典
        """
        self.model_params.update(params)
        self.model_config.update(params)

    def get_training_history(self) -> List[Dict[str, Any]]:
        """
        获取训练历史

        Returns:
            训练历史列表
        """
        return self.training_history

    def validate_config(self) -> bool:
        """
        验证配置

        Returns:
            配置是否有效
        """
        required_keys = ['model_type']
        return all(key in self.model_config for key in required_keys)

    def set_feature_names(self, feature_names: List[str]) -> None:
        """
        设置特征名称

        Args:
            feature_names: 特征名称列表
        """
        self.feature_names = feature_names

    def set_target_name(self, target_name: str) -> None:
        """
        设置目标变量名称

        Args:
            target_name: 目标变量名称
        """
        self.target_name = target_name

    def set_model_type(self, model_type: str) -> None:
        """
        设置模型类型

        Args:
            model_type: 模型类型
        """
        self.model_type = model_type
        self.model_config['model_type'] = model_type

    def set_predictions(self, predictions: np.ndarray) -> None:
        """
        设置预测结果

        Args:
            predictions: 预测结果数组
        """
        self.predictions = predictions

    @abstractmethod
    def train(self, X: pd.DataFrame, y: pd.Series) -> None:
        """
        训练模型

        Args:
            X: 特征数据
            y: 目标变量
        """

    @abstractmethod
    def predict(self, X: pd.DataFrame) -> np.ndarray:
        """
        预测

        Args:
            X: 特征数据

        Returns:
            预测结果
        """

    @abstractmethod
    def evaluate(self, X: pd.DataFrame, y: pd.Series) -> Dict[str, float]:
        """
        评估模型

        Args:
            X: 特征数据
            y: 真实标签

        Returns:
            评估指标字典
        """

    def save(self, path: str) -> None:
        """
        保存模型

        Args:
            path: 保存路径
        """
        if self.model is not None:
            if joblib is None:  # pragma: no cover
                raise ImportError("joblib 未安装")
            joblib.dump(self.model, path)

    def load(self, path: str) -> None:
        """
        加载模型

        Args:
            path: 模型文件路径
        """
        if joblib is None:  # pragma: no cover
            raise ImportError("joblib 未安装")
        self.model = joblib.load(path)
        self._is_trained = True
