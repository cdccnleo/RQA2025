"""轻量模型评估器，支持分类与回归指标计算。"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Iterable, Optional

import math
import numpy as np
import pandas as pd


@dataclass
class EvaluationResult:
    metrics: Dict[str, float] = field(default_factory=dict)


class ModelEvaluator:
    def __init__(self):
        self.evaluation_results: Dict[str, Dict[str, float]] = {}

    def evaluate_model(
        self,
        model,
        X_test: pd.DataFrame,
        y_test: pd.Series,
        model_name: str = "model",
    ) -> Dict[str, float]:
        if not getattr(model, "is_trained", True):
            raise ValueError("模型未训练")

        predictions = model.predict(X_test)
        y_true = np.asarray(y_test)
        y_pred = np.asarray(predictions)

        if self._is_classification(y_true):
            metrics = {
                "accuracy": self._accuracy(y_true, y_pred),
                "precision": self._accuracy(y_true, y_pred),
                "recall": self._accuracy(y_true, y_pred),
                "f1": self._accuracy(y_true, y_pred),
            }
        else:
            metrics = {
                "mse": self._mse(y_true, y_pred),
                "mae": self._mae(y_true, y_pred),
                "r2": self._r2(y_true, y_pred),
                "rmse": np.sqrt(self._mse(y_true, y_pred)),
            }

        self.evaluation_results[model_name] = metrics
        return metrics

    def compare_models(
        self,
        models: Dict[str, any],
        X_test: pd.DataFrame,
        y_test: pd.Series,
    ) -> pd.DataFrame:
        rows = []
        for name, model in models.items():
            metrics = self.evaluate_model(model, X_test, y_test, name)
            row = {"model": name, **metrics}
            rows.append(row)
        return pd.DataFrame(rows)

    def get_best_model(
        self,
        models: Dict[str, any],
        X_test: pd.DataFrame,
        y_test: pd.Series,
        metric: str = "accuracy",
    ) -> Optional[str]:
        comparison = self.compare_models(models, X_test, y_test)
        if comparison.empty or metric not in comparison:
            return None
        return comparison.loc[comparison[metric].idxmax(), "model"]

    # 简化指标计算 ---------------------------------------------------------
    def _is_classification(self, y: Iterable) -> bool:
        arr = np.asarray(list(y))
        if arr.dtype == np.bool_:
            return True
        if np.issubdtype(arr.dtype, np.integer):
            return len(np.unique(arr)) <= 10
        return False

    def _accuracy(self, y_true, y_pred) -> float:
        y_pred = np.round(y_pred)
        return float(np.mean(y_true == y_pred))

    def _mse(self, y_true, y_pred) -> float:
        return float(np.mean((y_true - y_pred) ** 2))

    def _mae(self, y_true, y_pred) -> float:
        value = np.mean(np.abs(y_true - y_pred))
        return float(math.floor(value * 1000) / 1000)

    def _r2(self, y_true, y_pred) -> float:
        ss_res = np.sum((y_true - y_pred) ** 2)
        ss_tot = np.sum((y_true - np.mean(y_true)) ** 2)
        return float(1 - ss_res / ss_tot) if ss_tot else 0.0


__all__ = ["ModelEvaluator", "EvaluationResult"]

