"""轻量化深度学习模型占位实现，便于在无 GPU 环境下完成单元测试。"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Optional

import numpy as np
import pandas as pd

from src.ml.models.base_model import BaseModel


@dataclass
class TrainingHistoryEntry:
    epoch: int
    loss: float
    metrics: Dict[str, float] = field(default_factory=dict)


@dataclass
class TrainingSummary:
    epochs: int
    history: List[TrainingHistoryEntry]
    best_loss: float
    final_loss: float


class _LightweightRegressor:
    """极简线性回归器，用于模拟深度学习模型的训练流程。"""

    def __init__(self) -> None:
        self.coefficients: Optional[np.ndarray] = None

    def fit(self, features: np.ndarray, targets: np.ndarray) -> float:
        if features.size == 0:
            raise ValueError("训练特征不能为空")
        X = np.hstack([np.ones((features.shape[0], 1)), features])
        self.coefficients, _, _, _ = np.linalg.lstsq(X, targets, rcond=None)
        predictions = X @ self.coefficients
        return float(np.mean((predictions - targets) ** 2))

    def predict(self, features: np.ndarray) -> np.ndarray:
        if self.coefficients is None:
            raise ValueError("模型尚未训练")
        X = np.hstack([np.ones((features.shape[0], 1)), features])
        return X @ self.coefficients

    def reset(self) -> None:
        self.coefficients = None


class DeepLearningModel(BaseModel):
    """提供 train / predict / evaluate 接口的轻量深度学习模型占位类。"""

    def __init__(self, config: Optional[Dict[str, object]] = None) -> None:
        config = config.copy() if config else {}
        model_type = str(config.get("model_type", "lightweight_dl"))
        super().__init__({"model_type": model_type, **config})
        self.set_model_type(model_type)
        self.learning_rate = float(config.get("learning_rate", 0.01))
        self.max_epochs = int(config.get("epochs", 3))
        if self.max_epochs <= 0:
            raise ValueError("epochs 必须为正整数")
        self.model = _LightweightRegressor()
        self.training_history: List[TrainingHistoryEntry] = []

    def _to_dataframe(self, data: Iterable) -> pd.DataFrame:
        if isinstance(data, pd.DataFrame):
            return data.copy()
        return pd.DataFrame(data)

    def train(self, X: pd.DataFrame, y: pd.Series) -> TrainingHistoryEntry:
        features = self._to_dataframe(X).astype(float).to_numpy()
        targets = pd.Series(y).to_numpy().reshape(-1, 1).astype(float)
        self.training_history.clear()
        for epoch in range(1, self.max_epochs + 1):
            loss = self.model.fit(features, targets)
            predictions = self.model.predict(features)
            mae = float(np.mean(np.abs(predictions - targets)))
            entry = TrainingHistoryEntry(epoch=epoch, loss=loss, metrics={"mae": mae})
            self.training_history.append(entry)
        self._is_trained = True
        return self.training_history[-1]

    def predict(self, X: pd.DataFrame) -> np.ndarray:
        if not self._is_trained:
            raise ValueError("模型尚未训练，无法预测")
        features = self._to_dataframe(X).astype(float).to_numpy()
        predictions = self.model.predict(features).reshape(-1)
        self.set_predictions(predictions)
        return predictions

    def evaluate(self, X: pd.DataFrame, y: pd.Series) -> Dict[str, float]:
        predictions = self.predict(X)
        targets = pd.Series(y).to_numpy().reshape(-1)
        mse = float(np.mean((predictions - targets) ** 2))
        mae = float(np.mean(np.abs(predictions - targets)))
        return {"mse": mse, "mae": mae}

    def get_training_summary(self) -> TrainingSummary:
        if not self.training_history:
            return TrainingSummary(epochs=0, history=[], best_loss=float("inf"), final_loss=float("inf"))
        losses = [entry.loss for entry in self.training_history]
        return TrainingSummary(
            epochs=len(self.training_history),
            history=list(self.training_history),
            best_loss=min(losses),
            final_loss=losses[-1],
        )

    def reset(self) -> None:
        self.model.reset()
        self.training_history.clear()
        self._is_trained = False


__all__ = ["DeepLearningModel", "TrainingSummary", "TrainingHistoryEntry"]

