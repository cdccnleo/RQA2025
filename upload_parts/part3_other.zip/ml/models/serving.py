"""轻量模型服务模块，提供可测试的模型加载与推理封装。"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

import joblib
import numpy as np
import pandas as pd


@dataclass
class ServingMetrics:
    total_requests: int = 0
    total_latency: float = 0.0
    history: List[Dict[str, Any]] = field(default_factory=list)

    def record(self, latency: float, inputs: int) -> None:
        self.total_requests += inputs
        self.total_latency += latency
        self.history.append({"latency": latency, "inputs": inputs})

    def snapshot(self) -> Dict[str, Any]:
        if not self.history:
            return {
                "total_requests": 0,
                "avg_latency": 0.0,
                "last_latency": 0.0,
            }
        return {
            "total_requests": self.total_requests,
            "avg_latency": self.total_latency / len(self.history),
            "last_latency": self.history[-1]["latency"],
        }


class ModelServingService:
    """简化的模型服务管理器。"""

    def __init__(self, storage_path: Optional[str] = None):
        self.storage_path = Path(storage_path or "./models")
        self.storage_path.mkdir(parents=True, exist_ok=True)
        self._model: Optional[Any] = None
        self._model_path: Optional[Path] = None
        self.metrics = ServingMetrics()

    def load(self, model_path: str) -> bool:
        path = Path(model_path)
        if not path.is_absolute():
            path = self.storage_path / model_path
        if not path.exists():
            return False
        try:
            self._model = joblib.load(path)
            self._model_path = path
            return True
        except Exception:
            self._model = None
            return False

    def reload(self) -> bool:
        if not self._model_path:
            return False
        return self.load(str(self._model_path))

    def predict(self, data: pd.DataFrame) -> np.ndarray:
        if self._model is None:
            raise RuntimeError("模型未加载")
        if not isinstance(data, pd.DataFrame):
            raise TypeError("输入必须为 pandas.DataFrame")
        if data.empty:
            raise ValueError("输入数据不能为空")

        predictions = self._model.predict(data)
        array = np.asarray(predictions)
        self.metrics.record(latency=0.0, inputs=len(array))
        return array

    def get_status(self) -> Dict[str, Any]:
        return {
            "loaded": self._model is not None,
            "model_path": str(self._model_path) if self._model_path else None,
            "metrics": self.metrics.snapshot(),
        }

    def list_available(self) -> Iterable[Path]:
        return (p for p in self.storage_path.glob("*.joblib"))


__all__ = ["ModelServingService", "ServingMetrics"]
