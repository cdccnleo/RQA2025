from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd


@dataclass
class PredictionRecord:
    input_rows: int
    output_shape: tuple
    duration: float
    metadata: Dict[str, Any] = field(default_factory=dict)


class PredictionError(RuntimeError):
    pass


class ModelPredictor:
    def __init__(self, model: Any):
        if model is None or not hasattr(model, "predict"):
            raise ValueError("模型必须实现 predict 方法")
        self.model = model
        self.history: List[PredictionRecord] = []

    def predict(self, data: pd.DataFrame) -> np.ndarray:
        if not isinstance(data, pd.DataFrame):
            raise PredictionError("输入必须为 pandas.DataFrame")
        if data.empty:
            raise PredictionError("输入数据不能为空")

        result = self.model.predict(data)
        array = np.asarray(result)
        self.history.append(
            PredictionRecord(
                input_rows=len(data),
                output_shape=array.shape,
                duration=0.0,
            )
        )
        return array

    def predict_with_confidence(self, data: pd.DataFrame) -> Dict[str, np.ndarray]:
        predictions = self.predict(data)
        if predictions.ndim == 1:
            confidence = np.ones_like(predictions, dtype=float)
        else:
            confidence = np.std(predictions, axis=1)
        return {"predictions": predictions, "confidence": confidence}

    def get_history(self) -> List[PredictionRecord]:
        return list(self.history)


__all__ = ["ModelPredictor", "PredictionError", "PredictionRecord"]
