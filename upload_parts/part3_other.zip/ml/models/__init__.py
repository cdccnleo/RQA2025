#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
机器学习模型模块

提供XGBoost/LightGBM模型训练和优化：
- XGBoost模型训练
- LightGBM模型训练
- 超参数自动优化
- 模型评估和对比
"""

from .xgboost_lightgbm_trainer import (
    XGBoostLightGBMTrainer,
    ModelMetrics,
    TrainedModel,
    get_model_trainer
)

__all__ = [
    'XGBoostLightGBMTrainer',
    'ModelMetrics',
    'TrainedModel',
    'get_model_trainer',
]
