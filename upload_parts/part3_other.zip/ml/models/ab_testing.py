"""轻量级 A/B 测试管理器。"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Iterable, List


@dataclass
class Result:
    model_id: str
    confidence: float

    def success(self) -> bool:
        return self.confidence >= 0.5


@dataclass
class Experiment:
    experiment_id: str
    models: Dict[str, float]
    history: List[Result] = field(default_factory=list)
    pointer: int = 0


class ABTestManager:
    """管理 A/B 实验的模型分配与结果统计。"""

    def __init__(self) -> None:
        self._experiments: Dict[str, Experiment] = {}

    def create_experiment(self, experiment_id: str, models: Dict[str, float]) -> None:
        if experiment_id in self._experiments:
            raise ValueError("experiment already exists")
        if not models or not all(weight > 0 for weight in models.values()):
            raise ValueError("models must have positive weights")
        total = sum(models.values())
        normalized = {model: weight / total for model, weight in models.items()}
        self._experiments[experiment_id] = Experiment(experiment_id, normalized)

    def select_model(self, experiment_id: str) -> str:
        experiment = self._get_experiment(experiment_id)
        model_ids = list(experiment.models.keys())
        model = model_ids[experiment.pointer % len(model_ids)]
        experiment.pointer += 1
        return model

    def record_result(self, experiment_id: str, model_id: str, confidence: float) -> None:
        experiment = self._get_experiment(experiment_id)
        if model_id not in experiment.models:
            raise ValueError("model not registered in experiment")
        experiment.history.append(Result(model_id, confidence))

    def get_summary(self, experiment_id: str) -> Dict[str, Dict[str, float]]:
        experiment = self._get_experiment(experiment_id)
        summary: Dict[str, Dict[str, float]] = {
            model_id: {"requests": 0, "success_rate": 0.0} for model_id in experiment.models
        }
        for result in experiment.history:
            model_summary = summary[result.model_id]
            model_summary["requests"] += 1
            successes = model_summary.get("successes", 0)
            if result.success():
                successes += 1
            model_summary["successes"] = successes
        for data in summary.values():
            requests = data["requests"]
            if requests:
                data["success_rate"] = data["successes"] / requests
            data.pop("successes", None)
        return summary

    def list_experiments(self) -> Iterable[str]:
        return self._experiments.keys()

    def _get_experiment(self, experiment_id: str) -> Experiment:
        if experiment_id not in self._experiments:
            raise ValueError("experiment not found")
        return self._experiments[experiment_id]


__all__ = ["ABTestManager"]

