"""轻量化模型版本管理器，提供内存级版本登记与激活操作。"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from threading import RLock
from typing import Dict, Iterable, List, Optional


@dataclass
class ModelVersion:
    version_id: str
    model_name: str
    created_by: str
    description: str = ""
    metadata: Dict[str, object] = field(default_factory=dict)
    performance_metrics: Dict[str, float] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.utcnow)
    is_active: bool = False


class ModelVersionManager:
    """测试友好型版本管理器，仅依赖内存，不涉及文件系统。"""

    def __init__(self) -> None:
        self._versions: Dict[str, ModelVersion] = {}
        self._counters: Dict[str, int] = {}
        self._lock = RLock()

    def create_version(
        self,
        model_name: str,
        created_by: str,
        description: str = "",
        metadata: Optional[Dict[str, object]] = None,
        performance_metrics: Optional[Dict[str, float]] = None,
        activate: bool = False,
    ) -> ModelVersion:
        with self._lock:
            index = self._counters.get(model_name, 0) + 1
            self._counters[model_name] = index
            version_id = f"{model_name}:v{index}"
            version = ModelVersion(
                version_id=version_id,
                model_name=model_name,
                created_by=created_by,
                description=description,
                metadata=metadata or {},
                performance_metrics=performance_metrics or {},
                is_active=False,
            )
            if activate:
                self._deactivate_model(model_name)
                version.is_active = True
            self._versions[version_id] = version
            return version

    def activate_version(self, version_id: str) -> bool:
        with self._lock:
            version = self._versions.get(version_id)
            if version is None:
                return False
            self._deactivate_model(version.model_name)
            version.is_active = True
            return True

    def rollback_to_version(self, version_id: str) -> bool:
        return self.activate_version(version_id)

    def delete_version(self, version_id: str) -> bool:
        with self._lock:
            version = self._versions.get(version_id)
            if version is None or version.is_active:
                return False
            del self._versions[version_id]
            return True

    def get_version_info(self, version_id: str) -> Optional[ModelVersion]:
        with self._lock:
            return self._versions.get(version_id)

    def get_active_version(self, model_name: str) -> Optional[ModelVersion]:
        with self._lock:
            for version in self._versions.values():
                if version.model_name == model_name and version.is_active:
                    return version
            return None

    def get_version_history(self, model_name: str) -> List[ModelVersion]:
        with self._lock:
            history = [
                version
                for version in self._versions.values()
                if version.model_name == model_name
            ]
            return sorted(history, key=lambda v: v.created_at, reverse=True)

    def get_all_versions(self) -> List[ModelVersion]:
        with self._lock:
            return list(self._versions.values())

    def get_version_summary(self) -> Dict[str, object]:
        with self._lock:
            summary: Dict[str, object] = {
                "total_versions": len(self._versions),
                "active_versions": 0,
                "models": {},
            }
            for version in self._versions.values():
                model_info = summary["models"].setdefault(
                    version.model_name,
                    {"total_versions": 0, "active_version": None},
                )
                model_info["total_versions"] += 1
                if version.is_active:
                    model_info["active_version"] = version.version_id
                    summary["active_versions"] += 1
            return summary

    def _deactivate_model(self, model_name: str) -> None:
        for version in self._versions.values():
            if version.model_name == model_name:
                version.is_active = False


__all__ = ["ModelVersionManager", "ModelVersion"]

