"""面向单测的轻量 GPU 推理引擎封装。"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Optional

import numpy as np


@dataclass
class EngineConfig:
    use_gpu: bool = False
    batch_size: int = 32


@dataclass
class EngineMetrics:
    runs: int = 0
    batches: int = 0
    samples: int = 0
    last_batch_size: Optional[int] = None


class GPUInferenceEngine:
    """简单的 GPU 推理包装，适配无 GPU 环境的业务单测。"""

    def __init__(self, config: Optional[EngineConfig | dict] = None):
        if config is None:
            self.config = EngineConfig()
        elif isinstance(config, EngineConfig):
            self.config = config
        else:
            self.config = EngineConfig(**config)
        if self.config.batch_size <= 0:
            raise ValueError("batch_size 必须为正整数")
        self.metrics = EngineMetrics()

    @property
    def gpu_enabled(self) -> bool:
        return self.config.use_gpu

    def get_gpu_info(self) -> dict:
        """返回轻量化 GPU 能力描述，方便在无 GPU 环境下降级。"""
        return {
            "gpu_enabled": self.gpu_enabled,
            "backend": "mock",
            "batch_size": self.config.batch_size,
            "runs": self.metrics.runs,
        }

    def run(self, model, features: np.ndarray | Iterable) -> np.ndarray:
        """对单批输入执行推理。"""
        if not hasattr(model, "predict"):
            raise ValueError("模型必须实现 predict 方法")
        array = np.asarray(features)
        if array.size == 0:
            return np.empty((0,))
        result = np.asarray(model.predict(array))
        if result.shape[0] != array.shape[0]:
            raise ValueError("模型输出的样本数与输入不一致")
        self.metrics.runs += 1
        self.metrics.samples += len(array)
        self.metrics.last_batch_size = len(array)
        return result

    def batch_run(self, model, features: np.ndarray | Iterable, batch_size: Optional[int] = None) -> np.ndarray:
        """按批拆分执行推理。"""
        array = np.asarray(features)
        if array.size == 0:
            return np.empty((0,))
        step = self.config.batch_size if batch_size is None else batch_size
        if step <= 0:
            raise ValueError("batch_size 必须为正整数")
        outputs = []
        for start in range(0, len(array), step):
            outputs.append(self.run(model, array[start : start + step]))
            self.metrics.batches += 1
        return np.concatenate(outputs, axis=0)


__all__ = ["GPUInferenceEngine", "EngineConfig", "EngineMetrics"]
