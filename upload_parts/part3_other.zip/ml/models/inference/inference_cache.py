from __future__ import annotations

import json
import pickle
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, Optional, Tuple, Union

import numpy as np
import pandas as pd


InputType = Union[np.ndarray, pd.DataFrame, Dict[str, Any]]


@dataclass
class CacheConfig:
    enable_cache: bool = True
    cache_path: Optional[str] = None
    ttl_seconds: int = 3600
    memory_cache_size: int = 100
    disk_cache_size: int = 500

    def resolve_path(self) -> Path:
        path = Path(self.cache_path or ".inference_cache")
        path.mkdir(parents=True, exist_ok=True)
        return path


class InferenceCache:
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = CacheConfig(**(config or {}))
        self.cache_path = self.config.resolve_path()
        self.memory_cache: Dict[str, Dict[str, Any]] = {}
        self.stats = {"hits": 0, "misses": 0, "evictions": 0}

    # 核心操作 -------------------------------------------------------------
    def get(self, model_id: str, input_data: InputType) -> Optional[Any]:
        if not self.config.enable_cache:
            return None

        key = self._generate_cache_key(model_id, input_data)
        entry = self.memory_cache.get(key)
        if entry and not self._expired(entry, self.config.ttl_seconds):
            self.stats["hits"] += 1
            return entry["result"]
        if entry:
            self.memory_cache.pop(key, None)

        disk_entry = self._load_from_disk(key)
        if disk_entry:
            self._set_memory(key, disk_entry["result"], disk_entry["timestamp"])
            self.stats["hits"] += 1
            return disk_entry["result"]

        self.stats["misses"] += 1
        return None

    def set(self, model_id: str, input_data: InputType, result: Any) -> bool:
        if not self.config.enable_cache:
            return False

        key = self._generate_cache_key(model_id, input_data)
        timestamp = time.time()
        self._set_memory(key, result, timestamp)
        self._save_to_disk(key, {"result": result, "timestamp": timestamp})
        return True

    def clear_cache(self, scope: str = "all") -> None:
        if scope in {"all", "memory"}:
            self.memory_cache.clear()
        if scope in {"all", "disk"}:
            for file in self.cache_path.glob("*.pkl"):
                file.unlink(missing_ok=True)
        self.stats.update({"hits": 0, "misses": 0, "evictions": 0})

    def warm_up_cache(
        self,
        model_id: str,
        samples: Iterable[Any],
        inference_func: Callable[[Any], Any],
    ) -> int:
        count = 0
        for sample in samples:
            result = inference_func(sample)
            self.set(model_id, sample, result)
            count += 1
        return count

    # 统计 ---------------------------------------------------------------
    def get_cache_stats(self) -> Dict[str, int]:
        return {
            **self.stats,
            "memory_cache_size": len(self.memory_cache),
            "disk_cache_size": len(list(self.cache_path.glob('*.pkl'))),
        }

    # 内部工具 -----------------------------------------------------------
    def _generate_cache_key(self, model_id: str, input_data: InputType) -> str:
        if isinstance(input_data, np.ndarray):
            payload = input_data.tobytes()
        elif isinstance(input_data, pd.DataFrame):
            payload = input_data.to_json().encode("utf-8")
        elif isinstance(input_data, dict):
            payload = json.dumps(input_data, sort_keys=True).encode("utf-8")
        else:
            payload = str(input_data).encode("utf-8")
        return f"{model_id}_{hash(payload)}"

    def _set_memory(self, key: str, result: Any, timestamp: Optional[float] = None):
        if len(self.memory_cache) >= self.config.memory_cache_size:
            outdated_key = next(iter(self.memory_cache))
            self.memory_cache.pop(outdated_key, None)
            self.stats["evictions"] += 1
        self.memory_cache[key] = {"result": result, "timestamp": timestamp or time.time()}

    def _load_from_disk(self, key: str) -> Optional[Dict[str, Any]]:
        file_path = self.cache_path / f"{key}.pkl"
        if not file_path.exists():
            return None
        with file_path.open("rb") as fh:
            entry: Dict[str, Any] = pickle.load(fh)
        if self._expired(entry, self.config.ttl_seconds):
            file_path.unlink(missing_ok=True)
            return None
        return entry

    def _save_to_disk(self, key: str, entry: Dict[str, Any]) -> None:
        existing = list(self.cache_path.glob("*.pkl"))
        if len(existing) >= self.config.disk_cache_size:
            for file in sorted(existing)[: len(existing) - self.config.disk_cache_size + 1]:
                file.unlink(missing_ok=True)
                self.stats["evictions"] += 1
        file_path = self.cache_path / f"{key}.pkl"
        with file_path.open("wb") as fh:
            pickle.dump(entry, fh)

    def _expired(self, entry: Dict[str, Any], ttl: int) -> bool:
        return time.time() - entry["timestamp"] > ttl


__all__ = ["InferenceCache"]

