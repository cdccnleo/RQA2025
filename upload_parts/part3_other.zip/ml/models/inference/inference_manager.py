from __future__ import annotations

import logging
from typing import Any, Dict, Optional

import pandas as pd

from .inference_cache import InferenceCache

try:  # pragma: no cover
    from src.core.integration import get_models_adapter as _get_models_adapter
except ImportError:  # pragma: no cover
    class _FallbackAdapter:
        def get_models_logger(self):
            return logging.getLogger(__name__)

    def _get_models_adapter():
        return _FallbackAdapter()


def get_models_adapter():
    return _get_models_adapter()


def get_model_manager(config: Optional[Dict[str, Any]] = None):
    from src.ml.models.model_manager import ModelManager

    return ModelManager(config)


def get_inference_cache(config: Optional[Dict[str, Any]] = None):
    return InferenceCache(config)


class InferenceManager:
    """面向测试的简化推理管理器，实现缓存、预测与反馈记录。"""

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or {}
        adapter = get_models_adapter()
        self.logger = adapter.get_models_logger()

        self.model_manager = get_model_manager(self.config.get("model_manager"))
        self.cache = None
        if self.config.get("cache_enabled", True):
            self.cache = get_inference_cache(self.config.get("cache"))

        self.feedback_history = []

    def _build_cache_key(self, model_id: str, data: pd.DataFrame) -> str:
        records = tuple(
            tuple(sorted(row.items())) for row in data.to_dict("records")
        )
        return f"{model_id}:{hash(records)}"

    def predict(self, model_id: str, data: pd.DataFrame, use_cache: bool = True) -> Any:
        cache_key = self._build_cache_key(model_id, data)

        if use_cache and self.cache:
            cached = self._cache_get(model_id, data, cache_key)
            if cached is not None:
                return cached

        predictions = self.model_manager.predict(model_id, data)

        if use_cache and self.cache:
            self._cache_set(model_id, data, predictions, cache_key)

        return predictions

    def record_feedback(
        self,
        model_id: str,
        input_data: Dict[str, Any],
        prediction: Dict[str, Any],
        actual: Dict[str, Any],
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        entry = {
            "model_id": model_id,
            "input": input_data,
            "prediction": prediction,
            "actual": actual,
            "metadata": metadata or {},
        }
        self.feedback_history.append(entry)

    # 缓存适配 ------------------------------------------------------------
    def _cache_get(self, model_id: str, data: pd.DataFrame, key: str):
        getter = getattr(self.cache, "get", None)
        if not callable(getter):
            return None
        import inspect

        params = list(inspect.signature(getter).parameters.keys())
        if "input_data" in params or len(params) >= 3:
            try:
                return getter(model_id, data)
            except TypeError:
                return getter(key)
        return getter(key)

    def _cache_set(self, model_id: str, data: pd.DataFrame, value: Any, key: str):
        setter = getattr(self.cache, "set", None)
        if not callable(setter):
            return
        import inspect

        params = list(inspect.signature(setter).parameters.keys())
        if "input_data" in params or len(params) >= 4:
            try:
                setter(model_id, data, value)
                return
            except TypeError:
                pass
        setter(key, value)


__all__ = [
    "InferenceManager",
    "get_model_manager",
    "get_inference_cache",
    "get_models_adapter",
]

