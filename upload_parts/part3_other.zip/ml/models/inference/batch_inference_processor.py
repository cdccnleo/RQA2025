"""简化的批量推理处理器。"""

from __future__ import annotations

from typing import Callable, Iterable, List, Optional

import numpy as np


class BatchInferenceProcessor:
    def __init__(self, batch_size: int = 32):
        if batch_size <= 0:
            raise ValueError("batch_size must be positive")
        self.batch_size = batch_size
        self.metrics: List[int] = []

    def process_batch(self, features: np.ndarray, inference_func: Callable[[np.ndarray], np.ndarray]) -> np.ndarray:
        if features.size == 0:
            return np.empty((0,))
        results: List[np.ndarray] = []
        for start in range(0, len(features), self.batch_size):
            batch = features[start:start + self.batch_size]
            results.append(inference_func(batch))
            self.metrics.append(len(batch))
        return np.concatenate(results, axis=0)

    def process_parallel(
        self,
        features_list: Iterable[np.ndarray],
        inference_func: Callable[[np.ndarray], np.ndarray],
    ) -> List[np.ndarray]:
        return [self.process_batch(features, inference_func) for features in features_list]


__all__ = ["BatchInferenceProcessor"]
