from __future__ import annotations

import json
import pickle
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, Optional


SUPPORTED_SUFFIXES = {".pkl", ".json", ".txt", ".bin"}


@dataclass
class LoaderConfig:
    storage_path: Path
    cache_enabled: bool = True

    @classmethod
    def from_dict(cls, config: Optional[Dict[str, Any]] = None) -> "LoaderConfig":
        data = config or {}
        storage_path = Path(data.get("model_storage_path", "./models"))
        storage_path.mkdir(parents=True, exist_ok=True)
        return cls(storage_path=storage_path, cache_enabled=data.get("cache_models", True))


class ModelLoader:
    """轻量模型加载器，支持 pickle/json 以及原始二进制文件。"""

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = LoaderConfig.from_dict(config)
        self._cache: Dict[str, Any] = {}

    # 公共 API -------------------------------------------------------------
    def load_model(self, model_path: str, model_type: Optional[str] = None) -> Optional[Any]:
        path = self._resolve_path(model_path)
        cache_key = str(path)

        if self.config.cache_enabled and cache_key in self._cache:
            return self._cache[cache_key]

        if not path.exists() or not path.is_file():
            return None

        model_type = (model_type or self._detect_type(path)).lower()
        loader = {
            "pickle": self._load_pickle,
            "json": self._load_json,
            "binary": self._load_binary,
        }.get(model_type, self._load_binary)

        model = loader(path)

        if self.config.cache_enabled:
            self._cache[cache_key] = model
        return model

    def clear_cache(self) -> None:
        self._cache.clear()

    def list_models(self) -> Iterable[Path]:
        return (p for p in self.config.storage_path.iterdir() if p.is_file())

    def get_metadata(self, model_path: str) -> Dict[str, Any]:
        path = self._resolve_path(model_path)
        if not path.exists():
            return {}
        return {
            "model_path": str(path),
            "model_type": self._detect_type(path),
            "file_size": path.stat().st_size,
        }

    # 内部实现 -------------------------------------------------------------
    def _resolve_path(self, model_path: str) -> Path:
        path = Path(model_path)
        if not path.is_absolute():
            path = self.config.storage_path / path
        return path

    def _detect_type(self, path: Path) -> str:
        suffix = path.suffix.lower()
        if suffix == ".pkl":
            return "pickle"
        if suffix == ".json":
            return "json"
        return "binary"

    @staticmethod
    def _load_pickle(path: Path) -> Any:
        with path.open("rb") as fp:
            return pickle.load(fp)

    @staticmethod
    def _load_json(path: Path) -> Any:
        with path.open("r", encoding="utf-8") as fp:
            return json.load(fp)

    @staticmethod
    def _load_binary(path: Path) -> bytes:
        with path.open("rb") as fp:
            return fp.read()


__all__ = ["ModelLoader", "LoaderConfig"]
