"""轻量化结构组件定义，提供基础的查询与处理能力。"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, Iterable, List, Optional


@dataclass
class StructureComponent:
    structure_id: int
    component_type: str = "Structure"
    created_at: datetime = field(default_factory=datetime.utcnow)

    def get_structure_id(self) -> int:
        return self.structure_id

    def get_info(self) -> Dict[str, Any]:
        return {
            "structure_id": self.structure_id,
            "component_type": self.component_type,
            "component_name": f"{self.component_type}_Component_{self.structure_id}",
            "created_at": self.created_at.isoformat(),
        }

    def get_status(self) -> Dict[str, Any]:
        return {
            "structure_id": self.structure_id,
            "status": "active",
            "component_type": self.component_type,
        }

    def process(self, data: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "structure_id": self.structure_id,
            "component_type": self.component_type,
            "processed_at": datetime.utcnow().isoformat(),
            "input": data,
        }


class StructureComponentFactory:
    def __init__(self, supported_ids: Optional[Iterable[int]] = None) -> None:
        self.supported_ids = list(supported_ids or [])
        self.components: Dict[int, StructureComponent] = {}

    def register(self, component: StructureComponent) -> None:
        if self.supported_ids and component.structure_id not in self.supported_ids:
            raise ValueError("不支持的 structure_id")
        self.components[component.structure_id] = component

    def create_component(self, structure_id: int, **kwargs: Any) -> StructureComponent:
        if self.supported_ids and structure_id not in self.supported_ids:
            raise ValueError("不支持的 structure_id")
        component = StructureComponent(structure_id=structure_id, **kwargs)
        self.components[structure_id] = component
        return component

    def get_component(self, structure_id: int) -> Optional[StructureComponent]:
        return self.components.get(structure_id)

    def list_components(self) -> List[int]:
        return sorted(self.components.keys())


__all__ = ["StructureComponent", "StructureComponentFactory"]

