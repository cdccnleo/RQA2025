#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
XGBoost/LightGBM模型训练器

功能：
- XGBoost模型训练和预测
- LightGBM模型训练和预测
- 模型超参数自动优化
- 模型评估和对比

作者: AI Assistant
创建日期: 2026-02-21
"""

import logging
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass
from datetime import datetime
import pandas as pd
import numpy as np

logger = logging.getLogger(__name__)


@dataclass
class ModelMetrics:
    """模型指标"""
    accuracy: float
    precision: float
    recall: float
    f1_score: float
    auc_roc: float
    log_loss: float
    training_time: float
    prediction_time: float


@dataclass
class TrainedModel:
    """训练好的模型"""
    name: str
    model: Any
    metrics: ModelMetrics
    feature_importance: Dict[str, float]
    training_date: datetime
    hyperparameters: Dict[str, Any]


class XGBoostLightGBMTrainer:
    """
    XGBoost/LightGBM模型训练器
    
    提供：
    - XGBoost模型训练
    - LightGBM模型训练
    - 超参数优化
    - 模型评估对比
    """
    
    def __init__(self, random_state: int = 42):
        """
        初始化训练器
        
        Args:
            random_state: 随机种子
        """
        self.random_state = random_state
        self.trained_models: Dict[str, TrainedModel] = {}
        
        # 检查可用库
        self._has_xgboost = self._check_xgboost()
        self._has_lightgbm = self._check_lightgbm()
        
        logger.info(f"模型训练器初始化完成 - XGBoost: {self._has_xgboost}, LightGBM: {self._has_lightgbm}")
    
    def _check_xgboost(self) -> bool:
        """检查XGBoost是否可用"""
        try:
            import xgboost as xgb
            return True
        except ImportError:
            logger.warning("XGBoost未安装")
            return False
    
    def _check_lightgbm(self) -> bool:
        """检查LightGBM是否可用"""
        try:
            import lightgbm as lgb
            return True
        except ImportError:
            logger.warning("LightGBM未安装")
            return False
    
    async def train_xgboost(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        X_val: Optional[pd.DataFrame] = None,
        y_val: Optional[pd.Series] = None,
        params: Optional[Dict[str, Any]] = None,
        use_gpu: bool = False
    ) -> TrainedModel:
        """
        训练XGBoost模型
        
        Args:
            X_train: 训练特征
            y_train: 训练标签
            X_val: 验证特征
            y_val: 验证标签
            params: 模型参数
            use_gpu: 是否使用GPU
            
        Returns:
            训练好的模型
        """
        if not self._has_xgboost:
            raise ImportError("XGBoost未安装")
        
        import xgboost as xgb
        import time
        
        start_time = time.time()
        
        # 默认参数
        if params is None:
            params = {
                'objective': 'binary:logistic',
                'eval_metric': ['auc', 'logloss'],
                'max_depth': 6,
                'learning_rate': 0.1,
                'n_estimators': 100,
                'subsample': 0.8,
                'colsample_bytree': 0.8,
                'random_state': self.random_state,
                'n_jobs': -1
            }
        
        if use_gpu:
            params['tree_method'] = 'gpu_hist'
        
        # 创建模型
        model = xgb.XGBClassifier(**params)
        
        # 训练
        eval_set = [(X_train, y_train)]
        if X_val is not None and y_val is not None:
            eval_set.append((X_val, y_val))
        
        model.fit(
            X_train, y_train,
            eval_set=eval_set,
            early_stopping_rounds=10,
            verbose=False
        )
        
        training_time = time.time() - start_time
        
        # 计算指标
        metrics = self._calculate_metrics(model, X_val, y_val) if X_val is not None else None
        if metrics:
            metrics.training_time = training_time
        
        # 特征重要性
        importance = dict(zip(X_train.columns, model.feature_importances_))
        
        trained_model = TrainedModel(
            name="XGBoost",
            model=model,
            metrics=metrics or ModelMetrics(0, 0, 0, 0, 0, 0, training_time, 0),
            feature_importance=importance,
            training_date=datetime.now(),
            hyperparameters=params
        )
        
        self.trained_models["xgboost"] = trained_model
        
        logger.info(f"XGBoost训练完成，AUC: {metrics.auc_roc if metrics else 'N/A'}")
        
        return trained_model
    
    async def train_lightgbm(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        X_val: Optional[pd.DataFrame] = None,
        y_val: Optional[pd.Series] = None,
        params: Optional[Dict[str, Any]] = None,
        use_gpu: bool = False
    ) -> TrainedModel:
        """
        训练LightGBM模型
        
        Args:
            X_train: 训练特征
            y_train: 训练标签
            X_val: 验证特征
            y_val: 验证标签
            params: 模型参数
            use_gpu: 是否使用GPU
            
        Returns:
            训练好的模型
        """
        if not self._has_lightgbm:
            raise ImportError("LightGBM未安装")
        
        import lightgbm as lgb
        import time
        
        start_time = time.time()
        
        # 默认参数
        if params is None:
            params = {
                'objective': 'binary',
                'metric': ['auc', 'binary_logloss'],
                'boosting_type': 'gbdt',
                'num_leaves': 31,
                'learning_rate': 0.1,
                'feature_fraction': 0.8,
                'bagging_fraction': 0.8,
                'bagging_freq': 5,
                'random_state': self.random_state,
                'n_jobs': -1,
                'verbose': -1
            }
        
        if use_gpu:
            params['device'] = 'gpu'
        
        # 创建模型
        model = lgb.LGBMClassifier(**params)
        
        # 训练
        eval_set = [(X_train, y_train)]
        if X_val is not None and y_val is not None:
            eval_set.append((X_val, y_val))
        
        model.fit(
            X_train, y_train,
            eval_set=eval_set,
            callbacks=[lgb.early_stopping(10), lgb.log_evaluation(0)]
        )
        
        training_time = time.time() - start_time
        
        # 计算指标
        metrics = self._calculate_metrics(model, X_val, y_val) if X_val is not None else None
        if metrics:
            metrics.training_time = training_time
        
        # 特征重要性
        importance = dict(zip(X_train.columns, model.feature_importances_))
        
        trained_model = TrainedModel(
            name="LightGBM",
            model=model,
            metrics=metrics or ModelMetrics(0, 0, 0, 0, 0, 0, training_time, 0),
            feature_importance=importance,
            training_date=datetime.now(),
            hyperparameters=params
        )
        
        self.trained_models["lightgbm"] = trained_model
        
        logger.info(f"LightGBM训练完成，AUC: {metrics.auc_roc if metrics else 'N/A'}")
        
        return trained_model
    
    def _calculate_metrics(
        self,
        model: Any,
        X_val: pd.DataFrame,
        y_val: pd.Series
    ) -> ModelMetrics:
        """计算模型指标"""
        import time
        from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, log_loss
        
        # 预测
        start_time = time.time()
        y_pred = model.predict(X_val)
        y_pred_proba = model.predict_proba(X_val)[:, 1]
        prediction_time = time.time() - start_time
        
        # 计算指标
        accuracy = accuracy_score(y_val, y_pred)
        precision = precision_score(y_val, y_pred, zero_division=0)
        recall = recall_score(y_val, y_pred, zero_division=0)
        f1 = f1_score(y_val, y_pred, zero_division=0)
        auc = roc_auc_score(y_val, y_pred_proba)
        loss = log_loss(y_val, y_pred_proba)
        
        return ModelMetrics(
            accuracy=accuracy,
            precision=precision,
            recall=recall,
            f1_score=f1,
            auc_roc=auc,
            log_loss=loss,
            training_time=0,
            prediction_time=prediction_time
        )
    
    async def hyperparameter_optimization(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        X_val: pd.DataFrame,
        y_val: pd.Series,
        model_type: str = "xgboost",
        n_trials: int = 50
    ) -> Dict[str, Any]:
        """
        超参数优化
        
        Args:
            X_train: 训练特征
            y_train: 训练标签
            X_val: 验证特征
            y_val: 验证标签
            model_type: 模型类型 ('xgboost' 或 'lightgbm')
            n_trials: 优化次数
            
        Returns:
            最优参数
        """
        try:
            import optuna
        except ImportError:
            logger.warning("Optuna未安装，使用默认参数")
            return {}
        
        def objective(trial):
            if model_type == "xgboost":
                params = {
                    'max_depth': trial.suggest_int('max_depth', 3, 10),
                    'learning_rate': trial.suggest_float('learning_rate', 0.01, 0.3),
                    'n_estimators': trial.suggest_int('n_estimators', 50, 300),
                    'subsample': trial.suggest_float('subsample', 0.6, 1.0),
                    'colsample_bytree': trial.suggest_float('colsample_bytree', 0.6, 1.0),
                    'reg_alpha': trial.suggest_float('reg_alpha', 1e-8, 10.0, log=True),
                    'reg_lambda': trial.suggest_float('reg_lambda', 1e-8, 10.0, log=True),
                }
                
                import xgboost as xgb
                model = xgb.XGBClassifier(**params, random_state=self.random_state)
                
            else:  # lightgbm
                params = {
                    'num_leaves': trial.suggest_int('num_leaves', 20, 100),
                    'learning_rate': trial.suggest_float('learning_rate', 0.01, 0.3),
                    'n_estimators': trial.suggest_int('n_estimators', 50, 300),
                    'feature_fraction': trial.suggest_float('feature_fraction', 0.6, 1.0),
                    'bagging_fraction': trial.suggest_float('bagging_fraction', 0.6, 1.0),
                    'bagging_freq': trial.suggest_int('bagging_freq', 1, 10),
                    'reg_alpha': trial.suggest_float('reg_alpha', 1e-8, 10.0, log=True),
                    'reg_lambda': trial.suggest_float('reg_lambda', 1e-8, 10.0, log=True),
                }
                
                import lightgbm as lgb
                model = lgb.LGBMClassifier(**params, random_state=self.random_state, verbose=-1)
            
            model.fit(X_train, y_train)
            y_pred_proba = model.predict_proba(X_val)[:, 1]
            
            from sklearn.metrics import roc_auc_score
            auc = roc_auc_score(y_val, y_pred_proba)
            
            return auc
        
        study = optuna.create_study(direction='maximize')
        study.optimize(objective, n_trials=n_trials, show_progress_bar=False)
        
        logger.info(f"超参数优化完成，最优AUC: {study.best_value:.4f}")
        
        return study.best_params
    
    def compare_models(self) -> pd.DataFrame:
        """
        对比已训练模型
        
        Returns:
            对比结果DataFrame
        """
        if not self.trained_models:
            return pd.DataFrame()
        
        comparison = []
        for name, model in self.trained_models.items():
            comparison.append({
                'Model': name,
                'Accuracy': model.metrics.accuracy,
                'Precision': model.metrics.precision,
                'Recall': model.metrics.recall,
                'F1 Score': model.metrics.f1_score,
                'AUC-ROC': model.metrics.auc_roc,
                'Log Loss': model.metrics.log_loss,
                'Training Time (s)': model.metrics.training_time,
                'Prediction Time (s)': model.metrics.prediction_time
            })
        
        return pd.DataFrame(comparison)
    
    def get_best_model(self, metric: str = "auc_roc") -> Optional[TrainedModel]:
        """
        获取最佳模型
        
        Args:
            metric: 评估指标
            
        Returns:
            最佳模型
        """
        if not self.trained_models:
            return None
        
        best_model = None
        best_score = -float('inf')
        
        for name, model in self.trained_models.items():
            score = getattr(model.metrics, metric, 0)
            if score > best_score:
                best_score = score
                best_model = model
        
        return best_model


# 全局训练器实例
_trainer_instance: Optional[XGBoostLightGBMTrainer] = None


def get_model_trainer(random_state: int = 42) -> XGBoostLightGBMTrainer:
    """获取模型训练器实例"""
    global _trainer_instance
    
    if _trainer_instance is None:
        _trainer_instance = XGBoostLightGBMTrainer(random_state)
    
    return _trainer_instance
